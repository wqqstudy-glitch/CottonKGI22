# Split Manifests

The `train_manifest.csv`, `val_manifest.csv` and `test_manifest.csv` files are
**not** included in this package because they are generated against a local
materialization of CottonKGI-22 (whose images carry the source licenses).

Generate them locally after reconstructing the image dataset:

```bash
python ../scripts/export_split_manifests.py \
    --data <CottonKGI-22 ImageFolder> \
    --class-indices ../class_indices/class_indices.json \
    --out . --expect 7088 1104 2941
```

Each manifest has columns:

- `relative_path` — path of the image relative to the dataset root
  (`<split>/<class>/<file>`)
- `class_name`
- `class_index` (0–21, see `../class_indices/class_indices.json`)

Expected counts: train 7,088; validation 1,104; test 2,941 (total 11,133).

Once generated, these three CSV files may be added to the public repository; they
contain no image pixels.
