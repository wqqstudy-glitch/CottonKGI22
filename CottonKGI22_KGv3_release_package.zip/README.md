# CottonKGI-22 & Cotton Pest/Disease KG v3 — Supplementary Data Package

Supporting data and code for the paper:

**Knowledge-Graph-Guided Vision–Language Fusion for Cotton Pest and Disease Recognition**

This package contains the *author-generated* artefacts needed to understand and
reproduce the study. It does **not** redistribute the source photographs, which
remain under the licenses of their original datasets.

---

## 1. Contents

```
release_staging/
├── README.md                         This file
├── DATA_SOURCES_AND_LICENSES.md      Source datasets, licenses, and how to obtain images
├── kg_v3/
│   ├── kg_entities.csv               All 1,600 entities (id, label, name, source_table)
│   ├── kg_triples.csv                All 2,743 triples (relation, head, tail, source_table)
│   ├── entities_tables/*.csv         Per-entity-type tables (Neo4j import layout, CSV)
│   └── relations_tables/*.csv        Per-relation-type tables (Neo4j import layout, CSV)
├── class_indices/
│   ├── class_indices.json            {class_name: index} for the 22 classes
│   ├── cottonkgi22_class_indices.csv index, class_name, kg_id, entity_type
│   └── class_map_detailed.json       Same mapping, structured
├── prompts/
│   └── prompts.json                  Multi-view text prompts per class (avg 5.9/class)
├── splits/
│   └── README.md                     How to generate train/val/test manifests locally
├── cached_predictions/
│   ├── M0_vis_test.npz               M0 visual-branch softmax probabilities (test)
│   └── M3_kg_test.npz                M3 semantic-branch cosine similarities (test)
└── scripts/
    ├── requirements.txt
    ├── export_split_manifests.py     Build train/val/test path manifests from your images
    ├── 05_train.py                   M0: YOLO11s-cls training
    ├── 15_build_prompts.py           Multi-view prompt construction
    ├── 16_clip_score.py              Image–text similarity scoring
    ├── 17_fuse_branches.py           Product-of-Experts fusion
    ├── 18_train_clip_lora.py         M3: Chinese-CLIP + LoRA training
    ├── 19_dedup_audit.py             Byte-level & leakage audit
    ├── 20_clean_cross_split.py       Cross-split leakage handling
    ├── 21_materialize_clean_plan.py  Materialize cleaned dataset
    ├── 22_near_duplicate_dedup.py    Near-duplicate (perceptual-hash) de-duplication
    ├── 23_zero_fusion_M0M2.py        M0+M2 zero-shot fusion control
    └── ...                            Remaining pipeline scripts
```

## 2. Key statistics

- **Knowledge Graph v3:** 1,600 entities, 2,743 triples; 87 target pest/disease
  entities (55 pests, 30 diseases, 2 physiological disorders), plus natural-enemy,
  growth-stage and other supporting entities.
- **Image dataset CottonKGI-22:** 22 classes, 11,133 images after byte-level and
  near-duplicate de-duplication; splits train/val/test = 7,088 / 1,104 / 2,941.
- **Results (test Top-1):** M0 visual 0.8354; M3 semantic 0.8569; PoE fusion 0.8708
  (macro-F1 0.8413), a net gain of 104 correct predictions over M0.

## 3. Reproducing the exact dataset split

Image pixels are not included. To obtain the *exact* split used in the paper:

1. Download the source datasets listed in `DATA_SOURCES_AND_LICENSES.md`.
2. Run the merge / de-duplication pipeline (`scripts/10_merge_datasets.py`,
   `19`–`22`) to materialize CottonKGI-22.
3. Generate the path manifests:
   ```bash
   python scripts/export_split_manifests.py \
       --data <CottonKGI-22 ImageFolder> \
       --class-indices class_indices/class_indices.json \
       --out splits --expect 7088 1104 2941
   ```

## 4. License of this package

The author-generated data in `kg_v3/`, `class_indices/`, `prompts/` and `scripts/`
is released under the **Creative Commons Attribution 4.0 International (CC BY 4.0)**
license (see `LICENSE`). The source photographs retain their original licenses; see
`DATA_SOURCES_AND_LICENSES.md`.

## 5. Citation

Please cite the article (bibliographic details to be updated upon publication).
IP102 should additionally be cited as:

> Wu, X.; Zhan, C.; Lai, Y.-K.; Cheng, M.-M.; Yang, J. **IP102: A Large-Scale
> Benchmark Dataset for Insect Pest Recognition.** In *Proceedings of the IEEE/CVF
> Conference on Computer Vision and Pattern Recognition (CVPR)*, 2019, pp. 8787–8796.
