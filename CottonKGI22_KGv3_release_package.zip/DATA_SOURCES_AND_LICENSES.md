# Data Sources, Licenses and Reconstruction Guide

CottonKGI-22 integrates images from three sources. The 22 classes are assigned as
follows (one class, Cotton Bollworm, is merged from two sources).

## 1. IP102

- **Reference:** Wu, X.; Zhan, C.; Lai, Y.-K.; Cheng, M.-M.; Yang, J. *IP102: A
  Large-Scale Benchmark Dataset for Insect Pest Recognition.* CVPR 2019, pp. 8787–8796.
- **Project page:** https://github.com/xpwu95/IP102
- **Classes used (12):** Silverleaf Whitefly, American Leafminer, Cotton Stainer,
  Cotton Leafhopper, Beet Armyworm, Onion Thrips, Cotton Leafworm, Cotton Semi-looper,
  Black Cutworm, Solenopsis Mealybug, Cotton Aphid, Carmine Spider Mite.
- **License:** Released for research use; please consult the project page for the
  current terms and cite the CVPR paper.
- *Note:* IP102 covers more than 100 crop pests; only the cotton-relevant classes
  listed above were extracted.

## 2. CottonInsect

- **Description:** A cotton-field insect image dataset from Xinjiang, China, used for
  the classification of cotton insects (including natural enemies).
- **Classes used (7, plus the shared Cotton Bollworm):** Green Lacewing, Hoverfly,
  Lady Beetle, Alfalfa Plant Bug, Green Plant Bug, Sutural Plant Bug, Tarnished Plant Bug.
- **Cotton Bollworm (Cotton Bollworm):** merged from CottonInsect **and** IP102.
- **License:** Use in accordance with the terms stated by the dataset providers; cite
  the corresponding source publication. *[Insert exact citation / repository link if
  available — verify before final submission.]*

## 3. Public cotton leaf-disease images

- **Classes used (2):** Cotton Leaf Curl Disease, Angular Leaf Spot.
- **Provenance:** Publicly available cotton leaf-disease images compiled for this study.
- **Important:** These are **not** from PlantVillage (PlantVillage contains no cotton
  category). The exact original provenance should be recorded before publication;
  please document the download source or publication for each of the two disease
  folders. *[Verify and insert precise provenance.]*

## 4. Class ↔ source summary (22 classes)

| # | Class (English) | Source |
|---|---|---|
| 0 | Sutural Plant Bug | CottonInsect |
| 1 | Black Cutworm | IP102 |
| 2 | Solenopsis Mealybug | IP102 |
| 3 | Cotton Leafworm | IP102 |
| 4 | Carmine Spider Mite | IP102 |
| 5 | Cotton Stainer | IP102 |
| 6 | Cotton Leafhopper | IP102 |
| 7 | Cotton Semi-looper | IP102 |
| 8 | Cotton Leaf Curl Disease | Public leaf-disease images |
| 9 | Cotton Aphid | IP102 |
| 10 | Angular Leaf Spot | Public leaf-disease images |
| 11 | Cotton Bollworm | CottonInsect + IP102 |
| 12 | Silverleaf Whitefly | IP102 |
| 13 | Onion Thrips | IP102 |
| 14 | Tarnished Plant Bug | CottonInsect |
| 15 | Lady Beetle | CottonInsect |
| 16 | Beet Armyworm | IP102 |
| 17 | Green Plant Bug | CottonInsect |
| 18 | American Leafminer | IP102 |
| 19 | Alfalfa Plant Bug | CottonInsect |
| 20 | Green Lacewing | CottonInsect |
| 21 | Hoverfly | CottonInsect |

## 5. Why the original images are not in this package

The source images are governed by the providers' licenses and are therefore not
redistributed here. This package instead provides the KG, prompts, class indices,
the exact split manifests (generated with `scripts/export_split_manifests.py`) and
the build scripts, allowing any researcher to reconstruct CottonKGI-22 from the
original sources under the respective licenses.

## 6. Items to verify before final submission

1. Exact citation / repository URL and license for **CottonInsect**.
2. Precise provenance for the two **leaf-disease** class folders.
3. Confirm the current **IP102** terms on the project page.
