#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
18_train_clip_lora.py
用现有 ImageFolder 训练集对 Chinese-CLIP 做轻量 LoRA 微调(图文对比学习),
把通用图文模型拉进棉花害虫领域, 同时用 KG 多 prompt 作为每类的文本语义锚点。

做法:
  - 冻结 Chinese-CLIP 主干, 仅给 视觉/文本 编码器注意力投影挂 LoRA (经验 <5% 参数)
  - 损失: 对称 InfoNCE  (image->text 与 text->image 交叉熵平均)
  - 每张图在其类别 prompt 池中随机抽一条文本, 一个 epoch 内文本表述多样化
  - WeightedRandomSampler 平衡 315 倍的类别悬殊
  - 图像强增强: RandomResizedCrop/Flip/ColorJitter + CLIP 归一化
  - 每个 epoch 在 val 上用"类 prompt 质心余弦"报一次 Top-1, 监控领域迁移
  - 训练后 merge_and_unload, 存成**完整 safetensors 模型目录**, 16 号 --model-path 直接读

依赖:
  pip install peft transformers torch pillow torchvision numpy

用法:
  python scripts/18_train_clip_lora.py --data merged \
      --prompts outputs/kg_prompts/prompts.json \
      --class-indices merged/class_indices.json \
      --out outputs/clip_lora --epochs 4 --batch 32 --lr 1e-4
  # 冒烟(每类取少量, 1 epoch):  --limit-per-class 20 --epochs 1
"""
import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

# Chinese-CLIP 图像归一化常量(与预训练一致)
CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD = (0.26862954, 0.26130258, 0.27577711)


def set_seed(s):
    random.seed(s); np.random.seed(s)
    try:
        import torch
        torch.manual_seed(s); torch.cuda.manual_seed_all(s)
    except Exception:
        pass


def load_base_model(model_id, model_path, device):
    """与 16 号一致的稳健加载(放行 torch<2.6 的 torch.load 安全拦截)。"""
    import torch
    import transformers.utils.import_utils as iu
    iu.check_torch_load_is_safe = lambda *a, **k: None
    from transformers import ChineseCLIPModel, ChineseCLIPProcessor
    import transformers.modeling_utils as mu
    if hasattr(mu, "check_torch_load_is_safe"):
        mu.check_torch_load_is_safe = lambda *a, **k: None

    src = model_id
    if model_path:
        p = Path(model_path)
        if not p.exists():
            print(f"❌ --model-path 不存在: {p}", file=sys.stderr); sys.exit(1)
        src = str(p.parent if p.is_file() else p)
    print(f"[base] 加载 Chinese-CLIP: {src}")
    model = ChineseCLIPModel.from_pretrained(src)
    processor = ChineseCLIPProcessor.from_pretrained(src)
    return model, processor, torch


def build_transforms():
    import torchvision.transforms as T
    train_tf = T.Compose([
        T.RandomResizedCrop(224, scale=(0.7, 1.0), ratio=(0.8, 1.25)),
        T.RandomHorizontalFlip(),
        T.ColorJitter(0.2, 0.2, 0.2, 0.05),
        T.ToTensor(),
        T.Normalize(CLIP_MEAN, CLIP_STD),
    ])
    val_tf = T.Compose([
        T.Resize(224), T.CenterCrop(224), T.ToTensor(),
        T.Normalize(CLIP_MEAN, CLIP_STD),
    ])
    return train_tf, val_tf


def make_dataset(split_dir, class_indices, prompts_doc, tf, tokenizer, limit_per_class=0):
    """返回 samples=[(path, cidx, cname)], 以及类名->prompt池。"""
    from PIL import Image
    samples, pool = [], {}
    for cname, cidx in class_indices.items():
        cdir = split_dir / cname
        if not cdir.is_dir():
            print(f"[warn] 缺类目录 {cdir}"); continue
        imgs = sorted([p for p in cdir.rglob("*")
                       if p.is_file() and p.suffix.lower() in IMG_EXTS])
        if limit_per_class:
            imgs = imgs[:limit_per_class]
        ps = prompts_doc.get(cname, {}).get("prompts", [])
        if not ps:
            print(f"❌ {cname} 无 prompt", file=sys.stderr); sys.exit(1)
        pool[cname] = ps
        for p in imgs:
            samples.append((p, int(cidx), cname))
    return samples, pool


class PairDataset:
    """__getitem__ 返回 (增强图像张量, 随机 KG prompt 的 token)。轻量自实现, 不依赖 DataLoader collator。"""
    def __init__(self, samples, pool, tf, tokenizer):
        self.samples, self.pool, self.tf, self.tok = samples, pool, tf, tokenizer

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, i):
        from PIL import Image
        path, cidx, cname = self.samples[i]
        img = Image.open(path).convert("RGB")
        x = self.tf(img)
        text = random.choice(self.pool[cname])
        enc = self.tok(text, padding="max_length", max_length=64,
                       truncation=True, return_tensors="pt")
        item = {"pixel": x, "input_ids": enc["input_ids"][0],
                "attention_mask": enc["attention_mask"][0]}
        if "token_type_ids" in enc:
            item["token_type_ids"] = enc["token_type_ids"][0]
        return item


def make_loader(ds, batch, weights=None, shuffle=True, workers=2):
    import torch
    from torch.utils.data import DataLoader
    if weights is not None:
        sampler = torch.utils.data.WeightedRandomSampler(
            weights, num_samples=len(weights), replacement=True)
        return DataLoader(ds, batch_size=batch, sampler=sampler, num_workers=workers,
                          drop_last=True)
    return DataLoader(ds, batch_size=batch, shuffle=shuffle, num_workers=workers,
                      drop_last=False)


def _feat(out):
    """兼容不同 transformers 版本: get_*_features 可能返回 tensor 或带 pooler 的对象。"""
    import torch
    if torch.is_tensor(out):
        return out.float()
    if getattr(out, "pooler_output", None) is not None:
        return out.pooler_output.float()
    if getattr(out, "last_hidden_state", None) is not None:
        return out.last_hidden_state[:, 0].float()
    if hasattr(out, "image_embeds") and out.image_embeds is not None:
        return out.image_embeds.float()
    if hasattr(out, "text_embeds") and out.text_embeds is not None:
        return out.text_embeds.float()
    raise TypeError(f"无法从 {type(out)} 提取特征")


def class_centroids(model, tokenizer, prompts_doc, classes, device, torch):
    import torch.nn.functional as F
    feats = []
    model.eval()
    with torch.no_grad():
        for c in classes:
            enc = tokenizer(prompts_doc[c]["prompts"], padding="max_length",
                            max_length=64, truncation=True, return_tensors="pt")
            kw = {k: v.to(device) for k, v in enc.items()}
            e = F.normalize(_feat(model.get_text_features(**kw)), dim=-1).mean(0, keepdim=True)
            feats.append(F.normalize(e, dim=-1))
    return torch.cat(feats, 0)


def eval_zeroshot(model, val_samples, pool, val_tf, tokenizer, centroids,
                  classes, device, torch, batch=64, max_n=2000):
    """用类 prompt 质心余弦评估 val Top-1 (与 16 号口径一致)。"""
    import torch.nn.functional as F
    from PIL import Image
    idx = list(range(len(val_samples)))
    random.Random(0).shuffle(idx)
    idx = idx[:max_n]
    cindex = {c: i for i, c in enumerate(classes)}
    correct, n = 0, 0
    model.eval()
    with torch.no_grad():
        for s in range(0, len(idx), batch):
            xs, ys = [], []
            for j in idx[s:s + batch]:
                path, cidx, cname = val_samples[j]
                xs.append(val_tf(Image.open(path).convert("RGB")))
                ys.append(cindex[cname])
            xv = torch.stack(xs).to(device)
            ie = F.normalize(_feat(model.get_image_features(pixel_values=xv)), dim=-1)
            pred = (ie @ centroids.T).argmax(1).cpu().numpy()
            correct += int((pred == np.array(ys)).sum()); n += len(ys)
    return correct / max(n, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="merged")
    ap.add_argument("--prompts", default="outputs/kg_prompts/prompts.json")
    ap.add_argument("--class-indices", default="merged/class_indices.json")
    ap.add_argument("--link", default="merged/kg_link.json")
    ap.add_argument("--model", default="OFA-Sys/chinese-clip-vit-base-patch16")
    ap.add_argument("--model-path", default=None)
    ap.add_argument("--out", default="outputs/clip_lora")
    ap.add_argument("--epochs", type=int, default=4)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--weight-decay", type=float, default=0.01)
    ap.add_argument("--lora-r", type=int, default=8)
    ap.add_argument("--lora-alpha", type=int, default=16)
    ap.add_argument("--lora-dropout", type=float, default=0.05)
    ap.add_argument("--limit-per-class", type=int, default=0)
    ap.add_argument("--workers", type=int, default=2, help="DataLoader 进程数, Windows 卡死可设 0")
    ap.add_argument("--no-balance", action="store_true")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    set_seed(args.seed)
    data = Path(args.data)
    prompts_doc = json.loads(Path(args.prompts).read_text(encoding="utf-8"))
    ci_path = Path(args.class_indices)
    if not ci_path.exists():
        link = json.loads(Path(args.link).read_text(encoding="utf-8"))
        class_indices = {k: v["class_index"] for k, v in link.items()}
    else:
        class_indices = json.loads(ci_path.read_text(encoding="utf-8"))
    classes = [c for c, _ in sorted(class_indices.items(), key=lambda kv: kv[1])]

    model, processor, torch = load_base_model(args.model, args.model_path, "cuda")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = processor.tokenizer

    # ---------- 数据 ----------
    train_tf, val_tf = build_transforms()
    train_samples, pool = make_dataset(
        data / "train", class_indices, prompts_doc, train_tf, tokenizer,
        args.limit_per_class)
    val_samples, _ = make_dataset(
        data / "val", class_indices, prompts_doc, val_tf, tokenizer,
        args.limit_per_class)
    print(f"[data] train {len(train_samples)} 张 | val {len(val_samples)} 张 | {len(classes)} 类")

    weights = None
    if not args.no_balance:
        cnt = {}
        for _, _, cname in train_samples:
            cnt[cname] = cnt.get(cname, 0) + 1
        w = np.array([1.0 / cnt[cname] for _, _, cname in train_samples], dtype="float64")
        weights = w / w.sum() * len(w)
        print(f"[data] 类别均衡采样 (最多 {max(cnt.values())} / 最少 {min(cnt.values())})")
    train_ds = PairDataset(train_samples, pool, train_tf, tokenizer)
    loader = make_loader(train_ds, args.batch, weights, shuffle=True,
                         workers=args.workers)

    # ---------- LoRA ----------
    try:
        from peft import LoraConfig, get_peft_model
    except ImportError:
        print("缺少 peft, 请先: pip install peft", file=sys.stderr); sys.exit(1)

    # 视觉塔是 CLIP 结构(q_proj/v_proj), 文本塔是 BERT 结构(query/value), 两套命名都挂上
    lora_cfg = LoraConfig(
        r=args.lora_r, lora_alpha=args.lora_alpha, lora_dropout=args.lora_dropout,
        bias="none",
        target_modules=["q_proj", "k_proj", "v_proj", "query", "key", "value"],
    )
    model = get_peft_model(model, lora_cfg)
    model.to(device).train()
    trainable, total = 0, 0
    for p in model.parameters():
        total += p.numel()
        if p.requires_grad:
            trainable += p.numel()
    print(f"[lora] r={args.lora_r} alpha={args.lora_alpha} | "
          f"可训练 {trainable/1e6:.2f}M / {total/1e6:.1f}M = {trainable/total:.2%}")

    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
                            lr=args.lr, weight_decay=args.weight_decay)
    ce = torch.nn.CrossEntropyLoss()

    def batch_to_device(b):
        kw = {k: v.to(device) for k, v in b.items() if k != "pixel"}
        kw["pixel_values"] = b["pixel"].to(device)
        return kw

    # 输出目录提前建好，best-save 也要写
    out_dir = Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)
    history = []
    best_top1 = -1.0; best_epoch = -1
    for ep in range(args.epochs):
        model.train(); run, nb = 0.0, 0
        for step, b in enumerate(loader):
            kw = batch_to_device(b)
            out = model(pixel_values=kw["pixel_values"],
                        input_ids=kw["input_ids"],
                        attention_mask=kw["attention_mask"],
                        token_type_ids=kw.get("token_type_ids"))
            lg = out.logits_per_image
            labels = torch.arange(lg.size(0), device=device)
            loss = 0.5 * (ce(lg, labels) + ce(lg.t(), labels))
            opt.zero_grad(); loss.backward(); opt.step()
            run += loss.item(); nb += 1
            if step % 50 == 0:
                print(f"\r  epoch {ep+1}/{args.epochs} step {step}/{len(loader)} "
                      f"loss {run/nb:.4f}", end="", flush=True)
        print()
        centroids = class_centroids(model, tokenizer, prompts_doc, classes, device, torch)
        top1 = eval_zeroshot(model, val_samples, pool, val_tf, tokenizer,
                             centroids, classes, device, torch)
        print(f"[epoch {ep+1}] train_loss {run/nb:.4f} | val 类质心 Top-1 {top1:.4f}")
        history.append({"epoch": ep + 1, "train_loss": run / nb, "val_top1": top1})
        # 按验证峰值另存 best 合并模型（对副本做 merge，不影响训练中的 model）
        if top1 > best_top1:
            best_top1 = top1; best_epoch = ep + 1
            try:
                import copy as _copy
                model_copy = _copy.deepcopy(model)
                merged_best = model_copy.merge_and_unload()
                best_dir = out_dir / "best"
                best_dir.mkdir(parents=True, exist_ok=True)
                merged_best.save_pretrained(best_dir, safe_serialization=True)
                processor.save_pretrained(best_dir)
                del model_copy, merged_best
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                print(f"  [best] epoch {best_epoch} val {best_top1:.4f} -> {best_dir.resolve()}")
            except Exception as e:
                print(f"  [best] 另存失败: {e}")

    # ---------- 合并 LoRA, 存完整 safetensors 模型目录 ----------
    print("[save] 合并 LoRA 并导出末轮完整模型 ...")
    merged = model.merge_and_unload()
    final_dir = out_dir / "final"
    final_dir.mkdir(parents=True, exist_ok=True)
    merged.save_pretrained(final_dir, safe_serialization=True)
    processor.save_pretrained(final_dir)
    # 同时留一份 adapter
    try:
        model.save_pretrained(out_dir / "adapter")
    except Exception:
        pass
    (out_dir / "train_history.json").write_text(
        json.dumps({"args": {k: str(v) for k, v in vars(args).items()},
                    "history": history,
                    "best_epoch": best_epoch,
                    "best_val_top1": best_top1,
                    "prompts_used": args.prompts}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    print(f"✅ 完整模型 -> {final_dir.resolve()}")
    print("下一步(用微调后模型重算 KG 余弦, 复用 16 号):")
    print(f"  python scripts/16_clip_score.py --data merged --splits val test \\")
    print(f"      --prompts {args.prompts} --out outputs/kg_scores_lora \\")
    print(f"      --model-path \"{final_dir.resolve()}\" --device 0 --batch 64")
    print("  python scripts/17_fuse_branches.py --weights <best.pt> \\")
    print("      --kg outputs/kg_scores_lora --out outputs/fusion_lora --imgsz 224 \\")
    print("      --skip-yolo --vis-cache outputs/fusion")


if __name__ == "__main__":
    main()
