#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
08_extract_pestinfo.py
从「棉花病虫害知识图谱构建数据集_信息表_扩充版.xlsx」抽取指定字段，形成产物。

抽取字段（按需求）：
    序号 | 棉花病虫害名称 | 别名 | 为害部位 | 为害症状 | 害虫形态

产物（同一份数据，两种格式）：
    outputs/病虫害信息抽取_6字段.xlsx   # 可直接打开/交人
    outputs/病虫害信息抽取_6字段.json   # 供程序/NLP 语料使用

用法：
    python scripts/08_extract_pestinfo.py \
        [--src kg_data/v3_合并全量/棉花病虫害知识图谱构建数据集_信息表_扩充版.xlsx] \
        [--out-xlsx outputs/病虫害信息抽取_6字段.xlsx] \
        [--out-json outputs/病虫害信息抽取_6字段.json]

说明：
    - 源表是 87 行扁平大表（30 病害 + 55 虫害 + 2 生理病害）。
    - 「害虫形态」列在病害/生理病害行为空属正常（32 行空），虫害行才有内容；
      空值在 Excel 产物中显示为空、在 JSON 产物中为 ""。
    - 字段内多值用「、」「；」等分隔，这里保持原文不拆分（需要拆词可后续在 NLP 层做）。
"""
import argparse
import json
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

# 需要抽取的列（表头名）。顺序即产物列序。
WANT_COLS = ["序号", "棉花病虫害名称", "别名", "为害部位", "为害症状", "害虫形态"]


def read_source(src: Path):
    """读源表，返回 (表头list, 数据行list[list])。只取 WANT_COLS 涉及的列。"""
    wb = openpyxl.load_workbook(src, read_only=True, data_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    header = list(next(rows))
    # 定位列索引（按表头名精确匹配，避免列序变化导致错位）
    idx = {}
    for col in WANT_COLS:
        if col not in header:
            raise SystemExit(f"源表缺少列：{col}；实际表头：{header}")
        idx[col] = header.index(col)

    data = []
    for r in rows:
        if r is None or all(v is None or str(v).strip() == "" for v in r):
            continue  # 跳过空行
        record = []
        for col in WANT_COLS:
            v = r[idx[col]]
            record.append("" if v is None else str(v).strip())
        data.append(record)
    wb.close()
    return WANT_COLS, data


def write_xlsx(header, data, out: Path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "病虫害信息"

    # 表头样式
    head_fill = PatternFill("solid", fgColor="1F6F4A")
    head_font = Font(bold=True, color="FFFFFF", size=11)
    for c, name in enumerate(header, start=1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.fill = head_fill
        cell.font = head_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

    # 数据
    for ri, record in enumerate(data, start=2):
        for ci, val in enumerate(record, start=1):
            cell = ws.cell(row=ri, column=ci, value=val)
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    # 列宽
    widths = {"序号": 6, "棉花病虫害名称": 16, "别名": 22,
              "为害部位": 26, "为害症状": 60, "害虫形态": 60}
    for c, name in enumerate(header, start=1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width = widths.get(name, 20)
    ws.freeze_panes = "A2"  # 冻结表头
    ws.auto_filter.ref = ws.dimensions  # 加筛选

    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)


def write_json(header, data, out: Path):
    records = []
    for record in data:
        obj = dict(zip(header, record))
        # 序号转 int（失败则保留原字符串）
        try:
            obj["序号"] = int(obj["序号"])
        except (ValueError, TypeError):
            pass
        records.append(obj)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    return records


def main():
    ap = argparse.ArgumentParser(description="从扩充版信息表抽取 6 个字段")
    ap.add_argument("--src", default="kg_data/v3_合并全量/棉花病虫害知识图谱构建数据集_信息表_扩充版.xlsx",
                    help="源 xlsx 路径")
    ap.add_argument("--out-xlsx", default="outputs/病虫害信息抽取_6字段.xlsx")
    ap.add_argument("--out-json", default="outputs/病虫害信息抽取_6字段.json")
    args = ap.parse_args()

    src = Path(args.src)
    if not src.exists():
        raise SystemExit(f"找不到源文件：{src.resolve()}")

    header, data = read_source(src)
    print(f"读取源表：{src}")
    print(f"共 {len(data)} 条记录，抽取字段：{header}")

    write_xlsx(header, data, Path(args.out_xlsx))
    records = write_json(header, data, Path(args.out_json))

    # 统计
    has_morph = sum(1 for r in records if r.get("害虫形态"))
    print(f"  其中「害虫形态」非空 {has_morph} 条（虫害），空 {len(records) - has_morph} 条（病害/生理）")
    print(f"产物：\n  {Path(args.out_xlsx).resolve()}\n  {Path(args.out_json).resolve()}")

    # 预览前 2 条
    print("\n预览：")
    for r in records[:2]:
        print(f"  [{r['序号']}] {r['棉花病虫害名称']} | 别名:{r['别名'] or '—'} | "
              f"部位:{r['为害部位'][:30]} | 形态:{(r['害虫形态'] or '—')[:30]}")


if __name__ == "__main__":
    main()
