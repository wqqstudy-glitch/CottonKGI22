#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
07_query_kg.py
实体链接之后的知识图谱查询: 给定 kg_id (或名称), 返回防治方法、药剂、症状、
发生时期、为害部位、天敌等问答系统所需信息。

两种数据源:
  A. 直接读 v3 合并全量 Excel (离线, 无需图数据库): --kg-dir ../augmented/v3_合并全量
  B. 查 Neo4j (部署后): --neo4j bolt://user:pass@host:7687

用法:
  python 07_query_kg.py --kg-dir ../augmented/v3_合并全量 --id 20002
  python 07_query_kg.py --kg-dir ../augmented/v3_合并全量 --name 绿盲蝽
  python 07_query_kg.py --kg-dir ../augmented/v3_合并全量 --linking outputs/linking_result.json
"""
import argparse
import json
from pathlib import Path

import openpyxl


def load_entity_table(path, name_col=2):
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    next(rows)
    return {r[0]: r[name_col] for r in rows if r[0] is not None}  # id -> name


def load_names(path, name_col=2):
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    next(rows)
    return {r[name_col]: r[0] for r in rows if r[0] is not None}  # name -> id


def load_rel(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    next(rows)
    return [(r[0], r[1], r[2]) for r in rows if r[1] is not None]


class KGExcel:
    """从 v3 Excel 读取的简易 KG 查询器。"""

    def __init__(self, kg_dir: Path):
        ent, rel = kg_dir / "实体", kg_dir / "关系"
        self.names = {}   # id -> name (全实体)
        self.type_of = {}  # id -> 表类型标签
        for f, label in [("Pestis.xlsx", "pest"), ("Disease.xlsx", "disease"),
                         ("Disorder.xlsx", "disorder"), ("Enemy.xlsx", "enemy")]:
            t = load_entity_table(ent / f)
            for i, n in t.items():
                self.names[i] = n
                self.type_of[i] = label
        # 属性实体
        self.attr = {}
        for f in ["Alias.xlsx", "Part.xlsx", "Symptom.xlsx", "Rule.xlsx",
                  "Method.xlsx", "Form.xlsx", "Agentia.xlsx", "Etiology.xlsx",
                  "Stage.xlsx", "Area.xlsx"]:
            p = ent / f
            if p.exists():
                for i, n in load_entity_table(p).items():
                    self.attr[i] = n
        # 关系: (关系名, start, end)
        self.rels = []
        for p in rel.glob("*.xlsx"):
            self.rels += load_rel(p)

    def resolve(self, eid=None, name=None):
        if eid is not None:
            return int(eid)
        if name is not None:
            for i, n in self.names.items():
                if n == name:
                    return i
            # 别名
            alias = load_names(self._ent_dir() / "Alias.xlsx") if False else None
        return None

    def _ent_dir(self):
        return None

    def query(self, eid):
        eid = int(eid)
        out = {
            "kg_id": eid,
            "name": self.names.get(eid),
            "entity_type": self.type_of.get(eid),
            "aliases": [], "parts": [], "symptoms": [], "stages": [],
            "methods": [], "agentia": [], "rules": [], "etiquette": [],
            "enemies": [], "areas": [], "forms": [],
        }
        bucket = {
            "别名": "aliases", "危害部位": "parts", "危害症状": "symptoms",
            "发生时期": "stages", "防治方法": "methods", "防治药剂": "agentia",
            "发病规律": "rules", "害虫形态": "forms", "分布区域": "areas",
        }
        for rname, s, e in self.rels:
            if s == eid and rname in bucket:
                val = self.attr.get(e, str(e))
                if val not in out[bucket[rname]]:
                    out[bucket[rname]].append(val)
        # 天敌 (Enemy_Pest: 天敌->害虫)
        if self.type_of.get(eid) == "pest":
            for rname, s, e in self.rels:
                if e == eid and self.type_of.get(s) == "enemy":
                    nm = self.names.get(s)
                    if nm and nm not in out["enemies"]:
                        out["enemies"].append(nm)
        # 致病原 (病害)
        for rname, s, e in self.rels:
            if s == eid and rname == "棉花病害致病原":
                val = self.attr.get(e, str(e))
                if val not in out["etiquette"]:
                    out["etiquette"].append(val)
        return out


def format_answer(q):
    lines = [f"【{q['name']}】(kg_id={q['kg_id']}, 类型={q['entity_type']})"]
    if q["aliases"]:
        lines.append(f"  别名: {'、'.join(q['aliases'])}")
    if q["symptoms"]:
        lines.append(f"  危害症状: {'；'.join(q['symptoms'][:6])}")
    if q["parts"]:
        lines.append(f"  为害部位: {'、'.join(q['parts'])}")
    if q["stages"]:
        lines.append(f"  发生时期: {'、'.join(q['stages'])}")
    if q["etiquette"]:
        lines.append(f"  致病原: {'、'.join(q['etiquette'])}")
    if q["methods"]:
        lines.append(f"  防治方法: {'；'.join(q['methods'][:8])}")
    if q["agentia"]:
        lines.append(f"  防治药剂(有效成分): {'、'.join(q['agentia'][:10])}")
    if q["enemies"]:
        lines.append(f"  天敌: {'、'.join(q['enemies'])}")
    if q["rules"]:
        lines.append(f"  发生规律: {'；'.join(q['rules'][:4])}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kg-dir", required=True, help="v3_合并全量 目录")
    ap.add_argument("--id", type=int, default=None)
    ap.add_argument("--name", default=None)
    ap.add_argument("--linking", default=None, help="04脚本输出的 linking_result.json, 查询其 top1")
    args = ap.parse_args()

    kg = KGExcel(Path(args.kg_dir))

    targets = []
    if args.linking:
        data = json.loads(Path(args.linking).read_text(encoding="utf-8"))
        top = data.get("top1")
        if top:
            targets.append(top["kg_id"])
    if args.id is not None:
        targets.append(args.id)
    if args.name:
        eid = kg.resolve(name=args.name)
        if eid:
            targets.append(eid)
        else:
            print(f"未找到实体: {args.name}")
    for eid in dict.fromkeys(targets):
        print(format_answer(kg.query(eid)))
        print()


if __name__ == "__main__":
    main()
