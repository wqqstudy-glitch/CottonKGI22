# -*- coding: utf-8 -*-
"""
22_near_duplicate_dedup.py
端到端近重复去重「发现 + 复核 + 报告」器（只读，不删图、不训练、不物化）。

与 stage5 的差别（stage5 只复核别人给的候选，召回受 stage4 限制）：
  A. 自己全量发现候选：
       1) MD5 字节级精确分组（同文件）；
       2) pHash 感知哈希（抗缩放/压缩/轻微改动）+ 4x16 位 LSH 分桶粗召回，
          桶内对再算真实汉明距离，按距离分层：很近直接强候选，较远进 SIFT。
  B. 多判据确认：SIFT + Lowe ratio + RANSAC 几何验证（高精度）；
       低纹理图 SIFT 关键点不足时，用「pHash 很近 + 少量几何内点/关键点极少」兜底。
  C. 连通分量内「全连接复核」：对分量内所有未直接验证的节点对强制补验，
       用复核后仍成立的边重建分量（可能分裂），消除单条误判边的「连坐」。
  D. 决策：
       - 最终分量含多个标签 -> EXCLUDE_ALL（标签冲突，不主观改标）；
       - 单一标签 -> test > val > train，同级取像素面积大者，再取路径字典序。
  E. 报告：before/after（类别 x split）、移除明细、冲突分量、clean_plan.csv、
       summary.json、可读「变化报告.txt」，并为冲突/大分量生成 montage 拼图。

安全：
  - 不修改/删除/移动任何原图；不启动训练；不复制数据集。
  - 产物全部写到一个新的评审文件夹，最后打一个 upload zip。

依赖：pip install pandas numpy pillow opencv-python
用法（Windows）：
  cd /d F:\wqq\CottonInsect
  python cotton_kg\vision\scripts\22_near_duplicate_dedup.py --img-dir merged
  # 也可在 merged_clean 上跑：--img-dir merged_clean --out-tag from_clean
"""
from __future__ import print_function

import argparse
import json
import os
import zipfile
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from PIL import Image, ImageOps, ImageDraw

# ---------------- 阈值（可命令行覆盖） ----------------
PHASH_CAND = 12      # LSH 桶内对：汉明距离 <= 此值才进入后续判定
PHASH_NEAR = 6      # <= 此值：即使 SIFT 不达标，也允许弱几何/低纹理兜底
PHASH_TIGHT = 4     # <= 此值：强 pHash 一致

SIFT_GOOD = 10
SIFT_INLIER = 8
SIFT_RATIO = 0.65
SOFT_GOOD = 4       # 兜底用的弱几何门槛
SOFT_INLIER = 4
SOFT_RATIO = 0.5
LOW_KP = 20         # 双方关键点都极少 -> 信任 pHash
NCC_MIN = 0.80      # 几何通过后，对齐灰度必须达到的光度一致性
COV_MIN = 0.50      # 主 SIFT 路线要求 A 变形后覆盖 B 的最小比例（挡"只匹配一小块重复纹理"）

MAX_SIDE = 1400     # SIFT 提特征时最长边限制
SPLIT_PRIORITY = {"test": 3, "val": 2, "train": 1}
SPLITS = ["train", "val", "test"]
IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


# ================= 扫描与基础签名 =================
def scan_tree(img_dir: Path):
    recs = []
    for sp in SPLITS:
        d = img_dir / sp
        if not d.is_dir():
            continue
        for cls in sorted(p for p in d.iterdir() if p.is_dir()):
            for f in sorted(p for p in cls.iterdir() if p.suffix.lower() in IMG_EXTS):
                recs.append({
                    "split": sp,
                    "label": cls.name,
                    "rel": f"{sp}/{cls.name}/{f.name}",
                    "abs": str(f),
                    "size": f.stat().st_size,
                })
    return recs


def md5_of(p):
    import hashlib
    h = hashlib.md5()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def phash_of(p):
    """64 位 pHash：灰度->32x32->DCT->左上8x8（去DC）->与中位数比较。返回 uint64。"""
    with Image.open(p) as im:
        im = ImageOps.exif_transpose(im).convert("L").resize((32, 32), Image.BILINEAR)
        x = np.asarray(im, dtype=np.float32)
    dct = cv2.dct(x)
    block = dct[:8, :8].flatten()
    med = np.median(block[1:])  # 排除 DC 分量
    bits = (block > med).astype(np.uint8)
    v = 0
    for b in bits:
        v = (v << 1) | int(b)
    return np.uint64(v)


def hamming(a_uint64, b_uint64):
    x = int(a_uint64) ^ int(b_uint64)
    return bin(x).count("1")


# ================= SIFT（懒加载缓存） =================
_sift_cache = {}


def sift_desc(abs_path):
    if abs_path in _sift_cache:
        return _sift_cache[abs_path]
    with Image.open(abs_path) as im:
        im = ImageOps.exif_transpose(im).convert("L")
        w, h = im.size
        sc = min(1.0, MAX_SIDE / float(max(w, h)))
        if sc < 1.0:
            new_w = max(1, int(round(w * sc)))
            new_h = max(1, int(round(h * sc)))
            im = im.resize((new_w, new_h), Image.BILINEAR)
        arr = np.asarray(im, dtype=np.uint8)
    sift = cv2.SIFT_create(nfeatures=2500)
    kp, desc = sift.detectAndCompute(arr, None)
    pts = [k.pt for k in (kp or [])]
    res = {"kp": 0 if kp is None else len(kp), "desc": desc,
           "pts": pts, "gray": arr, "wh": (w, h)}
    _sift_cache[abs_path] = res
    return res


def photometric_ncc(a, b, H):
    """把 a 用 H 变形对齐到 b，在重叠区域算零均值归一化互相关（0~1）。
    返回 (ncc, coverage)，coverage = A 变形后覆盖 B 面积的比例。
    覆盖率高 + NCC 高 = 整幅同图；覆盖率低 = 只对上一小块重复纹理。"""
    ga, gb = a["gray"], b["gray"]
    hb, wb = gb.shape
    try:
        warped = cv2.warpPerspective(ga, H, (wb, hb),
                                     flags=cv2.INTER_LINEAR,
                                     borderMode=cv2.BORDER_CONSTANT)
    except Exception:
        return 0.0, 0.0
    # 有效重叠掩码：a 变形后能覆盖到的区域
    ones = np.ones_like(ga, dtype=np.uint8)
    cover = cv2.warpPerspective(ones, H, (wb, hb),
                                flags=cv2.INTER_NEAREST,
                                borderMode=cv2.BORDER_CONSTANT)
    mask = cover > 0
    coverage = float(mask.sum()) / float(wb * hb)
    # 重叠太少（大面积裁剪）不足以做光度判定
    if int(mask.sum()) < 0.15 * wb * hb:
        return 0.0, coverage
    x = warped[mask].astype(np.float32)
    y = gb[mask].astype(np.float32)
    x -= x.mean(); y -= y.mean()
    denom = float(np.sqrt((x * x).sum() * (y * y).sum()))
    if denom < 1e-6:
        return 0.0, coverage
    return float((x * y).sum() / denom), coverage


def sift_verify(rec_a, rec_b):
    a = sift_desc(rec_a["abs"]); b = sift_desc(rec_b["abs"])
    d1, d2 = a["desc"], b["desc"]
    out = {"kp_a": a["kp"], "kp_b": b["kp"], "good": 0,
           "inliers": 0, "ratio": 0.0, "ncc": 0.0, "coverage": 0.0,
           "wa": a["wh"][0], "ha": a["wh"][1],
           "wb": b["wh"][0], "hb": b["wh"][1], "_H": None}
    if d1 is None or d2 is None or len(d1) < 2 or len(d2) < 2:
        return out
    knn = cv2.BFMatcher(cv2.NORM_L2).knnMatch(d1, d2, k=2)
    good = []
    for pair in knn:
        if len(pair) != 2:
            continue
        m, nn = pair
        if m.distance < 0.75 * nn.distance:
            good.append(m)
    inliers = 0; ratio = 0.0; H = None
    if len(good) >= 4:
        pts1 = a["pts"]; pts2 = b["pts"]
        src = np.float32([pts1[m.queryIdx] for m in good]).reshape(-1, 1, 2)
        dst = np.float32([pts2[m.trainIdx] for m in good]).reshape(-1, 1, 2)
        H, mask = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
        if mask is not None:
            inliers = int(mask.ravel().sum())
            ratio = float(inliers / max(1, len(good)))
    ncc = 0.0; coverage = 0.0
    if H is not None and inliers >= SIFT_INLIER:
        ncc, coverage = photometric_ncc(a, b, H)
    out.update({"good": len(good), "inliers": inliers,
                "ratio": round(ratio, 4), "ncc": round(ncc, 4),
                "coverage": round(coverage, 4), "_H": H})
    return out


_kp_coords_cache = {}


def _kp_coords(abs_path):
    """兼容保留：直接从 SIFT 缓存返回关键点坐标。"""
    return sift_desc(abs_path)["pts"]


# ================= 图算法 =================
def components_from_edges(n, edges):
    adj = defaultdict(set)
    for a, b in edges:
        adj[a].add(b); adj[b].add(a)
    seen = set(); comps = []
    for s in range(n):
        if s in seen:
            continue
        stack = [s]; seen.add(s); c = []
        while stack:
            x = stack.pop(); c.append(x)
            for y in adj[x]:
                if y not in seen:
                    seen.add(y); stack.append(y)
        comps.append(sorted(c))
    return comps


# ================= montage =================
def make_montage(recs, idxs, kept_set, title, out_png, thumb=160):
    pad = 8; cap_h = 30
    n = len(idxs); cols = min(4, n)
    rows = int(np.ceil(n / float(cols)))
    W = cols * (thumb + pad) + pad
    H = rows * (thumb + cap_h + pad) + pad + 24
    canvas = Image.new("RGB", (W, H), "white")
    dr = ImageDraw.Draw(canvas)
    dr.text((pad, 4), title, fill="black")
    for k, i in enumerate(idxs):
        r = recs[i]
        try:
            with Image.open(r["abs"]) as im:
                im = ImageOps.exif_transpose(im).convert("RGB")
                im.thumbnail((thumb, thumb))
                x = pad + (k % cols) * (thumb + pad)
                y = 24 + pad + (k // cols) * (thumb + cap_h + pad)
                canvas.paste(im, (x, y))
                tag = "KEEP" if i in kept_set else "EXCLUDE"
                dr.text((x, y + thumb + 2),
                        "#%d %s %s" % (i, r["split"], tag), fill="red" if tag == "EXCLUDE" else "green")
        except Exception:
            pass
    canvas.save(out_png)


# ================= 主流程 =================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--img-dir", default="merged", help="输入 ImageFolder（含 train/val/test/<类>）")
    ap.add_argument("--out-root", default=None, help="评审文件夹输出根，默认=img-dir 的父目录")
    ap.add_argument("--out-tag", default="", help="输出文件夹名附加标记")
    ap.add_argument("--montage-min-size", type=int, default=3,
                    help="同类分量至少多大才生成 montage（跨标签冲突始终生成）")
    ap.add_argument("--no-montage", action="store_true")
    args = ap.parse_args()

    img_dir = Path(args.img_dir).resolve()
    if not img_dir.is_dir():
        raise FileNotFoundError(img_dir)
    out_root = Path(args.out_root) if args.out_root else img_dir.parent
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = "near_dup_review_%s%s" % (stamp, ("_" + args.out_tag) if args.out_tag else "")
    outdir = out_root / name
    outdir.mkdir(parents=True, exist_ok=False)
    mont_dir = outdir / "montages"; mont_dir.mkdir()

    print("[1/6] 扫描目录 ...")
    recs = scan_tree(img_dir)
    n = len(recs)
    print("    图片总数:", n)

    print("[2/6] MD5 精确分组 ...")
    md5_groups = defaultdict(list)
    md5_vals = []
    for i, r in enumerate(recs):
        m = md5_of(r["abs"]); md5_vals.append(m); md5_groups[m].append(i)

    print("[3/6] pHash 全量 + 分块精确汉明候选 ...")
    ph = np.array([int(phash_of(r["abs"])) for r in recs], dtype=np.uint64)

    pair_rows = []
    near_pairs = []          # 进入 SIFT/兜底判定的对 (i,j,dist)
    confirmed_edges = set()  # 最终确认边
    reasons = {}

    # 分块「全量两两」精确汉明距离，避免 LSH 分段匹配漏召回。
    # 13.6k 规模下每块只占十几 MB，距离 <= PHASH_CAND 才进入 SIFT。
    def find_candidate_pairs(ph_arr, max_dist, chunk=128):
        lut = np.zeros(65536, dtype=np.uint16)
        for v in range(65536):
            lut[v] = bin(v).count("1")
        N = len(ph_arr)
        res = []
        for s0 in range(0, N, chunk):
            a = ph_arr[s0:s0 + chunk].astype(np.uint64)[:, None]
            x = a ^ ph_arr[None, :].astype(np.uint64)
            cnt = (lut[x & 0xFFFF]
                   + lut[(x >> 16) & 0xFFFF]
                   + lut[(x >> 32) & 0xFFFF]
                   + lut[(x >> 48) & 0xFFFF])
            rr, cc = np.nonzero(cnt <= max_dist)
            for r, c in zip(rr.tolist(), cc.tolist()):
                i = s0 + r; j = c
                if j > i:
                    res.append((i, j, int(cnt[r, c])))
        return res

    near_pairs = find_candidate_pairs(ph, PHASH_CAND)
    print("    pHash 距离 <= %d 的候选对: %d" % (PHASH_CAND, len(near_pairs)))

    # MD5 同字节：组内全连接边，直接确认，不必 SIFT
    for m, lst in md5_groups.items():
        if len(lst) < 2:
            continue
        for a in range(len(lst)):
            for b in range(a + 1, len(lst)):
                x, y = sorted((lst[a], lst[b]))
                confirmed_edges.add((x, y)); reasons[(x, y)] = "md5_exact"

    print("[4/6] SIFT 精确确认（含低纹理兜底）... 需判定对:", len(near_pairs))
    # 只对涉及的图提 SIFT
    involved = set()
    for i, j, d in near_pairs:
        involved.add(i); involved.add(j)
    for t, i in enumerate(sorted(involved)):
        sift_desc(recs[i]["abs"])
        if (t + 1) % 200 == 0:
            print("    提特征 %d/%d" % (t + 1, len(involved)))

    def judge_pair(sv, d):
        """统一的近重复判定，返回 (ok, reason)。
        路线1（SIFT 主路线）：强几何 + 覆盖率 + 光度，三者都满足。
        路线2（弱几何+光度）：pHash 近，弱几何，且整幅光度一致。
        路线3（纯 pHash）：pHash 极紧，几何无法对齐（低纹理）时的退路。
        """
        photo_ok = (sv["ncc"] >= NCC_MIN and sv["coverage"] >= COV_MIN)
        soft_geo = (sv["good"] >= SOFT_GOOD and sv["inliers"] >= SOFT_INLIER
                    and sv["ratio"] >= SOFT_RATIO)
        low_texture = (sv["kp_a"] < LOW_KP and sv["kp_b"] < LOW_KP)
        strong_geo = (sv["good"] >= SIFT_GOOD and sv["inliers"] >= SIFT_INLIER
                      and sv["ratio"] >= SIFT_RATIO)
        if strong_geo and photo_ok:
            return True, "sift+ncc"
        if d <= PHASH_NEAR and soft_geo and photo_ok:
            return True, "phash_near+softgeo+ncc"
        if d <= PHASH_TIGHT:
            if soft_geo and photo_ok:
                return True, "phash_tight+softgeo+ncc"
            if low_texture:
                return True, "phash_tight+lowtexture"
        return False, ""

    for i, j, d in near_pairs:
        sv = sift_verify(recs[i], recs[j])
        ok, why = judge_pair(sv, d)
        row = {"i": i, "j": j, "phash_dist": d,
               "good": sv["good"], "inliers": sv["inliers"], "ratio": sv["ratio"],
               "ncc": sv["ncc"], "coverage": sv["coverage"],
               "kp_a": sv["kp_a"], "kp_b": sv["kp_b"],
               "confirmed": ok, "reason": why}
        pair_rows.append(row)
        if ok:
            confirmed_edges.add((i, j)); reasons[(i, j)] = why

    print("[5/6] 连通分量 + 全连接复核 ...")
    comps = components_from_edges(n, confirmed_edges)
    multi = [c for c in comps if len(c) > 1]
    extra_check = 0
    for c in multi:
        S = set(c)
        for a in range(len(c)):
            for b in range(a + 1, len(c)):
                x, y = c[a], c[b]
                if (x, y) in confirmed_edges:
                    continue
                # 强制补验
                d = hamming(ph[x], ph[y])
                sv = sift_verify(recs[x], recs[y])
                ok, why = judge_pair(sv, d)
                if ok:
                    why = "fullcheck:" + why
                pair_rows.append({"i": x, "j": y, "phash_dist": d,
                                  "good": sv["good"], "inliers": sv["inliers"],
                                  "ratio": sv["ratio"], "ncc": sv["ncc"],
                                  "coverage": sv["coverage"],
                                  "kp_a": sv["kp_a"], "kp_b": sv["kp_b"],
                                  "confirmed": ok, "reason": why,
                                  "stage": "component_fullcheck"})
                extra_check += 1
                if ok:
                    confirmed_edges.add((x, y)); reasons[(x, y)] = why
    print("    补验对数:", extra_check)

    # 用复核后的边重建分量（可能分裂，消除连坐）
    comps = components_from_edges(n, confirmed_edges)

    print("[6/6] 决策、统计、montage ...")
    exclude = set()
    comp_rows = []; excl_rows = []; kept = set(range(n))
    montage_index = []

    for cid, c in enumerate(comps, start=1):
        if len(c) == 1:
            continue
        labels = sorted({recs[i]["label"] for i in c})
        splits = sorted({recs[i]["split"] for i in c})
        cross = len(labels) > 1
        if cross:
            decision = "EXCLUDE_ALL_LABEL_CONFLICT"; canonical = ""
            for i in c:
                exclude.add(i)
                excl_rows.append({"component_id": cid, "index": i,
                                  "split": recs[i]["split"], "label": recs[i]["label"],
                                  "rel": recs[i]["rel"], "reason": "cross_label_conflict",
                                  "canonical_rel": ""})
        else:
            decision = "KEEP_ONE"
            cands = []
            for i in c:
                fp = Path(recs[i]["abs"])
                try:
                    with Image.open(fp) as im:
                        w, h = im.size
                except Exception:
                    w = h = 0
                cands.append((i, SPLIT_PRIORITY.get(recs[i]["split"], 0), w * h, recs[i]["rel"]))
            cands.sort(key=lambda z: (-z[1], -z[2], z[3]))
            keep_i = cands[0][0]; canonical = recs[keep_i]["rel"]
            for i in c:
                if i == keep_i:
                    continue
                exclude.add(i)
                excl_rows.append({"component_id": cid, "index": i,
                                  "split": recs[i]["split"], "label": recs[i]["label"],
                                  "rel": recs[i]["rel"], "reason": "same_photo_duplicate",
                                  "canonical_rel": canonical})
        comp_rows.append({"component_id": cid, "n": len(c),
                          "labels": "|".join(labels), "splits": "|".join(splits),
                          "cross_label": cross, "decision": decision,
                          "canonical_rel": canonical})

        # montage
        need_montage = cross or (len(c) >= args.montage_min_size)
        if need_montage and not args.no_montage:
            kept_for_mont = set(c) - exclude
            tag = "conflict" if cross else "size%d" % len(c)
            mp = mont_dir / ("comp%03d_%s.png" % (cid, tag))
            make_montage(recs, c, kept_for_mont,
                         "comp %d %s" % (cid, tag), mp)
            montage_index.append({"component_id": cid, "cross_label": cross,
                                  "png": mp.name, "members": "|".join(recs[i]["rel"] for i in c)})

    # before / after
    before = defaultdict(int); after = defaultdict(int)
    for i, r in enumerate(recs):
        k = (r["label"], r["split"])
        before[k] += 1
        if i not in exclude:
            after[k] += 1
    keys = sorted(set(before) | set(after))
    ba = [{"label": k[0], "split": k[1], "before": before[k],
           "after": after[k], "removed": before[k] - after[k]} for k in keys]

    clean_rows = [r for i, r in enumerate(recs) if i not in exclude]

    # ---------------- 写文件 ----------------
    pd.DataFrame(pair_rows).to_csv(outdir / "pair_verification.csv",
                                   index=False, encoding="utf-8-sig")
    pd.DataFrame(comp_rows).to_csv(outdir / "components.csv",
                                   index=False, encoding="utf-8-sig")
    pd.DataFrame(excl_rows).to_csv(outdir / "excluded.csv",
                                   index=False, encoding="utf-8-sig")
    pd.DataFrame(ba).to_csv(outdir / "class_split_before_after.csv",
                            index=False, encoding="utf-8-sig")
    pd.DataFrame(montage_index).to_csv(outdir / "montages/montage_index.csv",
                                       index=False, encoding="utf-8-sig")
    cp = pd.DataFrame([{"split": r["split"], "target_class": r["label"],
                        "source_path": r["rel"]} for r in clean_rows])
    cp.to_csv(outdir / "clean_plan.csv", index=False, encoding="utf-8-sig")

    n_conflict = sum(1 for c in comp_rows if c["cross_label"])
    summary = {
        "img_dir": str(img_dir),
        "total_before": n,
        "total_after": len(clean_rows),
        "removed_total": len(exclude),
        "classes_before": len({r["label"] for r in recs}),
        "classes_after": len({r["label"] for r in clean_rows}),
        "confirmed_pairs": len([r for r in pair_rows if r.get("confirmed")]),
        "duplicate_components": len(comp_rows),
        "cross_label_conflict_components": n_conflict,
        "removed_by_reason": {
            "cross_label_conflict": sum(1 for x in excl_rows if x["reason"] == "cross_label_conflict"),
            "same_photo_duplicate": sum(1 for x in excl_rows if x["reason"] == "same_photo_duplicate"),
        },
        "montages": len(montage_index),
        "writes_to_original": False,
        "training_started": False,
    }
    (outdir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    # 可读变化报告
    lines = ["近重复去重变化报告", "=" * 40,
             "输入目录: %s" % img_dir,
             "样本: %d -> %d（移除 %d）" % (n, len(clean_rows), len(exclude)),
             "类别: %d -> %d" % (summary["classes_before"], summary["classes_after"]),
             "重复分量: %d，其中跨标签冲突分量: %d" % (len(comp_rows), n_conflict),
             "  冲突移除: %d 张；重复副本移除: %d 张" % (
                 summary["removed_by_reason"]["cross_label_conflict"],
                 summary["removed_by_reason"]["same_photo_duplicate"]),
             "", "按类别移除数量（仅列有变化的）:", "-" * 40]
    chg = defaultdict(int)
    for x in excl_rows:
        chg[x["label"]] += 1
    for lab in sorted(chg):
        lines.append("  %-20s -%d" % (lab, chg[lab]))
    lines += ["", "下一步：先看 montages/ 拼图（尤其 conflict 分量）人工核验；",
              "确认无误后可用 21_materialize_clean_plan.py 按本目录 clean_plan.csv 物化。"]
    (outdir / "变化报告.txt").write_text("\n".join(lines), encoding="utf-8")

    # zip
    zpath = out_root / (name + "_upload.zip")
    with zipfile.ZipFile(str(zpath), "w", zipfile.ZIP_DEFLATED) as zf:
        for p in outdir.rglob("*"):
            if p.is_file():
                zf.write(str(p), arcname=str(p.relative_to(outdir)))

    print("\nDONE")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("评审文件夹:", outdir)
    print("上传 ZIP:", zpath)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
