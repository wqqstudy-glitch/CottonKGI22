#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
01_export_kg_constraints.py
从 v3 合并全量知识图谱导出「视觉识别约束信息」，供实体链接层重排使用。

输出: outputs/kg_constraints.json
  每个病虫害实体一条记录:
  {
    "kg_id": 20002, "kg_name": "棉铃虫", "entity_type": "pest",
    "parts": ["蕾", "花", "棉铃", ...],        # 为害部位 (Part 4xxxx)
    "stages": ["蕾期", "花铃期", ...],          # 发生时期 (Stage 130xxx)
    "symptoms": ["...", ...],                   # 危害症状 (Symptom 5xxxx), 截断TopN
    "aliases": ["钻心虫", ...],                 # 别名
    "enemies": [120012, ...]                    # 天敌类群ID (仅虫害)
  }

用法:
  python 01_export_kg_constraints.py \
      --kg-dir ../augmented/v3_合并全量 \
      --out outputs/kg_constraints.json
"""
import argparse
import json
import sys
from pathlib import Path

import openpyxl


def load_entity_table(path: Path, name_col: int = 2):
    """读实体表 -> {name: id}。表头 :ID/:LABEL/name 三列。"""
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    next(rows)  # skip header
    return {r[name_col]: r[0] for r in rows if r[0] is not None}


def load_relation(path: Path):
    """读关系表 -> [(start_id, end_id)]。表头 relation/START_ID/END_ID。"""
    wb = openpyxl.load_workbook(path, read_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    next(rows)
    return [(r[1], r[2]) for r in rows if r[1] is not None and r[2] is not None]


def invert(mapping):
    """{name: id} -> {id: name}"""
    return {v: k for k, v in mapping.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kg-dir", required=True, help="v3_合并全量 目录(含 实体/ 关系/ 子目录)")
    ap.add_argument("--out", default="outputs/kg_constraints.json")
    ap.add_argument("--max-symptoms", type=int, default=8, help="每个实体保留的症状条数")
    args = ap.parse_args()

    kg = Path(args.kg_dir)
    ent_dir = kg / "实体"
    rel_dir = kg / "关系"

    # ---------- 实体表 ----------
    pest = load_entity_table(ent_dir / "Pestis.xlsx")          # 虫害 2xxxx
    disease = load_entity_table(ent_dir / "Disease.xlsx")      # 病害 1xxxx
    disorder = load_entity_table(ent_dir / "Disorder.xlsx")    # 生理性病害 140xxx
    enemy = load_entity_table(ent_dir / "Enemy.xlsx")          # 天敌 120xxx
    part = load_entity_table(ent_dir / "Part.xlsx")            # 部位 4xxxx
    stage = load_entity_table(ent_dir / "Stage.xlsx")          # 生育期 130xxx
    symptom = load_entity_table(ent_dir / "Symptom.xlsx")      # 症状 5xxxx
    alias = load_entity_table(ent_dir / "Alias.xlsx")          # 别名 3xxxx

    id2part = invert(part)
    id2stage = invert(stage)
    id2symptom = invert(symptom)
    id2alias = invert(alias)
    id2enemy = invert(enemy)

    # ---------- 目标实体注册表 ----------
    entities = {}  # kg_id -> record
    for name, eid in pest.items():
        entities[eid] = {"kg_id": eid, "kg_name": name, "entity_type": "pest",
                         "parts": [], "stages": [], "symptoms": [], "aliases": [], "enemies": []}
    for name, eid in disease.items():
        entities[eid] = {"kg_id": eid, "kg_name": name, "entity_type": "disease",
                         "parts": [], "stages": [], "symptoms": [], "aliases": [], "enemies": []}
    for name, eid in disorder.items():
        entities[eid] = {"kg_id": eid, "kg_name": name, "entity_type": "disorder",
                         "parts": [], "stages": [], "symptoms": [], "aliases": [], "enemies": []}

    def attach(rel_file, target_attr, id2name, valid_types=None):
        """把关系表 END_ID 对应的名称挂到 START_ID 实体的属性上。"""
        p = rel_dir / rel_file
        if not p.exists():
            print(f"[warn] 关系表不存在: {rel_file}", file=sys.stderr)
            return
        for sid, eid in load_relation(p):
            rec = entities.get(sid)
            if rec is None:
                continue
            if valid_types and rec["entity_type"] not in valid_types:
                continue
            name = id2name.get(eid)
            if name and name not in rec[target_attr]:
                rec[target_attr].append(name)

    # 为害部位
    attach("Pest_Part.xlsx", "parts", id2part)
    attach("Disease_Part.xlsx", "parts", id2part)
    attach("Disorder_Part.xlsx", "parts", id2part)
    # 发生时期
    attach("Pest_Stage.xlsx", "stages", id2stage)
    attach("Disease_Stage.xlsx", "stages", id2stage)
    attach("Disorder_Stage.xlsx", "stages", id2stage)
    # 症状
    attach("Pest_Symptom.xlsx", "symptoms", id2symptom)
    attach("Disease_Symptom.xlsx", "symptoms", id2symptom)
    attach("Disorder_Symptom.xlsx", "symptoms", id2symptom)
    # 别名
    attach("Pest_Alias.xlsx", "aliases", id2alias)
    attach("Disease_Alias.xlsx", "aliases", id2alias)
    attach("Disorder_Alias.xlsx", "aliases", id2alias)

    # 天敌: Enemy_Pest 关系为 天敌START -> 害虫END, 反向挂载
    ep = rel_dir / "Enemy_Pest.xlsx"
    if ep.exists():
        for enemy_id, pest_id in load_relation(ep):
            rec = entities.get(pest_id)
            if rec and enemy_id in id2enemy and enemy_id not in rec["enemies"]:
                rec["enemies"].append(enemy_id)

    # 症状截断
    for rec in entities.values():
        rec["symptoms"] = rec["symptoms"][: args.max_symptoms]

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(entities, f, ensure_ascii=False, indent=2)

    # 统计
    n_pest = sum(1 for r in entities.values() if r["entity_type"] == "pest")
    n_dis = sum(1 for r in entities.values() if r["entity_type"] == "disease")
    n_do = sum(1 for r in entities.values() if r["entity_type"] == "disorder")
    n_part = sum(1 for r in entities.values() if r["parts"])
    n_stage = sum(1 for r in entities.values() if r["stages"])
    print(f"导出实体: 虫害{n_pest} 病害{n_dis} 生理{n_do}, 共{len(entities)}")
    print(f"有部位约束: {n_part}, 有生育期约束: {n_stage}")
    print(f"输出: {out.resolve()}")


if __name__ == "__main__":
    main()
