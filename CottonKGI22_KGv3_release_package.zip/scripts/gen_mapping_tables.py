#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_mapping_tables.py
直接生成预计算好的多数据集→KG映射表 (无需数据集文件)
输出:
  - all_datasets_mapping.json  (训练用)
  - mapping_review.csv          (人工审查)
  - mapping_summary.txt         (摘要)
"""
import json
import csv
from pathlib import Path

OUTPUT_DIR = Path("outputs/mapping")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ── CottonInsect 13 类 ─
COTTONINSECT = {
    "lacewing":     {"kg_id": 120002, "kg_name": "草蛉类",     "entity_type": "enemy",      "zh": "草蛉",         "note": "天敌(益虫)", "confidence": 1.0},
    "ladybug_dy":   {"kg_id": 120001, "kg_name": "瓢虫类",     "entity_type": "enemy",      "zh": "瓢虫(多异?)",  "note": "天敌; 种名dy待核实, 类群级映射安全", "confidence": 1.0},
    "ladybug_lbq":  {"kg_id": 120001, "kg_name": "瓢虫类",     "entity_type": "enemy",      "zh": "瓢虫(种待核)",  "note": "天敌; lbq中文名待核实", "confidence": 1.0},
    "ladybug_hb":   {"kg_id": 120001, "kg_name": "瓢虫类",     "entity_type": "enemy",      "zh": "横斑瓢虫",     "note": "天敌; hb=横斑", "confidence": 1.0},
    "stinkbug_mx":  {"kg_id": 20032,  "kg_name": "苜蓿盲蝽",   "entity_type": "pest",       "zh": "苜蓿盲蝽",     "note": "", "confidence": 1.0},
    "stinkbug_mc":  {"kg_id": 20042,  "kg_name": "牧草盲蝽",   "entity_type": "pest",       "zh": "牧草盲蝽",     "note": "", "confidence": 1.0},
    "stinkbug_lv":  {"kg_id": 20009,  "kg_name": "绿盲蝽",     "entity_type": "pest",       "zh": "绿盲蝽",       "note": "", "confidence": 1.0},
    "stinkbug_hsy": {"kg_id": None,   "kg_name": None,         "entity_type": "unverified", "zh": "黑食蚜盲蝽",   "note": "分类存疑: 食蚜盲蝽属多为天敌, 需植保核实", "confidence": 0.0},
    "stinkbug_ccc": {"kg_id": None,   "kg_name": None,         "entity_type": "other",      "zh": "茶翅蝽",       "note": "果树/蔬菜害虫, 不在KG 87种内", "confidence": 0.0},
    "stinkbug_zh":  {"kg_id": 20010,  "kg_name": "中黑盲蝽",   "entity_type": "pest",       "zh": "中黑盲蝽",     "note": "", "confidence": 1.0},
    "syrphid":      {"kg_id": 120003, "kg_name": "食蚜蝇类",   "entity_type": "enemy",      "zh": "食蚜蝇",       "note": "天敌; 幼虫捕食蚜虫", "confidence": 1.0},
    "bollworm":     {"kg_id": 20002,  "kg_name": "棉铃虫",     "entity_type": "pest",       "zh": "棉铃虫",       "note": "", "confidence": 1.0},
    "bee":          {"kg_id": None,   "kg_name": None,         "entity_type": "other",      "zh": "蜂类(蜜蜂?)",  "note": "传粉昆虫; 若为寄生蜂→天敌120012/120013", "confidence": 0.0},
}

# ── Cotton Leaf Disease 7 类 ──
COTTON_DISEASE = {
    "Bacterial Blight":         {"kg_id": 10005, "kg_name": "棉角斑病",     "entity_type": "disease", "zh": "棉角斑病",     "note": "细菌性角斑病→棉角斑病", "confidence": 1.0},
    "Cotton Leaf Curl Disease": {"kg_id": 10019, "kg_name": "棉花曲叶病",   "entity_type": "disease", "zh": "棉花曲叶病",   "note": "棉曲叶病毒→棉花曲叶病", "confidence": 1.0},
    "Target Spot":              {"kg_id": None,  "kg_name": None,           "entity_type": "other",   "zh": "靶斑病",       "note": "KG无此病害实体, 建议新建或标other", "confidence": 0.0},
    "Red Leaf Spot":            {"kg_id": None,  "kg_name": None,           "entity_type": "uncertain","zh": "红叶斑(症状)", "note": "可能是棉红叶枯病(10015)症状, 需植保核实", "confidence": 0.5},
    "Leaf Mottle":              {"kg_id": None,  "kg_name": None,           "entity_type": "uncertain","zh": "叶斑驳(症状)", "note": "症状描述非病害名, 可能对应棉黄萎病(10007)或曲叶病(10019)", "confidence": 0.3},
    "Herbicide Damage":         {"kg_id": None,  "kg_name": None,           "entity_type": "other",   "zh": "除草剂药害",   "note": "非病虫害, KG无对应", "confidence": 0.0},
    "Healthy":                  {"kg_id": None,  "kg_name": None,           "entity_type": "healthy", "zh": "健康",         "note": "健康样本, 无KG映射", "confidence": 0.0},
}

# ── IP102 棉花相关子集 (13 类) ──
IP102_COTTON = {
    "0_Leaf Miner":          {"kg_id": 20036, "kg_name": "美洲斑潜蝇", "entity_type": "pest", "zh": "美洲斑潜蝇", "note": "Leaf Miner≈美洲斑潜蝇", "confidence": 0.85},
    "1_Army Worm":           {"kg_id": 20015, "kg_name": "斜纹夜蛾",   "entity_type": "pest", "zh": "斜纹夜蛾",   "note": "Army Worm泛称, 可能对应斜纹夜蛾", "confidence": 0.7},
    "2_Bollworm":            {"kg_id": 20002, "kg_name": "棉铃虫",     "entity_type": "pest", "zh": "棉铃虫",     "note": "Bollworm=棉铃虫", "confidence": 1.0},
    "6_Semilooper":          {"kg_id": 20003, "kg_name": "棉小造桥虫", "entity_type": "pest", "zh": "棉小造桥虫", "note": "Semilooper≈造桥虫", "confidence": 0.8},
    "9_Tobacco Caterpillar": {"kg_id": 20014, "kg_name": "甜菜夜蛾",   "entity_type": "pest", "zh": "甜菜夜蛾",   "note": "Tobacco Caterpillar=甜菜夜蛾", "confidence": 0.95},
    "16_Red Cotton Bug":     {"kg_id": 20037, "kg_name": "棉二点红蝽", "entity_type": "pest", "zh": "棉二点红蝽", "note": "Red Cotton Bug≈棉二点红蝽", "confidence": 0.9},
    "17_Cotton Stainer":     {"kg_id": 20037, "kg_name": "棉二点红蝽", "entity_type": "pest", "zh": "棉二点红蝽", "note": "Cotton Stainer≈棉二点红蝽", "confidence": 0.85},
    "18_Jassids":            {"kg_id": 20008, "kg_name": "棉叶蝉",     "entity_type": "pest", "zh": "棉叶蝉",     "note": "Jassids=叶蝉科", "confidence": 0.95},
    "19_Thrips":             {"kg_id": 20053, "kg_name": "烟蓟马",     "entity_type": "pest", "zh": "烟蓟马",     "note": "Thrips泛称, 棉花上主为烟蓟马", "confidence": 0.75},
    "24_White Fly":          {"kg_id": 20046, "kg_name": "烟粉虱",     "entity_type": "pest", "zh": "烟粉虱",     "note": "White Fly=烟粉虱/棉粉虱", "confidence": 1.0},
    "32_Spider Mite":        {"kg_id": 20047, "kg_name": "朱砂叶螨",   "entity_type": "pest", "zh": "朱砂叶螨",   "note": "Spider Mite泛称, 棉花上主为朱砂叶螨", "confidence": 0.75},
    "33_Aphids":             {"kg_id": 20001, "kg_name": "棉蚜",       "entity_type": "pest", "zh": "棉蚜",       "note": "Aphids泛称, 棉花上主为棉蚜", "confidence": 0.85},
    "34_Mealybug":           {"kg_id": 20029, "kg_name": "扶桑绵粉蚧", "entity_type": "pest", "zh": "扶桑绵粉蚧", "note": "Mealybug泛称", "confidence": 0.7},
}

# ── PlantVillage 棉花子集 (2 类) ──
PLANTVILLAGE_COTTON = {
    "Cotton___bacterial_blight":  {"kg_id": 10005, "kg_name": "棉角斑病",   "entity_type": "disease", "zh": "棉角斑病",   "note": "细菌性角斑病", "confidence": 1.0},
    "Cotton___leaf_curl_disease": {"kg_id": 10019, "kg_name": "棉花曲叶病", "entity_type": "disease", "zh": "棉花曲叶病", "note": "棉花曲叶病毒病", "confidence": 1.0},
}

# ── 组装输出 ──
all_data = {
    "CottonInsect": COTTONINSECT,
    "CottonLeafDisease": COTTON_DISEASE,
    "IP102_cotton_subset": IP102_COTTON,
    "PlantVillage_cotton_subset": PLANTVILLAGE_COTTON,
}

# JSON
json_out = {
    "version": "1.0",
    "kg_total_entities": 87,
    "kg_entity_range": {"disease": "10001-10030", "pest": "20001-20055", "disorder": "10086-10087", "enemy": "120001+"},
    "description": "多数据集类别→KG 87实体统一映射表。match_type=predefined为人工预定义; confidence≥0.9可直接使用; <0.9需人工核实; kg_id=None为未映射。",
    "datasets": {ds: {cls: {k: v for k, v in info.items()} for cls, info in m.items()} for ds, m in all_data.items()}
}
json_path = OUTPUT_DIR / "all_datasets_mapping.json"
json_path.write_text(json.dumps(json_out, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"✅ JSON → {json_path}")

# CSV
csv_path = OUTPUT_DIR / "mapping_review.csv"
with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["dataset", "class_name", "kg_id", "kg_name", "entity_type", "zh_name", "confidence", "note", "review_status"])
    rows = []
    for ds, m in all_data.items():
        for cls, info in m.items():
            kg_id_str = str(info["kg_id"]) if info["kg_id"] else ""
            if info["confidence"] >= 0.9:
                status = "✅ confirmed"
            elif info["kg_id"]:
                status = "⚠️ need_review"
            else:
                status = " unmapped/other"
            w.writerow([ds, cls, kg_id_str, info["kg_name"] or "", info["entity_type"], info["zh"], info["confidence"], info["note"], status])
            rows.append((ds, cls, kg_id_str, status))
print(f"✅ CSV → {csv_path}")

# Summary
total = sum(len(m) for m in all_data.values())
mapped = sum(1 for ds, m in all_data.items() for cls, info in m.items() if info["kg_id"])
confirmed = sum(1 for ds, m in all_data.items() for cls, info in m.items() if info["confidence"] >= 0.9)
need_review = sum(1 for ds, m in all_data.items() for cls, info in m.items() if info["kg_id"] and info["confidence"] < 0.9)
unmapped = total - mapped

txt_path = OUTPUT_DIR / "mapping_summary.txt"
with open(txt_path, "w", encoding="utf-8") as f:
    f.write(f"多数据集→KG统一映射摘要\n{'='*50}\n")
    f.write(f"KG 实体总数: 87 (病害30 + 虫害55 + 非生物2)\n")
    f.write(f"映射总条目: {total}\n已映射: {mapped} ({mapped/total*100:.1f}%)\n")
    f.write(f"  高置信(≥0.9)可直接用: {confirmed}\n  需人工核实: {need_review}\n")
    f.write(f"未映射/other: {unmapped}\n\n")
    for ds, m in all_data.items():
        ds_mapped = sum(1 for v in m.values() if v["kg_id"])
        f.write(f"[{ds}] {ds_mapped}/{len(m)} 已映射\n")
        for cls, info in m.items():
            s = "✅" if info["confidence"]>=0.9 else ("⚠️" if info["kg_id"] else "❌")
            f.write(f"  {s} {cls} → KG-{info['kg_id'] or 'N/A'} {info['zh']} [{info['entity_type']}]\n")
        f.write("\n")
print(f"✅ 摘要 → {txt_path}")
print(f"\n{'='*50}")
print(f"总计: {mapped}/{total} 已映射 | {confirmed} 高置信 | {need_review} 待核实 | {unmapped} 未映射")
