#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
15_build_prompts.py  (v2)
面向「零样本 CLIP 在细粒度害虫上近乎失效」重做 prompt 策略。

v1 的问题:
  - 主句是"成虫微距照片", 但数据里大量是幼虫/若虫、危害状、叶片特写 -> 图文错配
  - 充满"革片/楔形斑/小盾片刻点"等解剖学术语, CLIP 图文对里几乎没见过
  - 22 类近缘种(夜蛾团/盲蝽团)措辞高度同质, 余弦挤在一起 (std 仅 0.043)

v2 策略:
  1. 主句改用肉眼可见的通俗线索: 颜色 / 体型大小 / 聚生方式 / 蜡粉 / 丝网 / 飞行姿态
  2. 显式覆盖多个虫态与画面: 成虫、幼虫/若虫、危害症状、叶片/蕾铃特写 (对齐全数据)
  3. 近缘种加"区分"prompt, 拉开易混类 (夜蛾团、盲蝽团、叶蝉vs烟粉虱vs蚜虫)
  4. 14 号图谱形态降级为辅助"详细鉴别"prompt, 不再当主句
人工校订表 CUES 覆盖 22 类; 生成后仍输出 prompts.txt 供抽查。

用法:
  python scripts/15_build_prompts.py \
      --morph outputs/morphology/morphology.json \
      --kg outputs/kg_constraints.json \
      --link merged/kg_link.json \
      --out outputs/kg_prompts/prompts_v2
"""
import argparse
import json
import sys
from pathlib import Path

MAX_CHARS = 64

# ---------------------------------------------------------------------------
# 人工校订的「肉眼可见」特征表 (通俗词, 对应田间实拍画面)
# adult    : 成虫肉眼可见特征 (颜色/体型/蜡粉/聚集/姿态)
# young    : 幼虫/若虫画面 (None=此类数据基本以成虫为主或不强调)
# damage   : 危害状 (植株上肉眼可见, 不含减产等不可见后果)
# where    : 主要拍摄部位
# contrast : 与最易混近缘种的肉眼区分点
# ---------------------------------------------------------------------------
CUES = {
    "棉蚜": {
        "adult": ["嫩绿色或黑色的小虫子", "密密麻麻聚集在嫩尖和叶背", "有的长透明翅膀有的无翅", "虫体小而柔软"],
        "young": None,
        "damage": "嫩叶卷曲皱缩，叶面有黏腻蜜露",
        "where": "棉花嫩尖和嫩叶背面",
        "contrast": "比烟粉虱颜色深、不会一碰成片飞散",
    },
    "棉铃虫": {
        "adult": ["黄褐色的蛾子", "前翅有几条暗色横纹和肾形小斑"],
        "young": "肥大多肉的青绿色或红褐色毛虫，钻入棉蕾和青铃里取食",
        "damage": "棉蕾青铃上有圆形蛀孔，洞口有颗粒状虫粪",
        "where": "棉花蕾和青铃",
        "contrast": "幼虫钻蛀在蕾铃内部，不在叶片上爬",
    },
    "棉小造桥虫": {
        "adult": ["金黄色小蛾子", "前翅外端有一块暗褐色斑"],
        "young": "细长的绿色青虫，走路像量尺一样一弓一伸",
        "damage": "叶片被啃食成缺刻和孔洞，常只留叶脉",
        "where": "棉花叶片",
        "contrast": "幼虫只有腹末两对腹足，行走弓背呈造桥状",
    },
    "棉叶蝉": {
        "adult": ["淡绿色的小蝉", "头尖、翅膀收拢像小楔子", "受惊会快速横行或跳走"],
        "young": None,
        "damage": "叶片边缘变黄白再变红褐色，向下卷缩",
        "where": "棉花叶片背面",
        "contrast": "绿色尖头善跳跃，不是白色粉状的烟粉虱",
    },
    "绿盲蝽": {
        "adult": ["通体绿色的扁平小蝽", "身体长椭圆形、浅绿色半透明"],
        "young": None,
        "damage": "顶芽嫩叶出现黑色小点，叶片展开后破碎成破叶",
        "where": "棉花顶芽和嫩头",
        "contrast": "全身纯绿无纵纹，区别于背上有黑纹的中黑盲蝽",
    },
    "中黑盲蝽": {
        "adult": ["黄褐色的小蝽", "身体正中有一条明显的黑色纵纹"],
        "young": None,
        "damage": "嫩头和幼蕾出现黑点、干枯脱落",
        "where": "棉花顶芽和幼蕾",
        "contrast": "黄褐体色加一条黑背线，区别于纯绿的绿盲蝽",
    },
    "甜菜夜蛾": {
        "adult": ["灰褐色的小蛾子", "前翅外缘有一排深色小点"],
        "young": "绿色到黑褐色毛虫，体侧有一条明显的黄白色纵线",
        "damage": "低龄幼虫群集叶背拉丝结网，啃食叶肉留窗纸",
        "where": "棉花叶片背面",
        "contrast": "幼虫体侧黄白线、会结网群聚，区别于斜纹夜蛾",
    },
    "斜纹夜蛾": {
        "adult": ["灰褐色蛾子", "前翅中部有三条醒目的白色斜纹"],
        "young": "头部黑褐色的大毛虫，体背两侧各有一排黑色三角形斑",
        "damage": "叶片被暴食成大片缺刻，常成群聚集",
        "where": "棉花叶片",
        "contrast": "幼虫体背有成对三角形黑斑，区别于甜菜夜蛾",
    },
    "小地老虎": {
        "adult": ["暗褐色粗壮蛾子", "前翅有肾形和环形暗斑"],
        "young": "黑褐色粗大的地蚕，白天蜷在幼苗根部土表",
        "damage": "幼苗靠近地面的茎被咬断，整株倒伏",
        "where": "棉花幼苗茎基部和土表",
        "contrast": "幼虫在地表咬断幼苗，不在地上叶片取食",
    },
    "扶桑绵粉蚧": {
        "adult": ["椭圆形扁平小虫", "全身覆盖厚厚的白色蜡粉", "腹后拖着白色棉絮状卵囊", "成群堆在茎和叶背"],
        "young": None,
        "damage": "茎叶上成片白色棉絮状物，植株长势衰弱",
        "where": "棉花茎秆和叶背",
        "contrast": "白色蜡粉加棉絮卵囊堆集成片，不像散飞的烟粉虱",
    },
    "苜蓿盲蝽": {
        "adult": ["黄褐色小蝽", "前胸背面有两个明显的黑色圆点"],
        "young": None,
        "damage": "嫩头幼蕾出现黑点、焦枯",
        "where": "棉花嫩头和花蕾",
        "contrast": "黄褐色加前胸两个黑点，区别于绿色盲蝽",
    },
    "美洲斑潜蝇": {
        "adult": ["黄黑相间的小蝇", "体长很小、腹部黑色"],
        "young": "极小的黄白色蛆虫，在叶片上下表皮之间钻蛀",
        "damage": "叶片上有弯弯曲曲的白色蛇形隧道，像鬼画符",
        "where": "棉花叶片内部",
        "contrast": "标志性的白色弯曲虫道，别的害虫没有",
    },
    "棉二点红蝽": {
        "adult": ["身体红黑相间的长椭圆形蝽", "前翅革片中央各有一个大黑点", "常成群聚集"],
        "young": "红色和黑色相间的小若虫，成群活动",
        "damage": "群集在青铃上刺吸，铃面有斑点",
        "where": "棉花青铃",
        "contrast": "红黑配色加翅上一对黑点，颜色最醒目",
    },
    "牧草盲蝽": {
        "adult": ["绿色或黄绿色的小蝽", "身体短宽、颜色发绿"],
        "young": None,
        "damage": "嫩叶嫩蕾出现黑褐色小点、破损",
        "where": "棉花顶芽和嫩叶",
        "contrast": "短宽绿色，区别于有黑点或黑纹的其他盲蝽",
    },
    "烟粉虱": {
        "adult": ["极小的白色虫子像小飞蛾", "全身被白粉", "一碰叶片成群飞起", "密密停在叶背"],
        "young": None,
        "damage": "叶背成片白粉状小虫，叶面有蜜露和黑色煤污",
        "where": "棉花叶片背面",
        "contrast": "白色、一碰成群飞散，区别于绿蝉和黑绿蚜虫",
    },
    "朱砂叶螨": {
        "adult": ["针尖大的鲜红色小蜘蛛", "八条腿、在叶背活动", "叶背结有细密白色丝网"],
        "young": "淡红色或黄色的微小螨群集在丝网下",
        "damage": "叶片出现密集失绿小白点，后变红褐色锈斑",
        "where": "棉花叶片背面",
        "contrast": "红色小蜘蛛加白色丝网，肉眼可见红色小点",
    },
    "烟蓟马": {
        "adult": ["细长的淡黄色或棕色小虫", "身体窄长、末端尖", "在嫩叶和子叶上爬动很快"],
        "young": None,
        "damage": "子叶嫩叶出现成片银白色小斑点，叶片卷曲畸形",
        "where": "棉花子叶和嫩叶",
        "contrast": "体型极细长呈线状，不是圆形小虫",
    },
    "棉角斑病": {
        "adult": [],
        "young": None,
        "damage": "叶片上有受叶脉限制的多角形水浸状褐色病斑，后期变透明易破",
        "where": "棉花叶片和子叶",
        "contrast": "多角形水渍状褐斑，区别于卷曲皱缩的曲叶病",
    },
    "棉花曲叶病": {
        "adult": [],
        "young": None,
        "damage": "叶片增厚、向上卷曲皱缩，深浅黄绿相间，植株矮化",
        "where": "棉花整株上部叶片",
        "contrast": "整片叶卷曲增厚畸形，不是局部多角形病斑",
    },
    "瓢虫": {
        "adult": ["半球形圆滚滚的硬壳甲虫", "鞘翅红色或橙色带黑色斑点", "体表光滑有光泽"],
        "young": None,
        "damage": None,
        "where": "有蚜虫的棉花嫩头和叶背",
        "contrast": "益虫，圆背硬壳带斑点，会捕食蚜虫",
    },
    "草蛉": {
        "adult": ["身体嫩绿色细长柔弱", "翅膀宽大透明、翅脉像细密网", "眼睛有金属金色光泽"],
        "young": None,
        "damage": None,
        "where": "棉花叶片上",
        "contrast": "益虫，薄纱状大网翅和金色眼，不是害虫蛾子",
    },
    "食蚜蝇": {
        "adult": ["外形像蜜蜂", "腹部黄黑相间", "体表光滑无毛", "只有一对翅膀、能空中悬停"],
        "young": None,
        "damage": None,
        "where": "有蚜虫的棉花嫩头附近",
        "contrast": "益虫，像蜂但只有一对翅、会定点悬停",
    },
}


def split_frags(text: str):
    if not text:
        return []
    return [p.strip("，,。 ") for p in text.replace(";", "；").split("；") if p.strip("，,。 ")]


def clip_len(text: str, limit=MAX_CHARS):
    return text if len(text) <= limit else text[:limit - 1].rstrip("，,、") + "…"


def build(name, etype, cue, morph_frags):
    """按固定的 5 个 KG 视觉维度视角生成 prompt (每类 4~6 条):
       1 主体形态  2 危害部位  3 危害症状  4 田间场景  5 虫态 (+近缘种区分)
       各视角 embedding 在 16 号里平均归一, 等价于把结构化 KG 属性注入图文匹配。"""
    P = []

    def add(t):
        t = clip_len(t.strip())
        if t and t not in P:
            P.append(t)

    adult = cue.get("adult") or []
    young = cue.get("young")
    damage = cue.get("damage")
    where = (cue.get("where") or "").replace("棉花", "", 1)  # 纯部位, 模板自带"棉花"
    contrast = cue.get("contrast")
    where = where or "植株"

    # ---------- 病害: 无虫体, 视角换成 症状/病位/病因/田间 ----------
    if etype in ("disease", "disorder"):
        # 1 症状主体(=形态视角)
        if damage:
            add(f"微距拍摄的棉花染病叶片，{damage}")
        # 2 发病部位
        add(f"棉花{where}上的{name}症状，典型发病状态")
        # 3 症状+病因
        if damage:
            add(f"棉花{damage}，由{name}引起")
        # 4 田间场景
        add(f"大田棉花植株上的{name}症状，自然光照拍摄")
        # 5 鉴别区分
        if contrast:
            add(f"{name}的识别要点：{contrast}")
        return P

    role = "天敌益虫" if etype == "enemy" else "害虫"

    # 视角1 主体形态: 颜色 + 体型/可见结构
    if adult:
        if len(adult) >= 2:
            add(f"微距拍摄的{name}成虫，{adult[0]}，{adult[1]}")
        else:
            add(f"微距拍摄的{name}成虫，{adult[0]}")
        # 若还有更细的可见线索, 补一条纯形态
        if len(adult) >= 3:
            add(f"微距拍摄的{name}，{adult[2]}")

    # 视角2 危害部位
    if etype == "enemy":
        add(f"棉花{where}上活动的{name}，捕食害虫的天敌益虫")
    else:
        add(f"棉花{where}上的{name}虫害，典型危害状态")

    # 视角3 危害症状 (+病因)
    if damage and etype != "enemy":
        sym = damage if damage.startswith("棉") else f"棉花{damage}"
        add(f"{sym}，由{name}危害造成")

    # 视角4 田间场景
    add(f"大田棉花{where}上的{name}群体，自然光照拍摄")

    # 视角5 虫态: 有幼虫描述则给幼虫, 否则给成虫典型形态
    if young:
        add(f"{name}幼虫，{young}，棉花{role}典型形态")
    elif adult:
        add(f"{name}成虫，{adult[0]}，棉花{role}典型形态")

    # 补充: 近缘种肉眼区分 (凑到第 6 条, 拉开易混类)
    if contrast and len(P) < 6:
        add(f"{name}的识别要点：{contrast}")

    return P


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--morph", default="outputs/morphology/morphology.json")
    ap.add_argument("--kg", default="outputs/kg_constraints.json")
    ap.add_argument("--link", default="merged/kg_link.json")
    ap.add_argument("--out", default="outputs/kg_prompts/prompts_v2")
    args = ap.parse_args()

    for p in (args.morph, args.link):
        if not Path(p).exists():
            print(f"❌ 找不到 {p}", file=sys.stderr); sys.exit(1)

    morph = {r["visual_class"]: r
             for r in json.loads(Path(args.morph).read_text(encoding="utf-8"))}
    link = json.loads(Path(args.link).read_text(encoding="utf-8"))

    out, txt = {}, []
    missing = []
    ordered = sorted(link.items(), key=lambda kv: kv[1]["class_index"])
    for name, info in ordered:
        kg_id = int(info["kg_id"])
        m = morph.get(name, {})
        etype = m.get("entity_type", info.get("entity_type"))
        cue = CUES.get(name)
        if cue is None:
            missing.append(name)
            cue = {"adult": [], "young": None, "damage": None,
                   "where": "", "contrast": None}
        frags = split_frags(m.get("morph_zh", ""))
        prompts = build(name, etype, cue, frags)
        out[name] = {"kg_id": kg_id, "entity_type": etype, "prompts": prompts}
        txt.append(f"### {name} ({kg_id} / {etype})  共{len(prompts)}条")
        txt.extend(f"  - {p}" for p in prompts)
        txt.append("")

    if missing:
        print(f"⚠ CUES 表缺少(已退化为仅图谱形态): {missing}")

    out_p = Path(args.out)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.with_suffix(".json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    out_p.with_suffix(".txt").write_text("\n".join(txt), encoding="utf-8")

    n = len(out)
    avg = sum(len(v["prompts"]) for v in out.values()) / n
    longest = max((len(p) for v in out.values() for p in v["prompts"]), default=0)
    print(f"✅ v2: {n} 类, 每类平均 {avg:.1f} 条 prompt, 最长 {longest} 字")
    print(f"   -> {out_p.with_suffix('.json').resolve()}")
    print(f"   -> {out_p.with_suffix('.txt').resolve()}")
    print("下一步(重算 CLIP, 输出到新目录做 A/B):")
    print("  python scripts/16_clip_score.py --data merged --splits val test \\")
    print("      --prompts outputs/kg_prompts/prompts_v2.json \\")
    print("      --out outputs/kg_scores_v2 --device 0 --batch 64")
    print("  python scripts/17_fuse_branches.py --weights <best.pt> \\")
    print("      --kg outputs/kg_scores_v2 --out outputs/fusion --imgsz 224 --skip-yolo")


if __name__ == "__main__":
    main()
