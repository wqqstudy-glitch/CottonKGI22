#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
export_split_manifests.py

在【本地】已物化的 CottonKGI-22 ImageFolder 目录上运行，导出 train/val/test
三张「相对路径 + 类别 + 类别索引」清单（CSV）。清单本身不含图片像素，可公开分发，
配合来源数据与 build 脚本即可复现实验所用的精确划分。

期望目录结构（由 21_materialize_clean_plan.py / 22_near_duplicate_dedup.py 产出）：
    <data_root>/train/<class>/<file>
    <data_root>/val/<class>/<file>
    <data_root>/test/<class>/<file>

用法：
    python export_split_manifests.py --data <data_root> \
        --class-indices ../class_indices/class_indices.json --out ../splits
校验（可选）：--expect 7088 1104 2941
"""
import argparse, json, csv
from pathlib import Path

IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="CottonKGI-22 ImageFolder 根目录")
    ap.add_argument("--class-indices", required=True, help="class_indices.json")
    ap.add_argument("--out", required=True, help="清单输出目录")
    ap.add_argument("--expect", nargs=3, type=int, default=None,
                    metavar=("N_TRAIN", "N_VAL", "N_TEST"),
                    help="期望的 train/val/test 数量，用于校验")
    args = ap.parse_args()

    data = Path(args.data)
    cidx = json.loads(Path(args.class_indices).read_text(encoding="utf-8"))
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)

    counts = {}
    for split in ["train", "val", "test"]:
        rows, n = [], 0
        sdir = data / split
        if not sdir.is_dir():
            raise SystemExit(f"找不到 {sdir}")
        for cls_dir in sorted(p for p in sdir.iterdir() if p.is_dir()):
            cls = cls_dir.name
            if cls not in cidx:
                raise SystemExit(f"类别 {cls} 不在 class_indices.json，请核对目录/索引版本")
            for f in sorted(cls_dir.rglob("*")):
                if f.suffix.lower() in IMG_EXT:
                    rows.append([str(f.relative_to(data)), cls, cidx[cls]])
                    n += 1
        with open(out/f"{split}_manifest.csv", "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow(["relative_path", "class_name", "class_index"])
            w.writerows(rows)
        counts[split] = n
        print(f"{split}: {n} 张 -> {out/(split+'_manifest.csv')}")

    if args.expect:
        got = [counts["train"], counts["val"], counts["test"]]
        if got != args.expect:
            raise SystemExit(f"数量不符: 实际 {got} 期望 {args.expect}")
        print("数量校验通过:", got)


if __name__ == "__main__":
    main()
