#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
16_clip_score.py
KG 语义分支: 用 Chinese-CLIP 对 val/test 每张图编码, 与 22 类「多 prompt 集成」的
平均文本特征算余弦相似度, 离线缓存为矩阵, 供 17 号融合脚本使用(本脚本不做 softmax,
温度标定统一在 17 号完成)。

依赖:
  pip install transformers torch pillow
  # 国内下载模型慢可先设镜像(当前 PowerShell):
  #   $env:HF_ENDPOINT="https://hf-mirror.com"

用法:
  python scripts/16_clip_score.py --data merged --splits val test \
      --prompts outputs/kg_prompts/prompts.json \
      --model OFA-Sys/chinese-clip-vit-base-patch16 \
      --out outputs/kg_scores --device 0 --batch 64
  # 只检查图片发现/类对齐, 不加载模型:
  python scripts/16_clip_score.py --data merged --collect-only
"""
import argparse
import json
import sys
from pathlib import Path

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def collect_images(split_dir: Path):
    """递归收集 split/<类名>/*.{jpg,...}; 返回 (paths, labels, classes_sorted)。"""
    classes = sorted([p.name for p in split_dir.iterdir() if p.is_dir()])
    paths, labels = [], []
    for ci, c in enumerate(classes):
        imgs = sorted([p for p in split_dir.joinpath(c).rglob("*")
                       if p.is_file() and p.suffix.lower() in IMG_EXTS])
        for p in imgs:
            paths.append(p)
            labels.append(ci)
    return paths, labels, classes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="merged", help="ImageFolder 根目录(含 train/val/test)")
    ap.add_argument("--splits", nargs="+", default=["val", "test"])
    ap.add_argument("--prompts", default="outputs/kg_prompts/prompts.json")
    ap.add_argument("--link", default="merged/kg_link.json",
                    help="用于校验 prompts 与视觉类一致")
    ap.add_argument("--class-indices", default="merged/class_indices.json",
                    help="权威类列顺序 {类名: index}")
    ap.add_argument("--model", default="OFA-Sys/chinese-clip-vit-base-patch16")
    ap.add_argument("--model-path", default=None,
                    help="本地模型目录或 .safetensors 文件路径(绕过 from_pretrained + torch 安全检查)")
    ap.add_argument("--out", default="outputs/kg_scores")
    ap.add_argument("--device", default="0", help="0 / cpu")
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--limit", type=int, default=0, help=">0 时每个 split 只取前 N 张(冒烟)")
    ap.add_argument("--collect-only", action="store_true", help="只盘点图片与类, 不加载模型")
    args = ap.parse_args()

    data = Path(args.data)
    prompts_doc = json.loads(Path(args.prompts).read_text(encoding="utf-8"))
    ci_path = Path(args.class_indices)
    if not ci_path.exists():  # 兜底: 从 kg_link 取顺序
        link = json.loads(Path(args.link).read_text(encoding="utf-8"))
        class_indices = {k: v["class_index"] for k, v in link.items()}
    else:
        class_indices = json.loads(ci_path.read_text(encoding="utf-8"))
    classes = [c for c, _ in sorted(class_indices.items(), key=lambda kv: kv[1])]

    # 校验 prompt 覆盖
    missing = [c for c in classes if c not in prompts_doc or not prompts_doc[c].get("prompts")]
    if missing:
        print(f"❌ 以下类缺少 prompt: {missing}", file=sys.stderr); sys.exit(1)

    # ---------- 只盘点 ----------
    if args.collect_only:
        for sp in args.splits:
            sd = data / sp
            if not sd.exists():
                print(f"[warn] 不存在 {sd}")
                continue
            paths, labels, cls = collect_images(sd)
            print(f"{sp}: {len(paths)} 张, {len(cls)} 类, 顺序对齐={cls == classes}")
            if cls != classes:
                print("   目录类序:", cls)
        print(f"类列顺序(22): {classes}")
        return

    # ---------- 依赖 ----------
    try:
        import numpy as np
        import torch
        from PIL import Image
        # transformers>=4.49 在 torch<2.6 时会因 CVE-2025-32434 直接禁止 torch.load,
        # 但 OFA-Sys/chinese-clip-vit-base-patch16 官方仓库只发布 pytorch_model.bin
        # (没有 safetensors)。这里加载的是 HuggingFace 官方可信权重, 在 import 模型类
        # 之前关掉这个"硬拦截", 让底层 torch.load(weights_only=True) 正常工作。
        import transformers.utils.import_utils as _tf_iu
        _tf_iu.check_torch_load_is_safe = lambda *a, **k: None
        from transformers import ChineseCLIPProcessor, ChineseCLIPModel
        import transformers.modeling_utils as _tf_mu
        if hasattr(_tf_mu, "check_torch_load_is_safe"):
            _tf_mu.check_torch_load_is_safe = lambda *a, **k: None
    except ImportError as e:
        print("缺少依赖, 请先安装:\n  pip install transformers torch pillow numpy", file=sys.stderr)
        print(f"原始错误: {e}", file=sys.stderr); sys.exit(1)

    device = ("cuda" if str(args.device) not in ("cpu", "-1") and torch.cuda.is_available()
              else "cpu")
    print(f"加载 Chinese-CLIP: {args.model}  ->  {device}")
    load_src = args.model
    if args.model_path:
        mp = Path(args.model_path)
        if not mp.exists():
            print(f"❌ --model-path 不存在: {mp}", file=sys.stderr); sys.exit(1)
        if mp.is_file():  # 传 safetensors/bin 文件 -> 提升到所在 snapshot 目录
            mp = mp.parent
        load_src = str(mp)
        print(f"[本地] {mp.resolve()}")
    else:
        print("[在线/缓存] 优先 safetensors, 否则官方 pytorch_model.bin (已放行 torch.load)")

    model = ChineseCLIPModel.from_pretrained(load_src, local_files_only=bool(args.model_path))
    model.to(device).eval()
    processor = ChineseCLIPProcessor.from_pretrained(load_src, local_files_only=bool(args.model_path))

    @torch.no_grad()
    def encode_texts(texts):
        tok = processor(text=texts, padding="max_length", max_length=64,
                        truncation=True, return_tensors="pt")
        out = model.get_text_features(**{k: v.to(device) for k, v in tok.items()})
        # transformers 在 config 异常时可能返回 BaseModelOutputWithPooling 对象
        if hasattr(out, "pooler_output") and out.pooler_output is not None:
            feat = out.pooler_output
        elif hasattr(out, "last_hidden_state"):
            feat = out.last_hidden_state[:, 0]
        else:
            feat = out
        return torch.nn.functional.normalize(feat.float(), dim=-1)

    @torch.no_grad()
    def encode_images(pil_imgs):
        inp = processor(images=pil_imgs, return_tensors="pt")
        out = model.get_image_features(pixel_values=inp["pixel_values"].to(device))
        if hasattr(out, "pooler_output") and out.pooler_output is not None:
            feat = out.pooler_output
        elif hasattr(out, "last_hidden_state"):
            feat = out.last_hidden_state[:, 0]
        else:
            feat = out
        return torch.nn.functional.normalize(feat.float(), dim=-1)

    # ---- 每类多 prompt 集成: 逐条编码 -> L2 归一 -> 类内平均 -> 再归一 ----
    print("编码 22 类文本 prompt (prompt ensemble) ...")
    text_centroids = []
    for c in classes:
        embs = encode_texts(prompts_doc[c]["prompts"])
        cen = torch.nn.functional.normalize(embs.mean(dim=0, keepdim=True), dim=-1)
        text_centroids.append(cen)
    text_mat = torch.cat(text_centroids, dim=0)   # [22, D]

    out_dir = Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)

    for sp in args.splits:
        sd = data / sp
        if not sd.exists():
            print(f"[warn] 跳过不存在的 {sd}"); continue
        paths, labels, cls = collect_images(sd)
        if cls != classes:
            print(f"❌ {sp} 目录类序与 class_indices 不一致, 中止以防列错位", file=sys.stderr)
            sys.exit(1)
        if args.limit:
            paths, labels = paths[:args.limit], labels[:args.limit]
        n = len(paths)
        print(f"\n[{sp}] {n} 张图, 开始编码 ...")
        cos = np.zeros((n, len(classes)), dtype="float32")
        for s in range(0, n, args.batch):
            batch_paths = paths[s:s + args.batch]
            imgs = [Image.open(p).convert("RGB") for p in batch_paths]
            ie = encode_images(imgs)                    # [b, D]
            sim = ie @ text_mat.T                        # 余弦(两侧已归一)
            cos[s:s + len(batch_paths)] = sim.cpu().numpy().astype("float32")
            done = min(s + args.batch, n)
            print(f"\r  {done}/{n}", end="", flush=True)
        print()

        y = np.asarray(labels, dtype="int64")
        pred = cos.argmax(axis=1)
        top1 = float((pred == y).mean())
        top5 = float(np.mean([y[i] in np.argsort(-cos[i])[:5] for i in range(n)]))
        # macro-F1（numpy 手算，不依赖 sklearn）
        K = len(classes)
        cm0 = np.zeros((K, K), dtype="float64")
        for t, p in zip(y, pred):
            cm0[t, p] += 1
        tp = np.diag(cm0)
        fp = cm0.sum(axis=0) - tp
        fn = cm0.sum(axis=1) - tp
        prec = tp / np.maximum(tp + fp, 1)
        rec  = tp / np.maximum(tp + fn, 1)
        f1c = 2 * prec * rec / np.maximum(prec + rec, 1e-12)
        macro_f1 = float(f1c.mean())
        print(f"[{sp}] Chinese-CLIP 零样本 Top-1 {top1:.4f} | Top-5 {top5:.4f} | macro-F1 {macro_f1:.4f}")

        # ---- 混淆矩阵 (行归一化, 中文字体) ----
        try:
            import matplotlib
            matplotlib.use("Agg"); import matplotlib.pyplot as plt
            import seaborn as sns
            for f in ["Microsoft YaHei","SimHei","PingFang SC","Heiti SC",
                      "WenQuanYi Zen Hei","Noto Sans CJK SC","Arial Unicode MS"]:
                try:
                    from matplotlib.font_manager import findfont, FontProperties
                    if findfont(FontProperties(family=f), fallback_to_default=False):
                        plt.rcParams["font.sans-serif"] = [f]; break
                except Exception: continue
            plt.rcParams["axes.unicode_minus"] = False
            cm = cm0  # 上面已用 numpy 构建的 K×K 计数矩阵
            cm_norm = cm.astype(float) / np.maximum(cm.sum(axis=1, keepdims=True), 1)
            fig, ax = plt.subplots(figsize=(14, 12))
            sns.heatmap(cm_norm, annot=True, fmt=".2f", cmap="Blues",
                        xticklabels=classes, yticklabels=classes,
                        vmin=0, vmax=1, cbar_kws={"label": "行归一化 Recall"}, ax=ax)
            ax.set_xlabel("Predicted"); ax.set_ylabel("True")
            ax.set_title(f"KG 零样本 Test 混淆矩阵 (行归一化)  Top1={top1:.3f} macroF1={macro_f1:.3f}")
            plt.tight_layout()
            cm_path = out_dir / f"kg_zero_shot_{sp}_confusion.png"
            fig.savefig(cm_path, dpi=200); plt.close(fig)
            print(f"  混淆矩阵 -> {cm_path.resolve()}")
        except Exception as e:
            print(f"  混淆矩阵绘制失败: {e}", file=sys.stderr)

        np.savez_compressed(
            out_dir / f"{sp}.npz",
            cosine=cos, y=y,
            files=np.asarray([str(p) for p in paths], dtype=object),
            classes=np.asarray(classes, dtype=object),
        )
        (out_dir / f"{sp}_meta.json").write_text(json.dumps({
            "split": sp, "model": args.model, "n_images": n, "n_classes": len(classes),
            "classes": classes,
            "prompts_per_class": {c: len(prompts_doc[c]["prompts"]) for c in classes},
            "clip_zero_shot_top1": round(top1, 4), "clip_zero_shot_top5": round(top5, 4),
            "note": "存原始余弦相似度; softmax/温度/融合在 17 号脚本完成",
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  已缓存 -> {(out_dir / (sp + '.npz')).resolve()}")

    print("\n完成。下一步用 17 号脚本读 YOLO 的 p_vis 与这里的余弦矩阵做温度标定+融合评估。")


if __name__ == "__main__":
    main()
