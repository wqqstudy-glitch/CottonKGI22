#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_unified_mapping.py
将多个棉花相关数据集的类别统一映射到 KG 87 个实体 ID。

支持数据集:
  1. CottonInsect_classification (13 类, 虫害+天敌)
  2. CottonInsect_detection     (同 13 类, 检测格式)
  3. Cotton Leaf Disease Detection Dataset (7 类病害)
  4. IP102                       (102 类害虫, 提取棉花相关)
  5. PlantVillage                (38 类, 提取棉花子集)

输出:
  outputs/mapping/all_datasets_mapping.json   — 训练用 JSON 配置
  outputs/mapping/mapping_review.xlsx         — 人工审查表
  outputs/mapping/mapping_summary.txt         — 文本摘要

用法:
  python build_unified_mapping.py --root /path/to/datasets [--kg-xlsx path] [--kg-constraints path]
"""
import argparse
import json
import csv
import sys
import re
import os
from pathlib import Path
from difflib import SequenceMatcher

# ─────────────────────────────────────────────
# 0. KG 87 实体全量数据 (来自 v3_合并全量 xlsx + kg_constraints.json)
# ─────────────────────────────────────────────

KG_ENTITIES = {
    # ===== 病害 (10001-10030) =====
    10001: {"name": "棉立枯病",     "type": "disease",   "aliases": ["黑根病", "烂根病"]},
    10002: {"name": "棉炭疽病",     "type": "disease",   "aliases": []},
    10003: {"name": "棉红腐病",     "type": "disease",   "aliases": ["烂根病"]},
    10004: {"name": "棉苗猝倒病",   "type": "disease",   "aliases": []},
    10005: {"name": "棉角斑病",     "type": "disease",   "aliases": ["角点病"]},
    10006: {"name": "棉枯萎病",     "type": "disease",   "aliases": ["萎蔫病", "乌心瘟"]},
    10007: {"name": "棉黄萎病",     "type": "disease",   "aliases": []},
    10008: {"name": "棉黑斑病",     "type": "disease",   "aliases": ["棉轮纹病"]},
    10009: {"name": "棉红粉病",     "type": "disease",   "aliases": []},
    10010: {"name": "棉曲霉病",     "type": "disease",   "aliases": []},
    10011: {"name": "棉铃疫病",     "type": "disease",   "aliases": []},
    10012: {"name": "棉花根结线虫病", "type": "disease", "aliases": []},
    10013: {"name": "棉白霉病",     "type": "disease",   "aliases": []},
    10014: {"name": "棉叶斑病",     "type": "disease",   "aliases": []},
    10015: {"name": "棉红叶枯病",   "type": "disease",   "aliases": []},
    10016: {"name": "棉花黑色根腐病", "type": "disease", "aliases": ["棉黑根病", "棉褐根病", "棉花根颈癌肿病"]},
    10017: {"name": "棉花白粉病",   "type": "disease",   "aliases": []},
    10018: {"name": "棉花细菌性烂铃病", "type": "disease", "aliases": []},
    10019: {"name": "棉花曲叶病",   "type": "disease",   "aliases": []},
    10020: {"name": "得克萨斯根腐病", "type": "disease", "aliases": []},
    10021: {"name": "棉花锈病",     "type": "disease",   "aliases": []},
    10022: {"name": "棉铃黑果病",   "type": "disease",   "aliases": []},
    10023: {"name": "棉铃灰霉病",   "type": "disease",   "aliases": []},
    10024: {"name": "棉铃软腐病",   "type": "disease",   "aliases": []},
    10025: {"name": "棉苗褐斑病",   "type": "disease",   "aliases": []},
    10026: {"name": "棉苗疫病",     "type": "disease",   "aliases": []},
    10027: {"name": "棉花早衰",     "type": "disease",   "aliases": []},
    10028: {"name": "棉茎枯病",     "type": "disease",   "aliases": []},
    10029: {"name": "棉花叶烧病",   "type": "disease",   "aliases": []},
    10030: {"name": "棉花白绢病",   "type": "disease",   "aliases": []},
    # ===== 虫害 (20001-20055) =====
    20001: {"name": "棉蚜",         "type": "pest",      "aliases": ["腻虫", "蜜虫", "油汗"]},
    20002: {"name": "棉铃虫",       "type": "pest",      "aliases": ["桃虫", "钻心虫"]},
    20003: {"name": "棉小造桥虫",   "type": "pest",      "aliases": ["棉夜蛾", "量地虫", "棉尺模", "驼桥虫"]},
    20004: {"name": "棉大造桥虫",   "type": "pest",      "aliases": ["棉叶尺蛾", "脚攀虫"]},
    20005: {"name": "棉大卷叶螟",   "type": "pest",      "aliases": ["棉卷叶虫", "包叶虫", "裹叶虫"]},
    20006: {"name": "银纹夜娥",     "type": "pest",      "aliases": ["菜步曲", "造桥虫", "弓弓虫"]},
    20007: {"name": "棉红铃虫",     "type": "pest",      "aliases": ["红虫", "花虫", "棉花蛆"]},
    20008: {"name": "棉叶蝉",       "type": "pest",      "aliases": ["棉叶跳虫", "棉浮尘子", "二点浮尘子"]},
    20009: {"name": "绿盲蝽",       "type": "pest",      "aliases": ["花叶虫", "小臭虫"]},
    20010: {"name": "中黑盲蝽",     "type": "pest",      "aliases": []},
    20011: {"name": "三点盲蝽",     "type": "pest",      "aliases": []},
    20012: {"name": "玉米螟",       "type": "pest",      "aliases": ["钻心虫", "钻茎虫"]},
    20013: {"name": "大袋蛾",       "type": "pest",      "aliases": ["大蓑蛾"]},
    20014: {"name": "甜菜夜蛾",     "type": "pest",      "aliases": []},
    20015: {"name": "斜纹夜蛾",     "type": "pest",      "aliases": ["莲纹夜蛾"]},
    20016: {"name": "鼎点金刚钻",   "type": "pest",      "aliases": []},
    20017: {"name": "翠纹金刚钻",   "type": "pest",      "aliases": ["绿带金刚钻"]},
    20018: {"name": "蜗牛",         "type": "pest",      "aliases": []},
    20019: {"name": "华北蝼蛄",     "type": "pest",      "aliases": []},
    20020: {"name": "棉尖象",       "type": "pest",      "aliases": []},
    20021: {"name": "小地老虎",     "type": "pest",      "aliases": ["士蚕", "切根虫"]},
    20022: {"name": "黄地老虎",     "type": "pest",      "aliases": []},
    20023: {"name": "大地老虎",     "type": "pest",      "aliases": []},
    20024: {"name": "红腹灯蛾",     "type": "pest",      "aliases": []},
    20025: {"name": "黄腹灯蛾",     "type": "pest",      "aliases": []},
    20026: {"name": "白星花金龟",   "type": "pest",      "aliases": ["白纹铜花金龟", "白星花潜", "白星金龟子", "铜克螂"]},
    20027: {"name": "斑须蝽",       "type": "pest",      "aliases": []},
    20028: {"name": "稻绿蝽",       "type": "pest",      "aliases": []},
    20029: {"name": "扶桑绵粉蚧",   "type": "pest",      "aliases": []},
    20030: {"name": "黑绒金龟子",   "type": "pest",      "aliases": ["天鹅绒金龟子", "东方金龟", "东方绢金龟"]},
    20031: {"name": "花蓟马",       "type": "pest",      "aliases": []},
    20032: {"name": "苜蓿盲蝽",     "type": "pest",      "aliases": []},
    20033: {"name": "黄伊缘蝽",     "type": "pest",      "aliases": []},
    20034: {"name": "灰巴蜗牛",     "type": "pest",      "aliases": []},
    20035: {"name": "蛞蝓",         "type": "pest",      "aliases": ["旱螺", "无壳蜓蛐螺", "黏液虫", "鼻涕虫"]},
    20036: {"name": "美洲斑潜蝇",   "type": "pest",      "aliases": []},
    20037: {"name": "棉二点红蝽",   "type": "pest",      "aliases": []},
    20038: {"name": "棉黑蚜",       "type": "pest",      "aliases": ["紫团蚜"]},
    20039: {"name": "棉花根结线虫", "type": "pest",      "aliases": []},
    20040: {"name": "棉蝗",         "type": "pest",      "aliases": []},
    20041: {"name": "棉长管蚜",     "type": "pest",      "aliases": ["棉无网长管蚜", "大棉蚜"]},
    20042: {"name": "牧草盲蝽",     "type": "pest",      "aliases": []},
    20043: {"name": "双斑长跗萤叶甲", "type": "pest",   "aliases": ["双斑萤叶甲"]},
    20044: {"name": "桃蚜",         "type": "pest",      "aliases": []},
    20045: {"name": "同型巴蜗牛",   "type": "pest",      "aliases": []},
    20046: {"name": "烟粉虱",       "type": "pest",      "aliases": ["棉粉虱", "甘薯粉虱"]},
    20047: {"name": "朱砂叶螨",     "type": "pest",      "aliases": []},
    20048: {"name": "截形叶螨",     "type": "pest",      "aliases": []},
    20049: {"name": "土耳其斯坦叶螨", "type": "pest",    "aliases": []},
    20050: {"name": "东方蝼蛄",     "type": "pest",      "aliases": ["非洲蝼蛄", "拉拉蛄", "地拉蛄", "土狗子"]},
    20051: {"name": "沟金针虫",     "type": "pest",      "aliases": ["沟叩头虫", "钢丝虫", "铁丝虫", "土蚰蜒"]},
    20052: {"name": "细胸金针虫",   "type": "pest",      "aliases": []},
    20053: {"name": "烟蓟马",       "type": "pest",      "aliases": ["棉蓟马", "葱蓟马"]},
    20054: {"name": "二斑叶螨",     "type": "pest",      "aliases": ["二点叶螨", "普通叶螨"]},
    20055: {"name": "蛴螬",         "type": "pest",      "aliases": ["白土蚕", "核桃虫", "地蚕"]},
    # ===== 非生物胁迫 (10086-10087) =====
    10086: {"name": "棉花缺钾症",   "type": "disorder",  "aliases": []},
    10087: {"name": "棉花缺硼症",   "type": "disorder",  "aliases": ["蕾而不花症", "棉花缺硼"]},
    # ===== 天敌类群 (120001+) =====
    120001: {"name": "瓢虫类",       "type": "enemy",     "aliases": []},
    120002: {"name": "草蛉类",       "type": "enemy",     "aliases": []},
    120003: {"name": "食蚜蝇类",     "type": "enemy",     "aliases": []},
}

# ────────────────────────────────────────────
# 1. 预定义 CottonInsect 13 类 → KG 映射 (来自 cottoninsect_mapping.json)
# ─────────────────────────────────────────────
COTTONINSECT_PREDEF = {
    "lacewing":     {"kg_id": 120002, "zh": "草蛉",        "type": "enemy",      "note": "天敌(益虫)"},
    "ladybug_dy":   {"kg_id": 120001, "zh": "瓢虫(多异?)",  "type": "enemy",      "note": "天敌; 种名待核实, 类群级映射安全"},
    "ladybug_lbq":  {"kg_id": 120001, "zh": "瓢虫(种待核)",  "type": "enemy",      "note": "天敌; lbq中文名待核实"},
    "ladybug_hb":   {"kg_id": 120001, "zh": "横斑瓢虫",    "type": "enemy",      "note": "天敌; hb=横斑"},
    "stinkbug_mx":  {"kg_id": 20032,  "zh": "苜蓿盲蝽",    "type": "pest",       "note": ""},
    "stinkbug_mc":  {"kg_id": 20042,  "zh": "牧草盲蝽",    "type": "pest",       "note": ""},
    "stinkbug_lv":  {"kg_id": 20009,  "zh": "绿盲蝽",      "type": "pest",       "note": ""},
    "stinkbug_hsy": {"kg_id": None,   "zh": "黑食蚜盲蝽",  "type": "unverified", "note": "分类存疑: 可能为捕食性天敌, 需植保核实"},
    "stinkbug_ccc": {"kg_id": None,   "zh": "茶翅蝽",      "type": "other",      "note": "果树/蔬菜害虫, 不在KG 87种内"},
    "stinkbug_zh":  {"kg_id": 20010,  "zh": "中黑盲蝽",    "type": "pest",       "note": ""},
    "syrphid":      {"kg_id": 120003, "zh": "食蚜蝇",      "type": "enemy",      "note": "天敌; 幼虫捕食蚜虫"},
    "bollworm":     {"kg_id": 20002,  "zh": "棉铃虫",      "type": "pest",       "note": ""},
    "bee":          {"kg_id": None,   "zh": "蜂类(蜜蜂?)",  "type": "other",      "note": "传粉昆虫; 若为寄生蜂→天敌120012/120013"},
}

# ────────────────────────────────────────────
# 2. Mendeley / Kaggle Cotton Leaf Disease 7 类 → KG 映射
# ────────────────────────────────────────────
COTTON_DISEASE_PREDEF = {
    "Bacterial Blight":       {"kg_id": 10005, "zh": "棉角斑病",   "type": "disease", "note": "细菌性角斑病 → 棉角斑病"},
    "Cotton Leaf Curl Disease": {"kg_id": 10019, "zh": "棉花曲叶病", "type": "disease", "note": "棉曲叶病毒 → 棉花曲叶病"},
    "Target Spot":            {"kg_id": None,  "zh": "靶斑病(非棉花?)", "type": "other", "note": "棉花数据集中出现, 但KG无此病害实体, 建议标记other或新建"},
    "Red Leaf Spot":          {"kg_id": None,  "zh": "红叶斑(症状?)", "type": "uncertain", "note": "可能是棉红叶枯病(10015)的症状表现, 也可能是独立病害, 需植保核实"},
    "Leaf Mottle":            {"kg_id": None,  "zh": "叶斑驳(症状?)", "type": "uncertain", "note": "症状描述非病害名, 可能对应棉黄萎病(10007)或棉花曲叶病(10019)的斑驳症状"},
    "Herbicide Damage":       {"kg_id": None,  "zh": "除草剂药害",  "type": "other", "note": "非病虫害, 属药害, KG无对应实体"},
    "Healthy":                {"kg_id": None,  "zh": "健康",        "type": "healthy", "note": "健康样本, 无KG映射"},
}

# ─────────────────────────────────────────────
# 3. IP102 102 类中棉花相关 → KG 映射 (手动预定义棉花相关子集)
# ────────────────────────────────────────────
IP102_COTTON_RELEVANT = {
    0:  {"en": "Leaf Miner",              "kg_id": 20036, "zh": "美洲斑潜蝇", "type": "pest",     "note": "叶矿害虫; IP102 Leaf Miner ≈ 美洲斑潜蝇"},
    1:  {"en": "Army Worm",               "kg_id": 20015, "zh": "斜纹夜蛾",   "type": "pest",     "note": "Army Worm 泛称, 可能对应斜纹夜蛾或甜菜夜蛾"},
    2:  {"en": "Bollworm",                "kg_id": 20002, "zh": "棉铃虫",     "type": "pest",     "note": "棉铃虫 = Bollworm"},
    6:  {"en": "Semilooper",              "kg_id": 20003, "zh": "棉小造桥虫", "type": "pest",     "note": "Semilooper ≈ 造桥虫"},
    9:  {"en": "Tobacco Caterpillar",     "kg_id": 20014, "zh": "甜菜夜蛾",   "type": "pest",     "note": "Tobacco Caterpillar = 甜菜夜蛾"},
    16: {"en": "Red Cotton Bug",          "kg_id": 20037, "zh": "棉二点红蝽", "type": "pest",     "note": "Red Cotton Bug ≈ 棉二点红蝽"},
    17: {"en": "Cotton Stainer",          "kg_id": 20037, "zh": "棉二点红", "type": "pest",     "note": "Cotton Stainer ≈ 棉二点红蝽"},
    18: {"en": "Jassids",                 "kg_id": 20008, "zh": "棉叶蝉",     "type": "pest",     "note": "Jassids = 叶蝉科"},
    19: {"en": "Thrips",                  "kg_id": 20053, "zh": "烟蓟马",     "type": "pest",     "note": "Thrips 泛称, 棉花上主要是烟蓟马/花蓟马"},
    24: {"en": "White Fly",               "kg_id": 20046, "zh": "烟粉虱",     "type": "pest",     "note": "White Fly = 烟粉虱/棉粉虱"},
    32: {"en": "Spider Mite",             "kg_id": 20047, "zh": "朱砂叶螨",   "type": "pest",     "note": "Spider Mite 泛称, 棉花上主要是朱砂叶螨/截形叶螨"},
    33: {"en": "Aphids",                  "kg_id": 20001, "zh": "棉蚜",       "type": "pest",     "note": "Aphids 泛称, 棉花上主要是棉蚜"},
    34: {"en": "Mealybug",                "kg_id": 20029, "zh": "扶桑绵粉蚧", "type": "pest",     "note": "Mealybug 泛称"},
    35: {"en": "Cutworm",                 "kg_id": 20021, "zh": "小地老虎",   "type": "pest",     "note": "Cutworm = 地老虎"},
    36: {"en": "Stem Weevil",             "kg_id": None,  "zh": "茎象甲(非KG)", "type": "other",  "note": "棉花茎象甲不在KG 87种内"},
    37: {"en": "Stink Bug",               "kg_id": None,  "zh": "蝽象(泛称)",  "type": "uncertain","note": "Stink Bug 泛称, 可能对应多种盲蝽"},
    # 其余 IP102 类别为非棉花害虫, 不映射
}

# ────────────────────────────────────────────
# 4. PlantVillage 38 类中棉花相关 → KG 映射
# ─────────────────────────────────────────────
PLANTVILLAGE_COTTON = {
    "Cotton___bacterial_blight":    {"kg_id": 10005, "zh": "棉角斑病",    "type": "disease", "note": "细菌性角斑病"},
    "Cotton___leaf_curl_disease":   {"kg_id": 10019, "zh": "棉花曲叶病",  "type": "disease", "note": "棉花曲叶病毒病"},
    # PlantVillage 其他 36 类为非棉花作物病害, 不映射到棉花 KG
}


# ─────────────────────────────────────────────
# 5. 模糊匹配工具
# ─────────────────────────────────────────────
def similarity(a: str, b: str) -> float:
    a, b = a.lower().strip(), b.lower().strip()
    if a == b:
        return 1.0
    if a in b or b in a:
        return 0.85
    return SequenceMatcher(None, a, b).ratio()


def find_best_match(class_name: str, kg_entities: dict, threshold: float = 0.6) -> dict:
    """对单个类别名在 KG 实体中找最佳匹配"""
    best_score = 0.0
    best_entity = None
    best_match_type = ""

    search_name = class_name.lower().strip()

    for kg_id, entity in kg_entities.items():
        # 精确匹配名称
        if search_name == entity["name"].lower():
            return {"kg_id": kg_id, "score": 1.0, "match_type": "exact_name", "entity": entity}

        # 精确匹配别名
        for alias in entity["aliases"]:
            if search_name == alias.lower():
                return {"kg_id": kg_id, "score": 1.0, "match_type": "exact_alias", "entity": entity}

        # 模糊匹配名称
        score = similarity(search_name, entity["name"].lower())
        if score > best_score:
            best_score = score
            best_entity = entity
            best_match_type = "fuzzy_name"

        # 模糊匹配别名
        for alias in entity["aliases"]:
            score = similarity(search_name, alias.lower())
            if score > best_score:
                best_score = score
                best_entity = entity
                best_match_type = "fuzzy_alias"

    if best_score >= threshold and best_entity:
        return {"kg_id": None, "score": round(best_score, 3), "match_type": best_match_type, "entity": best_entity}

    return {"kg_id": None, "score": round(best_score, 3), "match_type": "no_match", "entity": best_entity}


# ─────────────────────────────────────────────
# 6. 数据集类别加载
# ─────────────────────────────────────────────
def parse_class_token(line: str) -> str:
    """剥离行首序号，兼容 '1 lacewing' / '1_lacewing' / '1. lacewing' / 'lacewing' 等格式。"""
    token = line.strip()
    m = re.match(r'^\d+[\s_,\.\)\-]+(.+)$', token)
    if m:
        token = m.group(1).strip()
    return token


def _pick_name_side(items):
    """class_indices.json 可能是 {类名:序号} 也可能是 {序号:类名}。
    用预定义表探测哪一侧是真正的类名, 返回类名列表。"""
    keys = [parse_class_token(str(k)) for k in items.keys()]
    vals = [parse_class_token(str(v)) for v in items.values()]
    key_hit = sum(1 for k in keys if k in COTTONINSECT_PREDEF)
    val_hit = sum(1 for v in vals if v in COTTONINSECT_PREDEF)
    return keys if key_hit >= val_hit else vals


def load_cottoninsect_classes(root: Path) -> list:
    """读取 CottonInsect 13 个类 token, 智能处理 class_indices.json 方向与带序号 classes.txt"""
    ci_dir = root / "CottonInsect_classification"
    cj = ci_dir / "class_indices.json"
    if cj.exists():
        try:
            data = json.loads(cj.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data:
                toks = _pick_name_side(data)
                # 纯数字(序号)一侧不会命中预定义表; 只要有一个命中即采用
                if any(t in COTTONINSECT_PREDEF for t in toks):
                    return toks
            elif isinstance(data, list) and data:
                toks = [parse_class_token(str(v)) for v in data]
                if any(t in COTTONINSECT_PREDEF for t in toks):
                    return toks
        except Exception:
            pass
    ci_cls = ci_dir / "classes.txt"
    if ci_cls.exists():
        toks = [parse_class_token(line) for line in ci_cls.read_text(encoding="utf-8").splitlines() if line.strip()]
        if any(t in COTTONINSECT_PREDEF for t in toks):
            return toks
    return list(COTTONINSECT_PREDEF.keys())


# Cotton Leaf Disease 文件夹名的各种实际写法 → 预定义规范名
_CLD_ALIASES = {
    "bacterialblight": "Bacterial Blight",
    "bacterial": "Bacterial Blight",
    "cottonleafcurldisease": "Cotton Leaf Curl Disease",
    "curlvirus": "Cotton Leaf Curl Disease",
    "cottonleafcurlvirus": "Cotton Leaf Curl Disease",
    "leafcurldisease": "Cotton Leaf Curl Disease",
    "leafcurl": "Cotton Leaf Curl Disease",
    "curl": "Cotton Leaf Curl Disease",
    "targetspot": "Target Spot",
    "redleafspot": "Red Leaf Spot",
    "redleaf": "Red Leaf Spot",
    "leafmottle": "Leaf Mottle",
    "mottle": "Leaf Mottle",
    "herbicidedamage": "Herbicide Damage",
    "herbicide": "Herbicide Damage",
    "healthy": "Healthy",
}


def _norm_dirname(s: str) -> str:
    return re.sub(r'[^0-9a-z\u4e00-\u9fff]+', '', str(s).lower())


def load_cotton_disease_classes(root: Path) -> list:
    """递归发现 Cotton Leaf Disease 数据集下的类别文件夹（兼容 train/val、Original/Augmented 等任意嵌套与命名差异）"""
    base = root / "Cotton Leaf Disease Detection Dataset"
    if not base.exists():
        # 兼容直接把该数据集目录作为 --root
        base = root if (root / "Original Dataset").exists() or (root / "Augmented Dataset").exists() else None
    if base is None:
        return list(COTTON_DISEASE_PREDEF.keys())

    found = []
    seen = set()
    for d in base.rglob("*"):
        if not d.is_dir():
            continue
        key = _norm_dirname(d.name)
        canonical = _CLD_ALIASES.get(key)
        # 包含关系兜底（如目录名带额外后缀）
        if canonical is None:
            for alias, canon in _CLD_ALIASES.items():
                if len(alias) >= 5 and (alias in key or key in alias) and key:
                    canonical = canon
                    break
        if canonical and canonical not in seen:
            seen.add(canonical)
            found.append(canonical)

    if found:
        # 按预定义顺序输出
        ordered = [c for c in COTTON_DISEASE_PREDEF if c in seen]
        ordered += [c for c in found if c not in ordered]
        return ordered
    return list(COTTON_DISEASE_PREDEF.keys())


def load_ip102_classes(root: Path) -> list:
    """从 IP102 加载 102 类名"""
    # 尝试从 class_indices.json 或 train.txt 读取
    ip102_dir = root / "ip102_v1.1-002" / "ip102_v1.1"
    if not ip102_dir.exists():
        ip102_dir = root / "ip102_v1.1-002"
    class_indices = ip102_dir / "class_indices.json"
    if class_indices.exists():
        data = json.loads(class_indices.read_text(encoding="utf-8"))
        return [str(v) for v in data.values()] if isinstance(data, dict) else data
    # fallback: IP102 标准 102 类英文名
    return [f"class_{i}" for i in range(102)]


def load_plantvillage_classes(root: Path) -> list:
    """从 PlantVillage 加载类别 (目录名)"""
    pv_dir = root / "PlantVillage-Dataset-master"
    if not pv_dir.exists():
        pv_dir = root / "PlantVillage-Dataset-master" / "raw"
    if pv_dir.exists():
        # PlantVillage 的类别是 "Crop___Disease" 格式的目录名
        subdirs = sorted([d.name for d in pv_dir.iterdir() if d.is_dir() and "___" in d.name])
        if subdirs:
            return subdirs
    return list(PLANTVILLAGE_COTTON.keys())


# ─────────────────────────────────────────────
# 7. 主逻辑: 构建统一映射
# ────────────────────────────────────────────
def build_mapping(root: Path, output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)

    all_mappings = {}   # dataset_name -> {class_name -> mapping_info}
    review_rows = []    # for xlsx output

    # ─ 7.1 CottonInsect ─
    print("=" * 60)
    print("[1/4] CottonInsect (13 类)")
    print("=" * 60)
    ci_classes = load_cottoninsect_classes(root)
    ci_mapping = {}
    for cls in ci_classes:
        if cls in COTTONINSECT_PREDEF:
            info = COTTONINSECT_PREDEF[cls]
            ci_mapping[cls] = {
                "kg_id": info["kg_id"],
                "kg_name": KG_ENTITIES[info["kg_id"]]["name"] if info["kg_id"] and info["kg_id"] in KG_ENTITIES else None,
                "entity_type": info["type"],
                "zh_name": info["zh"],
                "match_type": "predefined",
                "score": 1.0,
                "note": info["note"],
            }
            kg_id_str = str(info['kg_id']) if info['kg_id'] else 'N/A'
            status = "✅" if info['kg_id'] else ("⚠️" if info['type'] == 'unverified' else "❌")
            print(f"  {status} {cls:20s} → KG-{kg_id_str:>6s} {info['zh']:12s} [{info['type']}]")
        else:
            result = find_best_match(cls, KG_ENTITIES)
            ci_mapping[cls] = {
                "kg_id": result["kg_id"],
                "kg_name": result["entity"]["name"] if result["entity"] else None,
                "entity_type": result["entity"]["type"] if result["entity"] else "unmapped",
                "zh_name": cls,
                "match_type": result["match_type"],
                "score": result["score"],
                "note": "auto_matched" if result["kg_id"] else "no_match",
            }
            status = "✅" if result["kg_id"] else "❌"
            kg_id_str = str(result['kg_id']) if result['kg_id'] else 'N/A'
            print(f"  {status} {cls:20s} → KG-{kg_id_str:>6s} score={result['score']:.2f}")
    all_mappings["CottonInsect"] = ci_mapping

    # ── 7.2 Cotton Leaf Disease ──
    print("\n" + "=" * 60)
    print("[2/4] Cotton Leaf Disease Detection (7 类)")
    print("=" * 60)
    cd_classes = load_cotton_disease_classes(root)
    cd_mapping = {}
    for cls in cd_classes:
        if cls in COTTON_DISEASE_PREDEF:
            info = COTTON_DISEASE_PREDEF[cls]
            cd_mapping[cls] = {
                "kg_id": info["kg_id"],
                "kg_name": KG_ENTITIES[info["kg_id"]]["name"] if info["kg_id"] and info["kg_id"] in KG_ENTITIES else None,
                "entity_type": info["type"],
                "zh_name": info["zh"],
                "match_type": "predefined",
                "score": 1.0,
                "note": info["note"],
            }
            kg_id_str = str(info['kg_id']) if info['kg_id'] else 'N/A'
            status = "✅" if info['kg_id'] else ("⚠️" if info['type'] == 'uncertain' else "❌")
            print(f"  {status} {cls:30s} → KG-{kg_id_str:>6s} {info['zh']:12s} [{info['type']}]")
        else:
            result = find_best_match(cls, KG_ENTITIES)
            cd_mapping[cls] = {
                "kg_id": result["kg_id"],
                "kg_name": result["entity"]["name"] if result["entity"] else None,
                "entity_type": result["entity"]["type"] if result["entity"] else "unmapped",
                "zh_name": cls,
                "match_type": result["match_type"],
                "score": result["score"],
                "note": "auto_matched" if result["kg_id"] else "no_match",
            }
            status = "✅" if result["kg_id"] else "❌"
            kg_id_str = str(result['kg_id']) if result['kg_id'] else 'N/A'
            print(f"  {status} {cls:30s} → KG-{kg_id_str:>6s} score={result['score']:.2f}")
    all_mappings["CottonLeafDisease"] = cd_mapping

    # ── 7.3 IP102 (棉花相关子集) ──
    print("\n" + "=" * 60)
    print("[3/4] IP102 (102 类 → 提取棉花相关)")
    print("=" * 60)
    ip102_mapping = {}
    for cls_idx, info in IP102_COTTON_RELEVANT.items():
        cls_key = str(cls_idx)
        kg_name = KG_ENTITIES[info["kg_id"]]["name"] if info["kg_id"] and info["kg_id"] in KG_ENTITIES else None
        ip102_mapping[cls_key] = {
            "kg_id": info["kg_id"],
            "kg_name": kg_name,
            "entity_type": info["type"],
            "zh_name": info["zh"],
            "en_name": info["en"],
            "match_type": "predefined",
            "score": 1.0,
            "note": info["note"],
        }
        status = "✅" if info["kg_id"] else "⚠️"
        kg_id_str = str(info['kg_id']) if info['kg_id'] else 'N/A'
        status = "✅" if info['kg_id'] else "⚠️"
        print(f"  {status} IP102#{cls_idx:3d} {info['en']:25s} → KG-{kg_id_str:>6s} {info['zh']}")
    all_mappings["IP102_cotton_subset"] = ip102_mapping

    # ── 7.4 PlantVillage (棉花子集) ──
    print("\n" + "=" * 60)
    print("[4/4] PlantVillage (38 类 → 提取棉花子集)")
    print("=" * 60)
    pv_mapping = {}
    for cls, info in PLANTVILLAGE_COTTON.items():
        kg_name = KG_ENTITIES[info["kg_id"]]["name"] if info["kg_id"] and info["kg_id"] in KG_ENTITIES else None
        pv_mapping[cls] = {
            "kg_id": info["kg_id"],
            "kg_name": kg_name,
            "entity_type": info["type"],
            "zh_name": info["zh"],
            "match_type": "predefined",
            "score": 1.0,
            "note": info["note"],
        }
        kg_id_str = str(info['kg_id']) if info['kg_id'] else 'N/A'
        print(f"  ✅ {cls:40s} → KG-{kg_id_str:>6s} {info['zh']}")
    all_mappings["PlantVillage_cotton_subset"] = pv_mapping

    # ── 8. 输出 JSON ──
    json_path = output_dir / "all_datasets_mapping.json"
    output = {
        "version": "1.0",
        "kg_total_entities": len(KG_ENTITIES),
        "description": "多数据集类别 → KG 87 实体统一映射表",
        "datasets": {}
    }
    for ds_name, mapping in all_mappings.items():
        output["datasets"][ds_name] = {}
        for cls_name, info in mapping.items():
            output["datasets"][ds_name][cls_name] = {
                "kg_id": info["kg_id"],
                "kg_name": info["kg_name"],
                "entity_type": info["entity_type"],
                "zh_name": info["zh_name"],
                "match_type": info["match_type"],
                "confidence": info["score"],
                "note": info["note"],
            }
            # 收集审查行
            review_rows.append({
                "dataset": ds_name,
                "class_name": cls_name,
                "kg_id": info["kg_id"] or "",
                "kg_name": info["kg_name"] or "",
                "entity_type": info["entity_type"],
                "zh_name": info["zh_name"],
                "match_type": info["match_type"],
                "confidence": info["score"],
                "note": info["note"],
                "review_status": "✅ confirmed" if info["score"] >= 0.9 else ("⚠️ need_review" if info["kg_id"] else "❌ unmapped"),
            })

    json_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n📄 JSON 映射表 → {json_path}")

    # ── 9. 输出 CSV 审查表 ──
    csv_path = output_dir / "mapping_review.csv"
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["dataset", "class_name", "kg_id", "kg_name", "entity_type", "zh_name", "match_type", "confidence", "note", "review_status"])
        writer.writeheader()
        writer.writerows(review_rows)
    print(f"📄 CSV 审查表 → {csv_path}")

    # ── 10. 输出摘要 ──
    summary_path = output_dir / "mapping_summary.txt"
    total = len(review_rows)
    mapped = sum(1 for r in review_rows if r["kg_id"])
    confirmed = sum(1 for r in review_rows if r["confidence"] >= 0.9)
    need_review = sum(1 for r in review_rows if 0.6 <= r["confidence"] < 0.9)
    unmapped = sum(1 for r in review_rows if not r["kg_id"])

    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"多数据集→KG统一映射摘要\n")
        f.write(f"{'='*50}\n")
        f.write(f"KG 实体总数: {len(KG_ENTITIES)}\n")
        f.write(f"映射总条目: {total}\n")
        f.write(f"已映射: {mapped} ({mapped/total*100:.1f}%)\n")
        f.write(f"  - 高置信 (≥0.9): {confirmed}\n")
        f.write(f"  - 需人工核实: {need_review}\n")
        f.write(f"未映射/other: {unmapped}\n\n")

        for ds_name, mapping in all_mappings.items():
            ds_mapped = sum(1 for v in mapping.values() if v["kg_id"])
            ds_total = len(mapping)
            f.write(f"[{ds_name}] {ds_mapped}/{ds_total} 已映射\n")
            for cls, info in mapping.items():
                status = "✅" if info["kg_id"] and info["score"] >= 0.9 else ("⚠️" if info["kg_id"] else "❌")
                f.write(f"  {status} {cls} → KG-{info['kg_id'] or 'N/A'} {info['zh_name']} [{info['entity_type']}]\n")
            f.write("\n")

    print(f" 摘要 → {summary_path}")
    print(f"\n{'='*50}")
    print(f"✅ 映射完成! {mapped}/{total} 类已映射到 KG 实体")
    print(f"⚠️  {need_review} 条需人工核实, {unmapped} 条未映射")

    return output


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="多数据集→KG 87实体 统一映射")
    ap.add_argument("--root", required=True, help="数据集根目录 (含 CottonInsect_classification, ip102_v1.1-002 等)")
    ap.add_argument("--output", default="outputs/mapping", help="输出目录 (默认 outputs/mapping)")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    output_dir = Path(args.output).resolve()

    if not root.exists():
        print(f"❌ 数据集根目录不存在: {root}", file=sys.stderr)
        sys.exit(1)

    build_mapping(root, output_dir)
