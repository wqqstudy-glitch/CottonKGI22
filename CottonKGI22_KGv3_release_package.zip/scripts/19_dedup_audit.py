# -*- coding: utf-8 -*-
"""
④ 数据集去重审计（内容级）
对合并后的 merged 目录，按图片文件"完整字节 MD5"做去重核验，输出：
  - 总图片数、唯一 MD5 数、重复组数、被删除/保留的重复明细
  - 按 split（train/val/test）分别统计，检查跨 split 泄漏
用法（在本地 CottonInsect 项目根目录）：
  python scripts/19_dedup_audit.py --merged merged --out outputs/dedup_audit
只读，不删除任何文件；如需真正去重请另行处理。
"""
import argparse, hashlib, os, json, csv
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone

IMG_EXTS={".jpg",".jpeg",".png",".bmp",".webp",".tif",".tiff"}

def md5_of(p):
    h=hashlib.md5()
    with open(p,"rb") as f:
        for buf in iter(lambda:f.read(1<<16),b""):
            h.update(buf)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--merged",required=True,help="merged 数据集目录（含 train/val/test）")
    ap.add_argument("--out",default="outputs/dedup_audit")
    args=ap.parse_args()
    merged=Path(args.merged); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)

    # split/类/文件
    imgs=[]
    for split_dir in sorted(merged.iterdir()):
        if not split_dir.is_dir(): continue
        for cls_dir in sorted(split_dir.iterdir()):
            if not cls_dir.is_dir(): continue
            for p in sorted(cls_dir.iterdir()):
                if p.suffix.lower() in IMG_EXTS:
                    imgs.append((split_dir.name,cls_dir.name,p))

    # 计算 MD5
    by_hash=defaultdict(list)
    for split,cls,p in imgs:
        by_hash[md5_of(p)].append((split,cls,str(p)))

    total=len(imgs); uniq=len(by_hash)
    dup_groups={h:v for h,v in by_hash.items() if len(v)>1}
    redundant=sum(len(v)-1 for v in dup_groups.values())

    # 跨 split 泄漏检查（同一 MD5 出现在 >1 个 split）
    cross_split={h:v for h,v in dup_groups.items() if len({x[0] for x in v})>1}

    # 明细 CSV
    with open(out/"dedup_重复明细.csv","w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["md5","split","class","file"])
        for h,v in sorted(dup_groups.items(),key=lambda kv:-len(kv[1])):
            for split,cls,p in v: w.writerow([h,split,cls,p])

    report={
        "生成时间_UTC":datetime.now(timezone.utc).isoformat(),
        "merged目录":str(merged),
        "图片总数":total,"唯一MD5数":uniq,
        "重复组数":len(dup_groups),"冗余图片数":redundant,
        "跨split泄漏组数":len(cross_split),
        "去重方法":"完整文件字节 MD5（精确内容一致才判重；不识别内容相近但字节不同的图片）",
        "说明":"若冗余图片数为0，表示merged内不存在字节级重复图片；跨split泄漏为0表示无同一图跨训练/验证/测试。",
    }
    json.dump(report,open(out/"dedup_audit_report.json","w",encoding="utf-8"),ensure_ascii=False,indent=2)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    print(f"重复明细 -> {out/'dedup_重复明细.csv'}")

if __name__=="__main__":
    main()
