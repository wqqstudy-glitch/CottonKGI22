#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
17_fuse_branches.py
双分支晚期融合 (论文表7):
  分支1 (视觉): YOLO11-cls 的 softmax 概率 p_vis  [N, C]
  分支2 (语义): 16 号缓存的 Chinese-CLIP 余弦 s_k  [N, C]
  融合: Product-of-Experts, logit 级
        fused_logit(c) = log p_vis(c) + lam * ( s_k(c) / tau_k )
        - tau_k: 把余弦恢复成 logit 的"温度", 越小 KG 分布越尖锐
        - lam:   KG 分支权重; lam=0 即纯视觉

流程:
  1) 首次运行调 YOLO 对 val/test 出 22 维完整概率, 缓存 outputs/fusion/vis_{split}.npz
     (之后复跑直接读缓存, 融合调参秒出)
  2) (tau_k, lam) 网格只在 **val** 上按 macro-F1 选最优 (绝不碰 test)
  3) test 上报三档: 纯视觉(lam=0) / 纯KG(argmax 余弦) / 融合(val最优参数)
  4) 诊断: 余弦分布、每类 recall、视觉↔KG 错误互补矩阵、oracle 上限、
          融合相对视觉的翻转 帮对/帮错/净变化

用法:
  python scripts/17_fuse_branches.py \
      --weights runs/classify/runs/cottoninsect/classify_yolo11s_20260915_185226/weights/best.pt \
      --data merged --kg outputs/kg_scores --out outputs/fusion --imgsz 224
  # YOLO 概率已缓存后, 只重算融合可加 --skip-yolo
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np


def softmax(z, axis=-1):
    z = z - z.max(axis=axis, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=axis, keepdims=True)


def _f1_from_pred(y, pred, n_cls, average):
    """手写 F1, 不依赖 sklearn。average: macro / weighted。"""
    f1s, supports = [], []
    for ci in range(n_cls):
        tp = int(((pred == ci) & (y == ci)).sum())
        fp = int(((pred == ci) & (y != ci)).sum())
        fn = int(((pred != ci) & (y == ci)).sum())
        f1 = 2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) else 0.0
        f1s.append(f1); supports.append(int((y == ci).sum()))
    if average == "macro":
        return float(np.mean(f1s))
    w = np.array(supports, dtype="float64")
    return float(np.sum(np.array(f1s) * w) / max(w.sum(), 1))


def metrics(y, probs, classes):
    """返回 top1/top5/macro/weighted/per-class recall & f1。"""
    n, c = probs.shape
    order = np.argsort(-probs, axis=1)
    pred = order[:, 0]
    top1 = float((pred == y).mean())
    top5 = float(np.mean([y[i] in order[i, :5] for i in range(n)]))
    macro = _f1_from_pred(y, pred, c, "macro")
    weighted = _f1_from_pred(y, pred, c, "weighted")
    per = {}
    for ci, cname in enumerate(classes):
        m = y == ci
        if m.sum() == 0:
            continue
        rec = float((pred[m] == ci).mean())
        tp = int(((pred == ci) & (y == ci)).sum())
        fp = int(((pred == ci) & (y != ci)).sum())
        fn = int(((pred != ci) & (y == ci)).sum())
        f1 = 2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) else 0.0
        per[cname] = {"support": int(m.sum()), "recall": rec, "f1": f1}
    return {"top1": top1, "top5": top5, "macro_f1": macro,
            "weighted_f1": weighted, "per_class": per, "pred": pred}


def build_vis_matrix(split, weights, data_dir, kg_npz, imgsz, out_dir, skip_yolo,
                     vis_cache_dir=None):
    """返回与 kg_npz 行对齐的 YOLO p_vis [N,C], 带缓存。
    优先 out_dir, 其次可复用别的融合目录(如 v1 的 outputs/fusion)里对齐的缓存。"""
    cache = out_dir / f"vis_{split}.npz"
    kg = np.load(kg_npz, allow_pickle=True)
    kg_files = np.asarray(kg["files"]).astype(str)
    kg_y = kg["y"]
    classes = list(kg["classes"].astype(str))

    def _aligned(p):
        if not p.exists():
            return None
        z = np.load(p, allow_pickle=True)
        zf = np.asarray(z["files"]).astype(str)
        zy = np.asarray(z["y"])
        ky = np.asarray(kg_y)
        # 长度不一致即视为不对齐（不同数据集/口径），不能直接 == 否则触发广播异常
        if zf.shape != kg_files.shape or zy.shape != ky.shape:
            return None
        ok = (zf == kg_files).all() and (zy == ky).all()
        return z if ok else None

    z = _aligned(cache)
    if z is None and vis_cache_dir:
        shared = Path(vis_cache_dir) / f"vis_{split}.npz"
        zs = _aligned(shared)
        if zs is not None:
            # 复用对齐缓存: 拷一份到当前 out_dir, 后续自洽
            np.savez_compressed(cache, p=zs["p"], y=zs["y"],
                                files=np.asarray(kg_files, dtype=object),
                                classes=np.asarray(classes, dtype=object))
            z = _aligned(cache)
            print(f"[vis] 复用 {shared.name} -> {cache}")
    if z is not None:
        print(f"[vis] 读缓存 {cache.name} ({z['p'].shape[0]} 张)")
        return z["p"].astype("float64"), classes
    print(f"[vis] 无对齐缓存, 需重新跑 YOLO")

    if skip_yolo:
        print(f"❌ 无对齐的视觉概率缓存 (本目录及 --vis-cache={vis_cache_dir}), "
              f"且指定了 --skip-yolo", file=sys.stderr)
        sys.exit(1)

    try:
        from ultralytics import YOLO
    except ImportError:
        print("请先 pip install ultralytics", file=sys.stderr); sys.exit(1)

    model = YOLO(str(weights))
    n, c = len(kg_files), len(classes)
    P = np.zeros((n, c), dtype="float32")
    reorder = None
    print(f"[vis] YOLO 推理 {split}: {n} 张 ...")
    results = model.predict(source=[str(f) for f in kg_files],
                            stream=True, verbose=False, imgsz=imgsz)
    for i, r in enumerate(results):
        if reorder is None:
            names = r.names  # {内部idx: 类名}
            name2idx = {v: k for k, v in names.items()}
            if set(name2idx) != set(classes):
                print(f"❌ YOLO 类集合与 KG 不一致:\n  YOLO={sorted(name2idx)}\n  KG={classes}",
                      file=sys.stderr)
                sys.exit(1)
            reorder = np.array([name2idx[cname] for cname in classes], dtype="int64")
        p = r.probs.data.cpu().numpy().astype("float32")[reorder]
        P[i] = p
        if (i + 1) % 200 == 0:
            print(f"\r  {i+1}/{n}", end="", flush=True)
    print()
    np.savez_compressed(cache, p=P, y=kg_y,
                        files=np.asarray(kg_files, dtype=object),
                        classes=np.asarray(classes, dtype=object))
    print(f"[vis] 已缓存 -> {cache.resolve()}")
    return P.astype("float64"), classes


def fuse(logp_vis, cos_k, tau, lam):
    """PoE: logp_vis [N,C] 已取 log; cos_k [N,C] 余弦。返回融合概率。"""
    z = logp_vis + lam * (cos_k / tau)
    return softmax(z)


def lin_pool(p_vis, cos_k, tau, a):
    """线性意见池: a*p_vis + (1-a)*softmax(cos_k/tau)。返回概率分布。
    p_vis 已校准; KG 余弦经 tau 软max 成分布, a 为视觉分支权重。"""
    p_k = softmax(cos_k / tau)
    return a * p_vis + (1.0 - a) * p_k


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def fit_gate(p_vis, cos_k, y, iters=400, lr=0.2, l2=1e-3, seed=0):
    """在 val 上用逻辑回归学习'视觉分支是否正确' -> g(x)。
    特征 [1, 视觉置信, KG余弦最大, 两者差]; 输出 P(视觉正确), 即视觉权重 g。
    纯 numpy 梯度下降, 不依赖 sklearn。返回权重 w。"""
    rng = np.random.default_rng(seed)
    vis_pred = p_vis.argmax(1)
    target = (vis_pred == y).astype("float64")
    cv = p_vis.max(1)
    ck = cos_k.max(1)
    X = np.stack([np.ones_like(cv), cv, ck, cv - ck], axis=1)
    mu, sd = X.mean(0), X.std(0)
    sd[0] = 1.0
    Xs = (X - mu) / np.where(sd > 1e-9, sd, 1.0)
    w = rng.normal(0, 0.01, size=Xs.shape[1])
    n = Xs.shape[0]
    for _ in range(iters):
        h = _sigmoid(Xs @ w)
        grad = Xs.T @ (h - target) / n + l2 * w
        w -= lr * grad
    return {"w": w, "mu": mu, "sd": sd}


def gate_predict(gate, p_vis, cos_k):
    """对任意样本输出每样本视觉权重 g∈[0,1]。"""
    cv = p_vis.max(1); ck = cos_k.max(1)
    X = np.stack([np.ones_like(cv), cv, ck, cv - ck], axis=1)
    Xs = (X - gate["mu"]) / np.where(gate["sd"] > 1e-9, gate["sd"], 1.0)
    return _sigmoid(Xs @ gate["w"])


def gated_fuse(p_vis, cos_k, tau, g):
    """样本级门控: g_i*p_vis_i + (1-g_i)*p_kg_i; g/ (1-g) 为 [N,1]。"""
    p_k = softmax(cos_k / tau)
    g = np.asarray(g).reshape(-1, 1)
    return g * p_vis + (1.0 - g) * p_k


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True)
    ap.add_argument("--data", default="merged")
    ap.add_argument("--kg", default="outputs/kg_scores")
    ap.add_argument("--out", default="outputs/fusion")
    ap.add_argument("--imgsz", type=int, default=224)
    ap.add_argument("--taus", type=float, nargs="+",
                    default=[0.01, 0.02, 0.03, 0.05, 0.08, 0.1, 0.2])
    ap.add_argument("--lams", type=float, nargs="+",
                    default=[0.0, 0.02, 0.05, 0.1, 0.2, 0.35, 0.5, 0.75, 1.0, 1.5, 2.0])
    ap.add_argument("--skip-yolo", action="store_true")
    ap.add_argument("--extra-fuse", action="store_true",
                    help="额外评估线性意见池与样本级学习门控两个融合对照")
    ap.add_argument("--lin-a", type=float, nargs="+",
                    default=[0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95],
                    help="线性意见池视觉权重 a 网格")
    ap.add_argument("--lin-taus", type=float, nargs="+",
                    default=[0.01, 0.02, 0.03, 0.05, 0.08, 0.1, 0.2],
                    help="线性/门控中 KG softmax 温度网格")
    ap.add_argument("--vis-cache", default="outputs/fusion",
                    help="复用该目录下对齐的 vis_{split}.npz (A/B 换 prompt 时不重跑 YOLO)")
    args = ap.parse_args()

    kg_dir, out_dir = Path(args.kg), Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    eps = 1e-9

    report = {"fusion": "log p_vis + lam * cos_k/tau_k", "splits": {}}

    # ---------- val: 生成/读视觉概率 + KG 余弦, 网格调参 ----------
    val_kg = kg_dir / "val.npz"
    test_kg = kg_dir / "test.npz"
    if not val_kg.exists():
        print(f"❌ 缺少 {val_kg}, 请先跑 16 号", file=sys.stderr); sys.exit(1)

    Pv_val, classes = build_vis_matrix(
        "val", args.weights, Path(args.data), val_kg, args.imgsz, out_dir,
        args.skip_yolo, args.vis_cache)
    kv = np.load(val_kg, allow_pickle=True)
    cos_val = kv["cosine"].astype("float64"); y_val = kv["y"]
    logpv_val = np.log(Pv_val + eps)

    # ---- 诊断: 余弦分布 + 视觉置信度 ----
    print("=" * 84)
    print(f"[诊断] KG 余弦: 均值 {cos_val.mean():.3f} | 标准差 {cos_val.std():.3f} "
          f"| 范围 [{cos_val.min():.3f}, {cos_val.max():.3f}]")
    print(f"[诊断] 视觉最大概率: 均值 {Pv_val.max(1).mean():.3f} (越高越自信)")

    # ---- 纯视觉 / 纯KG 在 val ----
    m_vis_val = metrics(y_val, Pv_val, classes)
    m_kg_val = metrics(y_val, cos_val, classes)
    print("-" * 84)
    print(f"[val] 纯视觉 YOLO : Top-1 {m_vis_val['top1']:.4f} | macro-F1 {m_vis_val['macro_f1']:.4f}")
    print(f"[val] 纯KG   CLIP  : Top-1 {m_kg_val['top1']:.4f}  | macro-F1 {m_kg_val['macro_f1']:.4f}")

    # ---- 互补性 (oracle 上限): 视觉或KG 任一命中真值就算可救 ----
    pred_v = m_vis_val["pred"]; pred_k = m_kg_val["pred"]
    both_right = int(((pred_v == y_val) & (pred_k == y_val)).sum())
    v_only = int(((pred_v == y_val) & (pred_k != y_val)).sum())
    k_only = int(((pred_v != y_val) & (pred_k == y_val)).sum())
    both_wrong = int(((pred_v != y_val) & (pred_k != y_val)).sum())
    n_val = len(y_val)
    print("-" * 84)
    print("[val] 视觉↔KG 错误互补矩阵:")
    print(f"   两者都对 {both_right:4d} ({both_right/n_val:.1%})")
    print(f"   仅视觉对 {v_only:4d} ({v_only/n_val:.1%})")
    print(f"   仅KG对   {k_only:4d} ({k_only/n_val:.1%})  <- 融合可能救回的池")
    print(f"   两者都错 {both_wrong:4d} ({both_wrong/n_val:.1%})")
    print(f"   Oracle 互补上限 Top-1 = {(both_right+v_only+k_only)/n_val:.4f}")

    # ---- 网格 (tau, lam) 只在 val 选 macro-F1 ----
    best = None
    grid = []
    for tau in args.taus:
        for lam in args.lams:
            if lam == 0.0:
                m = m_vis_val
            else:
                pf = fuse(logpv_val, cos_val, tau, lam)
                m = metrics(y_val, pf, classes)
            grid.append({"tau": tau, "lam": lam,
                         "top1": m["top1"], "macro_f1": m["macro_f1"]})
            if best is None or m["macro_f1"] > best["macro_f1"]:
                best = {"tau": tau, "lam": lam,
                        "top1": m["top1"], "macro_f1": m["macro_f1"]}
    tau_b, lam_b = best["tau"], best["lam"]
    print("-" * 84)
    print(f"[val] 网格最优: tau_k={tau_b}  lam={lam_b}  "
          f"Top-1 {best['top1']:.4f} | macro-F1 {best['macro_f1']:.4f}")

    # ---- 对照融合: 线性意见池 + 样本级门控 (仅在 val 选参) ----
    lin_b = gate_b = None
    if args.extra_fuse:
        # (a) 线性意见池: 扫 (tau, a), 选 val macro-F1
        for tau in args.lin_taus:
            for a in args.lin_a:
                pf = lin_pool(np.exp(logpv_val), cos_val, tau, a)
                m = metrics(y_val, pf, classes)
                if lin_b is None or m["macro_f1"] > lin_b["macro_f1"]:
                    lin_b = {"tau": tau, "a": a,
                             "top1": m["top1"], "macro_f1": m["macro_f1"]}
        print("-" * 84)
        print(f"[val] 线性意见池最优: tau_k={lin_b['tau']}  a={lin_b['a']}  "
              f"Top-1 {lin_b['top1']:.4f} | macro-F1 {lin_b['macro_f1']:.4f}")

        # (b) 样本级学习门控: 门在 val 拟合; 融合温度 tau 仍由 val 网格选
        Pv_val_prob = np.exp(logpv_val)
        # 先选门控融合温度
        for tau in args.lin_taus:
            gate_tmp = fit_gate(Pv_val_prob, cos_val, y_val)
            g_val = gate_predict(gate_tmp, Pv_val_prob, cos_val)
            pf = gated_fuse(Pv_val_prob, cos_val, tau, g_val)
            m = metrics(y_val, pf, classes)
            if gate_b is None or m["macro_f1"] > gate_b["macro_f1"]:
                gate_b = {"tau": tau,
                          "top1": m["top1"], "macro_f1": m["macro_f1"],
                          "gate": gate_tmp}
        Pv_val_f = Pv_val_prob
        g_val = gate_predict(gate_b["gate"], Pv_val_f, cos_val)
        gate_b["g_mean"] = float(g_val.mean())
        print(f"[val] 学习门控最优: tau_k={gate_b['tau']}  "
              f"视觉权重均值 {gate_b['g_mean']:.3f} | "
              f"Top-1 {gate_b['top1']:.4f} | macro-F1 {gate_b['macro_f1']:.4f}")

    # ---------- test: 固定 val 参数, 三档报告 ----------
    Pv_te, classes_t = build_vis_matrix(
        "test", args.weights, Path(args.data), test_kg, args.imgsz, out_dir,
        args.skip_yolo, args.vis_cache)
    kt = np.load(test_kg, allow_pickle=True)
    cos_te = kt["cosine"].astype("float64"); y_te = kt["y"]
    logpv_te = np.log(Pv_te + eps)

    vis_te = metrics(y_te, Pv_te, classes)
    kg_te = metrics(y_te, cos_te, classes)
    if lam_b == 0.0:
        fused_te = vis_te
    else:
        fused_te = metrics(y_te, fuse(logpv_te, cos_te, tau_b, lam_b), classes)

    # 对照: 固定 val 参数, test 只评一次
    lin_te = gate_te_m = None
    if args.extra_fuse:
        lin_te = metrics(y_te, lin_pool(Pv_te, cos_te, lin_b["tau"], lin_b["a"]), classes)
        g_te = gate_predict(gate_b["gate"], Pv_te, cos_te)
        gate_te_m = metrics(y_te, gated_fuse(Pv_te, cos_te, gate_b["tau"], g_te), classes)

    rows = [
        ("纯视觉 YOLO (λ=0)", vis_te),
        ("纯KG  CLIP (argmax cos)", kg_te),
        (f"PoE 融合 (τ={tau_b}, λ={lam_b})", fused_te),
    ]
    if args.extra_fuse:
        rows.append((f"线性意见池 (τ={lin_b['tau']}, a={lin_b['a']})", lin_te))
        rows.append((f"学习门控 (τ={gate_b['tau']})", gate_te_m))
    print("\n" + "=" * 84)
    print("论文表7  (test, 参数仅由 val 选出)")
    print("=" * 84)
    print(f"{'方法':<26}{'Top-1':>9}{'Top-5':>9}{'macro-F1':>11}{'weighted-F1':>13}")
    print("-" * 84)
    for name, m in rows:
        print(f"{name:<26}{m['top1']:>9.4f}{m['top5']:>9.4f}"
              f"{m['macro_f1']:>11.4f}{m['weighted_f1']:>13.4f}")

    # ---- test 翻转统计 ----
    pv, pk, pf = vis_te["pred"], kg_te["pred"], fused_te["pred"]
    flipped = pv != pf
    helped = int((flipped & (pv != y_te) & (pf == y_te)).sum())
    hurt = int((flipped & (pv == y_te) & (pf != y_te)).sum())
    neutral = int((flipped & (pv != y_te) & (pf != y_te)).sum())
    print("-" * 84)
    print(f"[test] 融合相对纯视觉: 翻转 {int(flipped.sum())} 张 | "
          f"帮对 {helped} | 帮错 {hurt} | 错→错 {neutral} | 净 {helped-hurt:+d}")

    # ---- 每类 recall: 视觉 vs 融合, 按变化排序 ----
    print("-" * 84)
    print(f"{'类别':<12}{'support':>8}{'视觉recall':>11}{'融合recall':>11}{'Δ':>8}")
    per_v, per_f = vis_te["per_class"], fused_te["per_class"]
    deltas = []
    for cname in classes:
        if cname not in per_v:
            continue
        d = per_f[cname]["recall"] - per_v[cname]["recall"]
        deltas.append((cname, per_v[cname]["support"],
                       per_v[cname]["recall"], per_f[cname]["recall"], d))
    for cname, sup, rv, rf, d in sorted(deltas, key=lambda x: x[4]):
        flag = "⚠" if sup < 30 else " "
        print(f"{flag}{cname:<11}{sup:>8}{rv:>11.3f}{rf:>11.3f}{d:>+8.3f}")

    # ---------- 落盘 ----------
    def strip(m):
        return {k: v for k, v in m.items() if k != "pred"}

    report["val"] = {
        "cosine_mean": float(cos_val.mean()), "cosine_std": float(cos_val.std()),
        "vis_conf_mean": float(Pv_val.max(1).mean()),
        "complement": {"both_right": both_right, "vis_only": v_only,
                       "kg_only": k_only, "both_wrong": both_wrong,
                       "oracle_top1": (both_right + v_only + k_only) / n_val},
        "vis": strip(m_vis_val), "kg": strip(m_kg_val),
        "best": best, "grid_top": sorted(grid, key=lambda g: -g["macro_f1"])[:8],
    }
    report["test"] = {"params": {"tau_k": tau_b, "lam": lam_b},
                      "vis": strip(vis_te), "kg": strip(kg_te), "fused": strip(fused_te),
                      "flips": {"total": int(flipped.sum()), "helped": helped,
                                "hurt": hurt, "wrong_to_wrong": neutral,
                                "net": helped - hurt}}
    if args.extra_fuse:
        report["test"]["linear_pool"] = {
            "params": {"tau_k": float(lin_b["tau"]), "a": float(lin_b["a"])},
            "metrics": strip(lin_te)}
        report["test"]["learned_gate"] = {
            "params": {"tau_k": gate_b["tau"], "g_mean_val": gate_b["g_mean"]},
            "metrics": strip(gate_te_m)}
    rp = out_dir / "fusion_report.json"
    rp.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # CSV: 三档每类 recall/f1
    import csv
    cp = out_dir / "fusion_per_class.csv"
    with open(cp, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["class", "support",
                    "vis_recall", "vis_f1", "kg_recall", "kg_f1",
                    "fused_recall", "fused_f1", "delta_recall"])
        for cname in classes:
            if cname not in per_v:
                continue
            w.writerow([cname, per_v[cname]["support"],
                        round(per_v[cname]["recall"], 4), round(per_v[cname]["f1"], 4),
                        round(kg_te["per_class"][cname]["recall"], 4),
                        round(kg_te["per_class"][cname]["f1"], 4),
                        round(per_f[cname]["recall"], 4), round(per_f[cname]["f1"], 4),
                        round(per_f[cname]["recall"] - per_v[cname]["recall"], 4)])
    print("-" * 84)
    print(f"✅ 报告 -> {rp.resolve()}")
    print(f"✅ 每类对比 -> {cp.resolve()}")

    # ---- 三张混淆矩阵 (行归一化, 中文字体) ----
    try:
        import matplotlib
        matplotlib.use("Agg"); import matplotlib.pyplot as plt
        import seaborn as sns
        Kc = len(classes)
        def _cm(ya, pa, labels=None):
            m = np.zeros((Kc, Kc), dtype="float64")
            for t, p in zip(np.asarray(ya), np.asarray(pa)):
                m[int(t), int(p)] += 1
            return m
        for f in ["Microsoft YaHei","SimHei","PingFang SC","Heiti SC",
                  "WenQuanYi Zen Hei","Noto Sans CJK SC","Arial Unicode MS"]:
            try:
                from matplotlib.font_manager import findfont, FontProperties
                if findfont(FontProperties(family=f), fallback_to_default=False):
                    plt.rcParams["font.sans-serif"] = [f]; break
            except Exception: continue
        plt.rcParams["axes.unicode_minus"] = False

        for name, y_arr, pred_arr, stem in [
            ("纯视觉 YOLO", y_te, vis_te["pred"], "vision"),
            ("纯KG  CLIP",  y_te, kg_te["pred"],  "kg"),
            ("PoE 融合",    y_te, fused_te["pred"],"fused"),
        ]:
            cm = _cm(y_arr, pred_arr, labels=list(range(len(classes))))
            cm_norm = cm.astype(float) / np.maximum(cm.sum(axis=1, keepdims=True), 1)
            fig, ax = plt.subplots(figsize=(14, 12))
            sns.heatmap(cm_norm, annot=True, fmt=".2f", cmap="Blues",
                        xticklabels=classes, yticklabels=classes,
                        vmin=0, vmax=1, cbar_kws={"label": "行归一化 Recall"}, ax=ax)
            ax.set_xlabel("Predicted"); ax.set_ylabel("True")
            top1 = float((pred_arr == y_arr).mean())
            ax.set_title(f"{name} Test 混淆矩阵 (行归一化)  Top1={top1:.3f}")
            plt.tight_layout()
            cm_path = out_dir / f"{stem}_confusion.png"
            fig.savefig(cm_path, dpi=200); plt.close(fig)
            print(f"✅ {name} 混淆矩阵 -> {cm_path.resolve()}")
    except Exception as e:
        print(f"混淆矩阵绘制失败: {e}", file=sys.stderr)


if __name__ == "__main__":
    main()
