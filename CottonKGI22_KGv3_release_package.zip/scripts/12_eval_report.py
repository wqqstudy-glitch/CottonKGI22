#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
12_eval_report.py
用训练好的 best.pt 在 <data>/test 上做正式评估, 输出:
  - overall Top-1 / Top-5
  - 每类 Precision / Recall / F1 / Support
  - macro-F1 / weighted-F1(不平衡数据重点看 macro)
  - 混淆矩阵 PNG(行归一化, 中文字体) + 原始计数 JSON/CSV
  - 结果写到 outputs/eval/<run>_test_report.{json,csv} 和 confusion_matrix_test.png

用法:
  # 自动用 runs/ 下最新一次训练的 best.pt, 并从该 run 的 args.json 读取 data/imgsz
  python 12_eval_report.py

  # 手动指定
  python 12_eval_report.py --weights runs/.../weights/best.pt --data merged_bal --imgsz 224
"""
import argparse
import csv
import json
import sys
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np


def find_latest_best():
    cands = list(Path("runs").rglob("weights/best.pt"))
    if not cands:
        return None
    return max(cands, key=lambda p: p.stat().st_mtime)


def read_run_args(weights: Path):
    """best.pt 上两级目录里通常有 ultralytics 保存的 args.json。"""
    run_dir = weights.parents[1]
    ap = run_dir / "args.json"
    if ap.exists():
        try:
            return json.loads(ap.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def setup_plot():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns  # noqa: F401
    for f in ["Microsoft YaHei", "SimHei", "PingFang SC", "Heiti SC",
              "WenQuanYi Zen Hei", "Noto Sans CJK SC", "Arial Unicode MS"]:
        try:
            from matplotlib.font_manager import findfont, FontProperties
            if findfont(FontProperties(family=f), fallback_to_default=False):
                plt.rcParams["font.sans-serif"] = [f]
                break
        except Exception:
            continue
    plt.rcParams["axes.unicode_minus"] = False
    warnings.filterwarnings("ignore", message=r".*Glyph.*")
    warnings.filterwarnings("ignore", message=r".*missing from font.*")
    return plt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default=None, help="best.pt 路径; 不传则自动找 runs/ 下最新的")
    ap.add_argument("--data", default=None, help="数据集根目录(含 test/); 不传则读 run args.json")
    ap.add_argument("--imgsz", type=int, default=None, help="不传则读 run args.json, 再退回 224")
    ap.add_argument("--split", default="test", choices=["test", "val"])
    args = ap.parse_args()

    weights = Path(args.weights) if args.weights else find_latest_best()
    if weights is None or not weights.exists():
        print("❌ 没找到 best.pt, 请用 --weights 指定。", file=sys.stderr)
        sys.exit(1)

    run_cfg = read_run_args(weights)
    data_root = Path(args.data or run_cfg.get("data") or "merged")
    imgsz = args.imgsz or int(run_cfg.get("imgsz", 224) or 224)
    split_dir = data_root / args.split
    if not split_dir.exists():
        print(f"❌ 找不到评估目录: {split_dir}", file=sys.stderr)
        sys.exit(1)

    print(f"权重: {weights}")
    print(f"数据: {split_dir}   imgsz={imgsz}")

    try:
        from ultralytics import YOLO
    except ImportError:
        print("❌ 请先 pip install ultralytics", file=sys.stderr)
        sys.exit(1)

    model = YOLO(str(weights))
    classes = sorted([p.name for p in split_dir.iterdir() if p.is_dir()])
    idx = {c: i for i, c in enumerate(classes)}
    n = len(classes)

    # 递归收集 test/<类名>/*.jpg(predict 直接传目录不会进子文件夹, 必须自己列文件)
    img_exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    img_paths = sorted([str(p) for p in split_dir.rglob("*")
                        if p.is_file() and p.suffix.lower() in img_exts])
    if not img_paths:
        print(f"❌ {split_dir} 下没有递归找到任何图片", file=sys.stderr)
        sys.exit(1)
    print(f"递归发现 {len(img_paths)} 张测试图, 开始推理 ...")

    cm = np.zeros((n, n), dtype=np.int64)
    top1_ok = top5_ok = total = 0
    per_class_top5 = {c: [0, 0] for c in classes}  # [hit, support]

    # 传文件路径列表(加载器支持 list), stream 逐批回收结果, 避免一次性占满内存
    results = model.predict(source=img_paths, stream=True, verbose=False, imgsz=imgsz)
    for r in results:
        true_cls = Path(r.path).parent.name
        if true_cls not in idx:
            continue
        probs = r.probs
        if probs is None:
            continue
        pred_i = int(probs.top1)
        pred_cls = model.names.get(pred_i, str(pred_i))
        if pred_cls not in idx:
            continue
        cm[idx[true_cls], idx[pred_cls]] += 1
        total += 1
        if pred_cls == true_cls:
            top1_ok += 1
        top5_idx = [int(i) for i in probs.top5]
        top5_names = {model.names.get(i, str(i)) for i in top5_idx}
        hit5 = true_cls in top5_names
        if hit5:
            top5_ok += 1
        per_class_top5[true_cls][0] += int(hit5)
        per_class_top5[true_cls][1] += 1

    if total == 0:
        print("❌ 未评估到任何图片, 请检查 test 目录结构。", file=sys.stderr)
        sys.exit(1)

    # ---- 每类指标 ----
    rows = []
    f1s, precs, recs, supports = [], [], [], []
    for c in classes:
        i = idx[c]
        tp = int(cm[i, i])
        fp = int(cm[:, i].sum() - tp)
        fn = int(cm[i, :].sum() - tp)
        support = tp + fn
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
        t5h, t5n = per_class_top5[c]
        rows.append({
            "class": c, "precision": round(prec, 4), "recall": round(rec, 4),
            "f1": round(f1, 4), "support": support,
            "top5_recall": round(t5h / t5n, 4) if t5n else 0.0,
            "TP": tp, "FP": fp, "FN": fn,
        })
        precs.append(prec); recs.append(rec); f1s.append(f1); supports.append(support)

    macro_p, macro_r, macro_f1 = float(np.mean(precs)), float(np.mean(recs)), float(np.mean(f1s))
    sw = np.array(supports, dtype=float)
    weighted_f1 = float(np.sum(np.array(f1s) * sw) / sw.sum())
    top1, top5 = top1_ok / total, top5_ok / total

    # KG 信息
    kg = {}
    kp = data_root / "kg_link.json"
    if kp.exists():
        kg = json.loads(kp.read_text(encoding="utf-8"))

    # ---- 输出文件 ----
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("outputs") / "eval"
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = weights.parents[1].name
    stem = f"{tag}_{args.split}_{ts}"

    report = {
        "weights": str(weights), "data": str(data_root), "split": args.split,
        "imgsz": imgsz, "n_images": total, "n_classes": n,
        "top1_acc": round(top1, 4), "top5_acc": round(top5, 4),
        "macro_precision": round(macro_p, 4), "macro_recall": round(macro_r, 4),
        "macro_f1": round(macro_f1, 4), "weighted_f1": round(weighted_f1, 4),
        "per_class": [{**r, "kg_id": kg.get(r["class"], {}).get("kg_id", ""),
                       "kg_name": kg.get(r["class"], {}).get("kg_name", "")} for r in rows],
        "confusion_matrix": cm.tolist(), "class_order": classes,
    }
    (out_dir / f"{stem}_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    with open(out_dir / f"{stem}_report.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["class", "kg_id", "kg_name", "precision",
                                          "recall", "f1", "support", "top5_recall",
                                          "TP", "FP", "FN"])
        w.writeheader()
        for r in report["per_class"]:
            w.writerow({k: r.get(k, "") for k in w.fieldnames})

    # ---- 混淆矩阵(行归一化) ----
    plt = setup_plot()
    row_sum = cm.sum(axis=1, keepdims=True)
    cm_norm = np.divide(cm, row_sum, out=np.zeros_like(cm, dtype=float),
                        where=row_sum != 0)
    fig, ax = plt.subplots(figsize=(14, 12))
    import seaborn as sns
    sns.heatmap(cm_norm, annot=True, fmt=".2f", cmap="Blues",
                xticklabels=classes, yticklabels=classes,
                vmin=0, vmax=1, cbar_kws={"label": "行归一化 Recall"}, ax=ax)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    ax.set_title(f"Test Confusion Matrix (row-normalized)  Top1={top1:.3f} macroF1={macro_f1:.3f}")
    plt.tight_layout()
    fig.savefig(out_dir / f"{stem}_confusion.png", dpi=200)
    plt.close(fig)

    # ---- 终端摘要(按 F1 升序, 最差类排最前) ----
    print("\n" + "=" * 86)
    print(f"test 图片 {total} | Top-1 {top1:.4f} | Top-5 {top5:.4f} | "
          f"macro-F1 {macro_f1:.4f} | weighted-F1 {weighted_f1:.4f}")
    print("=" * 86)
    print(f"{'类别':<10}{'KG-ID':>8}{'Precision':>11}{'Recall':>9}{'F1':>9}{'support':>9}")
    print("-" * 86)
    for r in sorted(rows, key=lambda x: x["f1"]):
        kid = kg.get(r["class"], {}).get("kg_id", "")
        flag = " ⚠️" if (r["support"] < 20 or r["f1"] < 0.5) else ""
        print(f"{r['class']:<10}{str(kid):>8}{r['precision']:>11.3f}{r['recall']:>9.3f}"
              f"{r['f1']:>9.3f}{r['support']:>9}{flag}")
    print("-" * 86)
    print(f"\n✅ 报告目录 → {out_dir.resolve()}")
    print(f"   {stem}_report.csv / .json / _confusion.png")


if __name__ == "__main__":
    main()
