#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
23_zero_fusion_M0M2.py
补关键消融：M0 + M2「零样本(未经 LoRA)语义分支」融合，与 M0 + M3(LoRA 适配后) 对比。

口径严格对齐论文:
  - 数据: 近重复去泄漏 CottonKGI-22-clean 的 val / test (ImageFolder)
  - M2: 直接用未微调 OFA-Sys/chinese-clip-vit-base-patch16, 官方 ChineseCLIPProcessor
        (与 M3 最终 test 评估同一预处理, 保证唯一变量是"是否做过 LoRA")
  - 文本锚: 与 M3 完全相同的多 prompt 集成质心
  - M0: 读已有视觉概率缓存(vis val/test npz), 按文件名对齐
  - 融合: PoE  s(c)=log p_vis(c)+λ·cos_k(x,c)/τ
        (a) 固定 τ=.01,λ=1.5(与 M3 主结果同参, 直接对比)
        (b) 若提供 --vis-val, 则在 val 上网格标定 M0+M2 自己的最优 τ/λ 再报 test(公平)

依赖: pip install transformers torch pillow numpy
用法(本地, 在 vision 工程目录下):
  python scripts/23_zero_fusion_M0M2.py \
      --data datasets/CottonKGI-22-clean \
      --prompts outputs/kg_prompts/prompts.json \
      --class-indices merged/class_indices.json \
      --vis-test outputs/fusion_nd/vis_test.npz \
      --vis-val  outputs/fusion_nd/vis_val.npz \
      --m3-test  outputs/kg_scores_nd/test.npz \
      --out outputs/zero_fusion_M0M2 --device 0
  # 没有 vis_val / m3_test 也可省略, 至少给出 test 关键对比
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def collect_images(split_dir, classes):
    paths, labels = [], []
    for ci, c in enumerate(classes):
        for p in sorted(split_dir.joinpath(c).rglob("*")):
            if p.is_file() and p.suffix.lower() in IMG_EXTS:
                paths.append(p); labels.append(ci)
    return paths, np.asarray(labels)


def load_base(device):
    import torch
    import transformers.utils.import_utils as iu
    iu.check_torch_load_is_safe = lambda *a, **k: None
    from transformers import ChineseCLIPModel, ChineseCLIPProcessor
    import transformers.modeling_utils as mu
    if hasattr(mu, "check_torch_load_is_safe"):
        mu.check_torch_load_is_safe = lambda *a, **k: None
    mid = "OFA-Sys/chinese-clip-vit-base-patch16"
    model = ChineseCLIPModel.from_pretrained(mid).to(device).eval()
    processor = ChineseCLIPProcessor.from_pretrained(mid)
    return model, processor, torch


def feat_of(out, torch):
    if torch.is_tensor(out):
        return out.float()
    if getattr(out, "pooler_output", None) is not None:
        return out.pooler_output.float()
    if getattr(out, "last_hidden_state", None) is not None:
        return out.last_hidden_state[:, 0].float()
    return out


def encode_split(model, processor, paths, device, torch, batch=64):
    """官方 processor 编码图像 -> L2 归一特征。"""
    from PIL import Image
    import torch.nn.functional as F
    feats = []
    for s in range(0, len(paths), batch):
        imgs = [Image.open(p).convert("RGB") for p in paths[s:s + batch]]
        inp = processor(images=imgs, return_tensors="pt")
        out = model.get_image_features(pixel_values=inp["pixel_values"].to(device))
        feats.append(F.normalize(feat_of(out, torch), dim=-1).cpu())
    return torch.cat(feats, 0)


def text_centroids(model, processor, prompts_doc, classes, device, torch):
    import torch.nn.functional as F
    cens = []
    with torch.no_grad():
        for c in classes:
            tok = processor(text=prompts_doc[c]["prompts"], padding="max_length",
                            max_length=64, truncation=True, return_tensors="pt")
            out = model.get_text_features(**{k: v.to(device) for k, v in tok.items()})
            e = F.normalize(feat_of(out, torch), dim=-1).mean(0, keepdim=True)
            cens.append(F.normalize(e, dim=-1))
    return torch.cat(cens, 0)


def poe_top1(p, cos, tau, lam):
    s = np.log(p + 1e-9) + lam * cos / tau
    return s.argmax(1), s


def macro_f1(y, pred, K):
    cm = np.zeros((K, K))
    for t, q in zip(y, pred):
        cm[t, q] += 1
    tp = np.diag(cm); fp = cm.sum(0) - tp; fn = cm.sum(1) - tp
    pr = tp / np.maximum(tp + fp, 1); rc = tp / np.maximum(tp + fn, 1)
    f1 = 2 * pr * rc / np.maximum(pr + rc, 1e-12)
    return float(f1.mean())


def align_vis(vis_npz, paths):
    """按文件名把 M0 概率/标签对齐到当前 paths 顺序。"""
    z = np.load(vis_npz, allow_pickle=True)
    vfiles = [Path(str(f)).name for f in z["files"]]
    idx = {n: i for i, n in enumerate(vfiles)}
    order = [idx[Path(p).name] for p in paths]
    assert len(set(order)) == len(order), "文件名不能唯一对齐, 请检查"
    return z["p"][order], z["y"][order]


def report(tag, y, pred, K):
    top1 = float((pred == y).mean())
    top5 = float(np.mean([y[i] in np.argsort(-np.eye(K)[pred[i]])[:0] or True
                          for i in range(0)]))  # 占位, Top-5 需 score, 下方单独算
    mf1 = macro_f1(y, pred, K)
    return top1, mf1


def top5_from_score(y, score):
    k5 = np.argsort(-score, axis=1)[:, :5]
    return float(np.mean([y[i] in k5[i] for i in range(len(y))]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--prompts", required=True)
    ap.add_argument("--class-indices", required=True)
    ap.add_argument("--vis-test", required=True, help="M0 test 概率 npz(含 p,y,files)")
    ap.add_argument("--vis-val", default=None)
    ap.add_argument("--m3-test", default=None, help="M3 test 余弦 npz(用于同屏对比)")
    ap.add_argument("--m3-val", default=None)
    ap.add_argument("--out", default="outputs/zero_fusion_M0M2")
    ap.add_argument("--device", default="0")
    ap.add_argument("--batch", type=int, default=64)
    args = ap.parse_args()

    class_indices = json.loads(Path(args.class_indices).read_text(encoding="utf-8"))
    classes = [c for c, _ in sorted(class_indices.items(), key=lambda kv: kv[1])]
    prompts_doc = json.loads(Path(args.prompts).read_text(encoding="utf-8"))
    K = len(classes)

    import torch
    device = ("cuda" if str(args.device) not in ("cpu", "-1") and torch.cuda.is_available() else "cpu")
    print(f"[device] {device}; 加载未微调 Chinese-CLIP (M2) ...")
    model, processor, torch = load_base(device)
    tmat = text_centroids(model, processor, prompts_doc, classes, device, torch).to(device)

    out_dir = Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)
    result = {}

    def run_split(split, vis_npz, m3_npz, can_tune):
        paths, y_img = collect_images(Path(args.data) / split, classes)
        imgf = encode_split(model, processor, paths, device, torch, args.batch).to(device)
        cos2 = (imgf @ tmat.T).cpu().numpy().astype("float32")  # M2 零样本余弦
        y = np.asarray(y_img)
        p_vis, yv = align_vis(vis_npz, paths)
        assert (yv == y).mean() > 0.99, f"{split}: M0 标签与图像标签对不齐"

        r = {}
        r["n"] = int(len(y))
        r["M2_zero_top1"] = float((cos2.argmax(1) == y).mean())
        r["M2_zero_macroF1"] = macro_f1(y, cos2.argmax(1), K)

        # 固定 τ=.01 λ=1.5 (与 M3 主结果同参)
        pred_f, sc_f = poe_top1(p_vis, cos2, 0.01, 1.5)
        r["M0+M2_fixed_tau.01_lam1.5"] = dict(
            top1=float((pred_f == y).mean()), top5=top5_from_score(y, sc_f),
            macroF1=macro_f1(y, pred_f, K))

        # M3 同屏对比
        if m3_npz and Path(m3_npz).exists():
            z3 = np.load(m3_npz, allow_pickle=True)
            cos3 = z3["cosine"]
            # 按 files 对齐
            f3 = [Path(str(f)).name for f in z3["files"]]
            pos = {n: i for i, n in enumerate(f3)}
            o3 = [pos[Path(q).name] for q in paths]
            cos3 = cos3[o3]
            r["M3_top1"] = float((cos3.argmax(1) == y).mean())
            pred3, sc3 = poe_top1(p_vis, cos3, 0.01, 1.5)
            r["M0+M3_tau.01_lam1.5"] = dict(
                top1=float((pred3 == y).mean()), top5=top5_from_score(y, sc3),
                macroF1=macro_f1(y, pred3, K))
            result[f"_{split}_cos3"] = cos3
        result[f"_{split}_cos2"] = cos2
        result[f"_{split}_y"] = y
        result[f"_{split}_pvis"] = p_vis
        result[f"_{split}_files"] = np.asarray([str(q) for q in paths], dtype=object)
        return r

    has_val = args.vis_val and Path(args.vis_val).exists()
    if has_val:
        print("[val] 编码零样本 M2 + 融合 ...")
        result["val"] = run_split("val", args.vis_val, args.m3_val, True)
    print("[test] 编码零样本 M2 + 融合 ...")
    result["test"] = run_split("test", args.vis_test, args.m3_test, False)

    # val 上为 M0+M2 标定自身最优 τ/λ, 再应用到 test
    if has_val:
        taus = [0.01, 0.02, 0.05, 0.1]
        lams = [0.5, 1.0, 1.5, 2.0]
        best = None
        for t in taus:
            for l in lams:
                pv, _ = poe_top1(result["_val_pvis"], result["_val_cos2"], t, l)
                sc = (pv == result["_val_y"]).mean()
                if best is None or sc > best[0]:
                    best = (sc, t, l)
        _, bt, bl = best
        pt, sct = poe_top1(result["_test_pvis"], result["_test_cos2"], bt, bl)
        yt = result["_test_y"]
        result["test"]["M0+M2_valTuned"] = dict(
            tau=bt, lam=bl,
            top1=float((pt == yt).mean()), top5=top5_from_score(yt, sct),
            macroF1=macro_f1(yt, pt, K))
        print(f"[tune] M0+M2 val 最优 τ={bt} λ={bl}")

    (out_dir / "result.json").write_text(
        json.dumps({k: v for k, v in result.items()
                    if not k.startswith("_")}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    # 存 M2 余弦缓存供论文/画图
    for sp in (["val"] if has_val else []) + ["test"]:
        np.savez_compressed(
            out_dir / f"{sp}.npz",
            cosine=result[f"_{sp}_cos2"], y=result[f"_{sp}_y"],
            files=result[f"_{sp}_files"], classes=np.asarray(classes, dtype=object))

    print("\n================ 关键对比 (test) ================")
    t = result["test"]
    print(f"M2 零样本单分支        : Top-1 {t['M2_zero_top1']:.4f}  macro-F1 {t['M2_zero_macroF1']:.4f}")
    a = t["M0+M2_fixed_tau.01_lam1.5"]
    print(f"M0+M2 (τ=.01,λ=1.5)   : Top-1 {a['top1']:.4f}  Top-5 {a['top5']:.4f}  macro-F1 {a['macroF1']:.4f}")
    if "M0+M2_valTuned" in t:
        b = t["M0+M2_valTuned"]
        print(f"M0+M2 (val标定{ b['tau']},{b['lam']})  : Top-1 {b['top1']:.4f}  Top-5 {b['top5']:.4f}  macro-F1 {b['macroF1']:.4f}")
    if "M0+M3_tau.01_lam1.5" in t:
        print(f"M3 单分支             : Top-1 {t['M3_top1']:.4f}")
        c = t["M0+M3_tau.01_lam1.5"]
        print(f"M0+M3 (τ=.01,λ=1.5)   : Top-1 {c['top1']:.4f}  Top-5 {c['top5']:.4f}  macro-F1 {c['macroF1']:.4f}")
    print(f"\n结果/缓存 -> {out_dir.resolve()}")


if __name__ == "__main__":
    main()
