#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
02_inspect_dataset.py
自动探查 CottonInsect 数据集结构, 输出数据画像 (类别清单、样本数、目录格式、映射状态)。

支持两种版本:
  - CottonInsect_classification/: 分类版 (classes.txt + class_indices.json + train/val/test.txt + pest_dataset/)
  - CottonInsect_detection/:      检测版 (VOC XML 标注 + classes.txt + JPG)

用法:
  python 02_inspect_dataset.py \
      --root "/Users/os11/Downloads/b0d40-main 2" \
      --mapping ../configs/cottoninsect_mapping.json \
      --out outputs/dataset_report.json
"""
import argparse
import json
import re
from collections import Counter
from pathlib import Path

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def read_text(p: Path):
    for enc in ("utf-8", "gbk", "utf-8-sig"):
        try:
            return p.read_text(encoding=enc)
        except Exception:
            continue
    return p.read_text(errors="ignore")


def inspect_classification(root: Path):
    """探查分类版。"""
    info = {"version": "classification", "path": str(root), "classes": [], "splits": {}, "issues": []}

    # classes.txt (每行 "序号 类名" 或纯 "类名")
    ct = root / "classes.txt"
    if ct.exists():
        lines = []
        for l in read_text(ct).splitlines():
            l = l.strip()
            if not l:
                continue
            parts = l.split()
            lines.append(parts[-1] if parts and parts[0].isdigit() and len(parts) > 1 else l)
        info["classes_file"] = lines
        info["classes"] = lines

    # class_indices.json (形如 {"0": "bollworm", ...} 或 {"bollworm": 0})
    cj = root / "class_indices.json"
    if cj.exists():
        try:
            data = json.loads(read_text(cj))
            info["class_indices"] = data
            # 统一成 {name: index}
            if all(isinstance(v, int) for v in data.values()):
                info["name2idx"] = {k: v for k, v in data.items()}
            elif all(isinstance(k, str) and k.isdigit() for k in data):
                info["name2idx"] = {v: int(k) for k, v in data.items()}
        except Exception as e:
            info["issues"].append(f"class_indices.json 解析失败: {e}")

    # train/val/test.txt —— 每行 "文件名 0-based标签"; 图片扁平存放在 pest_dataset/<split>/
    splits = {}
    for sp in ("train", "val", "test"):
        f = root / f"{sp}.txt"
        if not f.exists():
            continue
        lines = [l.strip() for l in read_text(f).splitlines() if l.strip()]
        splits[sp] = {"count": len(lines), "sample_lines": lines[:3]}
    info["splits"] = splits

    # pest_dataset 实际目录统计
    pd_dir = root / "pest_dataset"
    if pd_dir.exists():
        tree = {}
        for sub in sorted(pd_dir.iterdir()):
            if sub.is_dir():
                imgs = [p for p in sub.rglob("*") if p.suffix.lower() in IMG_EXTS]
                tree[sub.name] = len(imgs)
        info["pest_dataset_tree"] = tree

    # 统计每类样本数: 优先直接用 txt 的标签列 (扁平目录), 类名取 classes 顺序
    names = info.get("classes", [])
    if names and splits:
        cnt = Counter()
        for sp in splits:
            for line in [l.strip() for l in read_text(root / f"{sp}.txt").splitlines() if l.strip()]:
                parts = line.split()
                if len(parts) >= 2 and parts[-1].lstrip("-").isdigit():
                    lab = int(parts[-1])
                    if 0 <= lab < len(names):
                        cnt[names[lab]] += 1
        info["samples_per_class_from_txt"] = dict(cnt)

    return info


def inspect_detection(root: Path):
    """探查检测版 (VOC)。"""
    info = {"version": "detection", "path": str(root), "issues": []}

    ct_files = sorted(root.rglob("classes.txt"))
    if ct_files:
        info["classes_file_path"] = str(ct_files[0].relative_to(root))
        names = []
        for l in read_text(ct_files[0]).splitlines():
            l = l.strip()
            if not l:
                continue
            parts = l.split()
            names.append(parts[-1] if parts and parts[0].isdigit() and len(parts) > 1 else l)
        info["classes"] = names

    # 递归统计 jpg / xml
    jpgs = [p for p in root.rglob("*") if p.suffix.lower() in IMG_EXTS]
    xmls = list(root.rglob("*.xml"))
    info["n_images"] = len(jpgs)
    info["n_xml"] = len(xmls)

    # 顶层结构
    info["top_level"] = sorted([p.name for p in root.iterdir() if not p.name.startswith(".")])

    # 解析若干 XML 看类别名与框格式
    cls_counter = Counter()
    xml_sample = None
    for x in xmls[:200]:
        txt = read_text(x)
        names = re.findall(r"<name>\s*([^<]+?)\s*</name>", txt)
        for n in names:
            cls_counter[n.strip()] += 1
        if xml_sample is None and names:
            xml_sample = txt[:800]
    if xmls:
        # 全量统计类别 (200个之后的也要)
        for x in xmls[200:]:
            for n in re.findall(r"<name>\s*([^<]+?)\s*</name>", read_text(x)):
                cls_counter[n.strip()] += 1
    info["objects_per_class"] = dict(cls_counter)
    info["xml_sample"] = xml_sample

    # 检查 jpg/xml 配对
    jpg_stems = {p.stem for p in jpgs}
    xml_stems = {p.stem for p in xmls}
    info["jpg_without_xml"] = len(jpg_stems - xml_stems)
    info["xml_without_jpg"] = len(xml_stems - jpg_stems)
    return info


def merge_mapping(info: dict, mapping_path: Path):
    """把类别与 KG 映射表对照, 标注未映射类别。"""
    if not mapping_path.exists():
        info["mapping"] = {"error": f"映射表不存在: {mapping_path}"}
        return info
    mp = json.loads(Path(mapping_path).read_text(encoding="utf-8"))["mappings"]

    found = set()
    # 收集数据集中实际出现的类别名
    cls_names = set()
    if info["version"] == "classification":
        cls_names |= set(info.get("name2idx", {}).keys())
        cls_names |= set(info.get("classes", []))
        cls_names |= set(info.get("samples_per_class_from_txt", {}).keys())
    else:
        cls_names |= set(info.get("classes", []))
        cls_names |= set(info.get("objects_per_class", {}).keys())
    cls_names = {c for c in cls_names if c}

    rows = []
    for c in sorted(cls_names):
        key = c.strip()
        if key in mp:
            m = mp[key]
            rows.append({"dataset_class": key, "zh": m["zh"],
                         "kg_entity_type": m["kg_entity_type"],
                         "kg_id": m["kg_id"], "kg_name": m["kg_name"],
                         "status": "MAPPED" if m["kg_id"] else
                                   ("UNVERIFIED" if m["kg_entity_type"] == "unverified" else "NOT_IN_KG")})
            found.add(key)
        else:
            rows.append({"dataset_class": key, "zh": None, "kg_entity_type": None,
                         "kg_id": None, "kg_name": None, "status": "UNMAPPED_NEED_REVIEW"})

    missing_in_data = [k for k in mp if k not in found]
    info["mapping"] = {
        "rows": rows,
        "mapped_classes": [r["dataset_class"] for r in rows if r["status"] == "MAPPED"],
        "unmapped_in_data": [r["dataset_class"] for r in rows if r["status"] == "UNMAPPED_NEED_REVIEW"],
        "mapping_entries_not_seen_in_data": missing_in_data,
    }
    return info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="包含 CottonInsect_classification/ 和 CottonInsect_detection/ 的目录")
    ap.add_argument("--mapping", default="../configs/cottoninsect_mapping.json")
    ap.add_argument("--out", default="outputs/dataset_report.json")
    args = ap.parse_args()

    root = Path(args.root)
    report = {}

    cls_dir = root / "CottonInsect_classification"
    det_dir = root / "CottonInsect_detection"

    if cls_dir.exists():
        report["classification"] = inspect_classification(cls_dir)
        report["classification"] = merge_mapping(report["classification"], Path(args.mapping))
    else:
        print(f"[warn] 未找到分类版目录: {cls_dir}")

    if det_dir.exists():
        report["detection"] = inspect_detection(det_dir)
        report["detection"] = merge_mapping(report["detection"], Path(args.mapping))
    else:
        print(f"[warn] 未找到检测版目录: {det_dir}")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # 控制台摘要
    print("=" * 60)
    for ver in ("classification", "detection"):
        if ver not in report:
            continue
        r = report[ver]
        print(f"【{ver}】")
        if ver == "classification":
            print(f"  类别: {r.get('classes')}")
            for sp, d in r.get("splits", {}).items():
                print(f"  {sp}: {d['count']} 条")
            t = r.get("samples_per_class_from_txt", {})
            if t:
                print(f"  各类样本数: {t}")
        else:
            print(f"  图片 {r['n_images']} 张, XML {r['n_xml']} 个")
            print(f"  类别目标数: {r.get('objects_per_class')}")
            print(f"  无XML的图片: {r['jpg_without_xml']}, 无图片的XML: {r['xml_without_jpg']}")
        mp = r.get("mapping", {})
        print(f"  已映射KG: {mp.get('mapped_classes')}")
        print(f"  数据中未收录映射: {mp.get('unmapped_in_data')}")
        print(f"  映射表有但数据未见: {mp.get('mapping_entries_not_seen_in_data')}")
        for iss in r.get("issues", []):
            print(f"  [issue] {iss}")
        print("-" * 60)
    print(f"完整报告: {out.resolve()}")


if __name__ == "__main__":
    main()
