#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
03_convert_dataset.py
把 CottonInsect 原始发布格式转换为训练就绪格式。

【分类版】CottonInsect_classification/
  原始: pest_dataset/{train,val,test}/*.jpg (扁平) + {split}.txt (每行 "文件名 0-based标签")
        classes.txt 为 1-based 类别名 (第1行=标签0)
  输出: datasets/Classification/<split>/<dataset_class>/*.jpg  (ImageFolder, 硬链接优先)
        datasets/Classification/class_map.json  (dataset_class ↔ kg_id/kg_name)
        datasets/Classification/stats.json

【检测版】CottonInsect_detection/  (VOC XML)
  原始: 自动发现 JPG 目录与 XML 目录; classes.txt
  输出: datasets/Detection/images/<split>/*.jpg
        datasets/Detection/labels/<split>/*.txt   (YOLO 归一化格式)
        datasets/Detection/data.yaml
  若无现成 train/val/test 划分, 按 8:1:1 分层划分 (按图片主类别分层)。

注意: 训练标签保持数据集原始 13 类 (细粒度利于学特征);
      类别 → KG 实体的聚合映射在推理阶段(04脚本)完成。

用法:
  python 03_convert_dataset.py \
      --root "/Users/os11/Downloads/b0d40-main 2" \
      --mapping ../configs/cottoninsect_mapping.json \
      --out datasets --link hard
"""
import argparse
import json
import os
import random
import re
import shutil
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp"}
random.seed(42)


def read_text(p: Path):
    for enc in ("utf-8", "gbk", "utf-8-sig"):
        try:
            return p.read_text(encoding=enc)
        except Exception:
            continue
    return p.read_text(errors="ignore")


def load_classes(ct_file: Path):
    """读 classes.txt 文件 -> ['lacewing', ...] (行顺序即 0-based 标签顺序)。
    兼容 '1 lacewing' 带编号与纯 'lacewing' 两种写法。"""
    names = []
    for line in read_text(ct_file).splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        names.append(parts[-1] if parts and parts[0].isdigit() and len(parts) > 1 else line)
    return names


def find_classes_file(root: Path):
    """在目录树下找 classes.txt (检测版可能多嵌套一层)。"""
    cands = sorted(root.rglob("classes.txt"))
    return cands[0] if cands else None


def link_or_copy(src: Path, dst: Path, mode: str):
    """硬链接优先(省空间), 失败按 mode 回退。"""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    if mode == "hard":
        try:
            os.link(src, dst)
            return
        except OSError:
            pass
    if mode == "symlink":
        try:
            os.symlink(src.resolve(), dst)
            return
        except OSError:
            pass
    shutil.copy2(src, dst)


# ---------------- 分类版 ----------------
def convert_classification(root: Path, out_dir: Path, mapping: dict, link_mode: str):
    print("\n[分类版] 转换开始")
    names = load_classes(root / "classes.txt")
    print(f"  类别({len(names)}): {names}")
    pd_dir = root / "pest_dataset"

    stats = {}
    total = 0
    for split in ("train", "val", "test"):
        txt = root / f"{split}.txt"
        img_dir = pd_dir / split
        if not txt.exists() or not img_dir.exists():
            print(f"  [skip] {split}: txt或图片目录缺失")
            continue
        cls_counter = Counter()
        missing = 0
        for line in read_text(txt).splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            fname, label = parts[0], int(parts[1])
            if label >= len(names):
                print(f"  [warn] 标签越界: {line}")
                continue
            cls = names[label]
            src = img_dir / fname
            if not src.exists():
                missing += 1
                continue
            dst = out_dir / "Classification" / split / cls / fname
            link_or_copy(src, dst, link_mode)
            cls_counter[cls] += 1
            total += 1
        stats[split] = dict(cls_counter)
        print(f"  {split}: {sum(cls_counter.values())} 张, 缺失图片 {missing}")

    # 类别映射表
    mp = mapping["mappings"]
    class_map = {}
    for i, cls in enumerate(names):
        m = mp.get(cls, {})
        class_map[cls] = {
            "dataset_label_0based": i,
            "zh": m.get("zh"),
            "kg_entity_type": m.get("kg_entity_type"),
            "kg_id": m.get("kg_id"),
            "kg_name": m.get("kg_name"),
            "note": m.get("note"),
        }
    out_c = out_dir / "Classification"
    out_c.mkdir(parents=True, exist_ok=True)
    (out_c / "class_map.json").write_text(
        json.dumps(class_map, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_c / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  合计 {total} 张 -> {out_c}")
    return stats


# ---------------- 检测版 ----------------
def find_dirs(root: Path, keywords):
    """在根目录下找名字含关键词的子目录。"""
    hits = []
    for p in root.rglob("*"):
        if p.is_dir() and any(k in p.name.lower() for k in keywords):
            hits.append(p)
    return hits


def convert_detection(root: Path, out_dir: Path, mapping: dict, link_mode: str):
    print("\n[检测版] 转换开始")
    ct_file = find_classes_file(root)
    names = load_classes(ct_file) if ct_file else None
    name2id = {n: i for i, n in enumerate(names)} if names else {}

    # 发现 XML 与 JPG
    xmls = list(root.rglob("*.xml"))
    jpgs = [p for p in root.rglob("*") if p.suffix.lower() in IMG_EXTS]
    print(f"  发现 XML {len(xmls)} 个, 图片 {len(jpgs)} 张")
    if not xmls:
        print("  [skip] 未发现 VOC 标注")
        return

    # XML 内类别名收集 (核对 classes.txt)
    xml_classes = set()
    records = []  # (jpg_path, [(cls, xc, yc, w, h 归一化)])
    skipped = 0
    for x in xmls:
        try:
            tree = ET.parse(x)
        except Exception:
            skipped += 1
            continue
        r = tree.getroot()
        size = r.find("size")
        if size is None:
            skipped += 1
            continue
        W = float(size.findtext("width"))
        H = float(size.findtext("height"))
        if W <= 0 or H <= 0:
            skipped += 1
            continue
        # 找对应图片
        stem = x.stem
        jpg = next((j for j in jpgs if j.stem == stem), None)
        if jpg is None:
            skipped += 1
            continue
        boxes = []
        for obj in r.findall("object"):
            cls = obj.findtext("name").strip()
            xml_classes.add(cls)
            b = obj.find("bndbox")
            if b is None:
                continue
            xmin = float(b.findtext("xmin")); ymin = float(b.findtext("ymin"))
            xmax = float(b.findtext("xmax")); ymax = float(b.findtext("ymax"))
            # 裁剪到图像范围
            xmin = max(0, min(xmin, W)); xmax = max(0, min(xmax, W))
            ymin = max(0, min(ymin, H)); ymax = max(0, min(ymax, H))
            if xmax <= xmin or ymax <= ymin:
                continue
            boxes.append((cls, (xmin + xmax) / 2 / W, (ymin + ymax) / 2 / H,
                          (xmax - xmin) / W, (ymax - ymin) / H))
        if boxes:
            records.append((jpg, boxes))

    print(f"  有效标注图片 {len(records)} 张, 跳过 {skipped}")
    print(f"  XML 内类别: {sorted(xml_classes)}")
    if names:
        extra = xml_classes - set(names)
        if extra:
            print(f"  [warn] XML 有而 classes.txt 无的类别: {extra}")
    else:
        # 没有 classes.txt, 用 XML 类别自建
        names = sorted(xml_classes)
        name2id = {n: i for i, n in enumerate(names)}
        print(f"  无 classes.txt, 按 XML 类别自建 {len(names)} 类")

    # 划分: 若目录本身已分 train/val/test 则遵循; 否则 8:1:1 分层
    def split_of(p: Path):
        low = str(p).lower()
        for sp in ("train", "val", "valid", "test"):
            if f"{sp}" in [seg.lower() for seg in p.parts]:
                return "val" if sp == "valid" else sp
        return None

    pre_split = defaultdict(list)
    auto_split = []
    for rec in records:
        sp = split_of(rec[0])
        (pre_split[sp] if sp else auto_split).append(rec) if sp else auto_split.append(rec)
    if auto_split:
        # 按主类别(框最多的类)分层
        by_cls = defaultdict(list)
        for rec in auto_split:
            main_cls = Counter(b[0] for b in rec[1]).most_common(1)[0][0]
            by_cls[main_cls].append(rec)
        for cls, recs in by_cls.items():
            random.shuffle(recs)
            n = len(recs)
            n_test = max(1, round(n * 0.1)) if n >= 3 else 0
            n_val = max(1, round(n * 0.1)) if n >= 3 else 0
            for i, rec in enumerate(recs):
                sp = "test" if i < n_test else "val" if i < n_test + n_val else "train"
                pre_split[sp].append(rec)

    out_d = out_dir / "Detection"
    cnt = Counter()
    for sp in ("train", "val", "test"):
        for jpg, boxes in pre_split.get(sp, []):
            link_or_copy(jpg, out_d / "images" / sp / jpg.name, link_mode)
            label_lines = []
            for cls, xc, yc, w, h in boxes:
                cid = name2id.get(cls)
                if cid is None:
                    continue
                label_lines.append(f"{cid} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}")
                cnt[cls] += 1
            (out_d / "labels" / sp).mkdir(parents=True, exist_ok=True)
            (out_d / "labels" / sp / f"{jpg.stem}.txt").write_text(
                "\n".join(label_lines), encoding="utf-8")

    # data.yaml (ultralytics)
    yaml_text = (
        f"path: {out_d.resolve()}\n"
        f"train: images/train\nval: images/val\ntest: images/test\n\n"
        f"names:\n" + "\n".join(f"  {i}: {n}" for i, n in enumerate(names)) + "\n"
    )
    (out_d / "data.yaml").write_text(yaml_text, encoding="utf-8")

    mp = mapping["mappings"]
    class_map = {n: {"dataset_label_0based": i, "zh": mp.get(n, {}).get("zh"),
                     "kg_entity_type": mp.get(n, {}).get("kg_entity_type"),
                     "kg_id": mp.get(n, {}).get("kg_id"),
                     "kg_name": mp.get(n, {}).get("kg_name")}
                 for i, n in enumerate(names)}
    (out_d / "class_map.json").write_text(
        json.dumps(class_map, ensure_ascii=False, indent=2), encoding="utf-8")
    split_stats = {sp: len(pre_split.get(sp, [])) for sp in ("train", "val", "test")}
    (out_d / "stats.json").write_text(
        json.dumps({"images_per_split": split_stats, "boxes_per_class": dict(cnt)},
                   ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  划分(图片数): {split_stats}")
    print(f"  各类标注框数: {dict(cnt)}")
    print(f"  -> {out_d}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="含 CottonInsect_classification/ 与 CottonInsect_detection/ 的目录")
    ap.add_argument("--mapping", default="../configs/cottoninsect_mapping.json")
    ap.add_argument("--out", default="datasets")
    ap.add_argument("--link", choices=["hard", "symlink", "copy"], default="hard",
                    help="图片放置方式: hard=硬链接(默认,省空间), symlink=软链接, copy=复制")
    args = ap.parse_args()

    root = Path(args.root)
    mapping = json.loads(Path(args.mapping).read_text(encoding="utf-8"))
    out_dir = Path(args.out)

    cls_dir = root / "CottonInsect_classification"
    det_dir = root / "CottonInsect_detection"
    if cls_dir.exists():
        convert_classification(cls_dir, out_dir, mapping, args.link)
    else:
        print(f"[warn] 分类版目录不存在: {cls_dir}")
    if det_dir.exists():
        convert_detection(det_dir, out_dir, mapping, args.link)
    else:
        print(f"[warn] 检测版目录不存在: {det_dir}")


if __name__ == "__main__":
    main()
