#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
14_extract_morphology.py
从 v3 知识图谱自动抽取「视觉形态描述」, 生成 CLIP 语义分支专用的形态表初稿。
不修改原图谱, 产物仅供 KG prompt 构建使用。

数据来源:
  - 害虫(pest): 关系 Pest_Form + 实体 Form(成虫形态短语), 多条去重清洗后聚合
  - 病害(disease): 关系 Disease_Symptom + 实体 Symptom(取前 N 条可见病征)
  - 天敌(enemy): 图谱无形态表, 用人工草稿占位, need_review=1 待你核对
  - 生理病害(disorder): 暂用症状(若有)

输入:
  --link   merged/kg_link.json  (10号脚本产物, 锁定 22 个视觉类与 kg_id)
  --kg-dir v3_合并全量 目录(含 实体/ 关系/)
输出:
  outputs/morphology/morphology.csv 与 .json
  字段: visual_class, kg_id, entity_type, morph_zh, morph_en(待翻译),
        source(auto_form/auto_symptom/manual_enemy), n_fragments, need_review

用法:
  python scripts/14_extract_morphology.py \
      --link merged/kg_link.json \
      --kg-dir ../cotton_kg/augmented/v3_合并全量 \
      --out outputs/morphology/morphology
"""
import argparse
import csv
import json
import re
import sys
from pathlib import Path

import openpyxl

# 天敌人工草稿(图谱无形态表); 仅 3 个视觉类用到, 需植保/你本人核对
ENEMY_DRAFT = {
    120001: "成虫体背光滑呈半球形，鞘翅多为红色或橙色并具黑色斑点，触角短呈棒状",
    120002: "成虫体细长柔弱，体色嫩绿，复眼具金属光泽，翅宽大透明、翅脉呈网状",
    120003: "成虫形似蜜蜂，腹部黄黑相间，体表光滑无毛，仅具一对发达前翅",
}

ENTITY_TYPE_CN = {"pest": "害虫", "disease": "病害", "enemy": "天敌", "disorder": "生理病害"}


def load_entity(path: Path, name_col: int = 2):
    """实体表 -> {id: name}。表头 :ID/:LABEL/name。"""
    if not path.exists():
        return {}
    ws = openpyxl.load_workbook(path, read_only=True).active
    it = ws.iter_rows(values_only=True)
    next(it, None)
    return {r[0]: r[name_col] for r in it if r[0] is not None and r[name_col]}


def load_relation(path: Path):
    """关系表 -> [(start_id, end_id)]。"""
    if not path.exists():
        return []
    ws = openpyxl.load_workbook(path, read_only=True).active
    it = ws.iter_rows(values_only=True)
    next(it, None)
    return [(r[1], r[2]) for r in it if r[1] is not None and r[2] is not None]


def clean_text(s: str) -> str:
    """轻度清洗形态短语, 不改语义。"""
    if s is None:
        return ""
    s = str(s).strip()
    s = s.replace(",", "，")            # 统一逗号
    s = re.sub(r"(\d)，(?=\d)", r"\1.", s)  # 录入错: 数字间逗号当小数点, 如 1,9 -> 1.9
    s = re.sub(r"\s+", "", s)          # 形态短语内去多余空白
    s = s.strip("；;，,。 ")
    return s


def dedup_keep_order(seq):
    seen = set()
    out = []
    for x in seq:
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out


def attach_names(kg_dir: Path, rel_file: str, id2name: dict):
    """start_id -> [去重后的 end 实体名]。"""
    bucket = {}
    for sid, eid in load_relation(kg_dir / "关系" / rel_file):
        name = id2name.get(eid)
        if name:
            bucket.setdefault(sid, []).append(name)
    return {sid: dedup_keep_order([clean_text(n) for n in names])
            for sid, names in bucket.items()}


def build_indexes(kg_dir: Path):
    form = load_entity(kg_dir / "实体" / "Form.xlsx")
    symptom = load_entity(kg_dir / "实体" / "Symptom.xlsx")
    pest_form = attach_names(kg_dir, "Pest_Form.xlsx", form)
    larva_form = attach_names(kg_dir, "Pest_Larva.xlsx", form)
    disease_sym = attach_names(kg_dir, "Disease_Symptom.xlsx", symptom)
    disorder_sym = attach_names(kg_dir, "Disorder_Symptom.xlsx", symptom)
    return {
        "form": form, "pest_form": pest_form, "larva_form": larva_form,
        "disease_sym": disease_sym, "disorder_sym": disorder_sym,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--link", default="merged/kg_link.json")
    ap.add_argument("--kg-dir", default="../cotton_kg/augmented/v3_合并全量")
    ap.add_argument("--out", default="outputs/morphology/morphology")
    ap.add_argument("--max-symptoms", type=int, default=5)
    args = ap.parse_args()

    link_p, kg_dir = Path(args.link), Path(args.kg_dir)
    if not link_p.exists():
        print(f"❌ 找不到 {link_p}", file=sys.stderr); sys.exit(1)
    if not kg_dir.exists():
        print(f"❌ 找不到图谱目录 {kg_dir}", file=sys.stderr); sys.exit(1)

    kg_link = json.loads(link_p.read_text(encoding="utf-8"))
    idx = build_indexes(kg_dir)

    rows = []
    n_auto = n_manual = n_sym = n_empty = 0
    for vclass, info in kg_link.items():
        kg_id = int(info["kg_id"])
        etype = info.get("entity_type")
        morph_parts, source, need_review, nfrag = [], "empty", 0, 0

        if etype == "pest":
            adult = idx["pest_form"].get(kg_id, [])
            larva = idx["larva_form"].get(kg_id, [])
            if adult:
                morph_parts.extend(adult); nfrag += len(adult)
            if larva:
                morph_parts.append("幼虫：" + "，".join(larva)); nfrag += len(larva)
            if morph_parts:
                source, n_auto = "auto_form", n_auto + 1
        elif etype in ("disease", "disorder"):
            sym = (idx["disease_sym"].get(kg_id) or idx["disorder_sym"].get(kg_id, []))[:args.max_symptoms]
            if sym:
                morph_parts.extend(sym); nfrag += len(sym)
                source, n_sym = "auto_symptom", n_sym + 1
        if etype == "enemy" or not morph_parts:
            draft = ENEMY_DRAFT.get(kg_id)
            if draft:
                morph_parts, source, need_review, nfrag = [draft], "manual_enemy", 1, 1
                n_manual += 1

        morph_zh = "；".join(dedup_keep_order(morph_parts))
        if not morph_zh:
            n_empty += 1
            need_review = 1
            source = "empty"

        rows.append({
            "visual_class": vclass,
            "kg_id": kg_id,
            "entity_type": etype,
            "entity_type_cn": ENTITY_TYPE_CN.get(etype, etype),
            "morph_zh": morph_zh,
            "morph_en": "",                 # 留待翻译(open_clip 用)
            "source": source,
            "n_fragments": nfrag,
            "need_review": need_review,
        })

    # 按 kg_id 排序, 稳定可读
    rows.sort(key=lambda r: r["kg_id"])

    out_p = Path(args.out)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    (out_p.with_suffix(".json")).write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    with open(out_p.with_suffix(".csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    print(f"✅ 共 {len(rows)} 类 -> {out_p.with_suffix('.csv').resolve()} / .json")
    print(f"   害虫形态自动抽取 {n_auto} | 病害症状顶替 {n_sym} | 天敌人工草稿 {n_manual} | 仍为空 {n_empty}")
    print("-" * 90)
    for r in rows:
        flag = "  ⚠待审" if r["need_review"] else ""
        txt = r["morph_zh"][:60] + ("…" if len(r["morph_zh"]) > 60 else "")
        print(f"{r['kg_id']:>6} {r['entity_type_cn']:<4} {r['visual_class']:<8} "
              f"[{r['source']:<12}] {txt}{flag}")
    print("-" * 90)
    print("下一步: 核对 morph_zh(尤其 ⚠待审 的天敌/空值), 补 morph_en, 再进 15 号 prompt 构建脚本。")


if __name__ == "__main__":
    main()
