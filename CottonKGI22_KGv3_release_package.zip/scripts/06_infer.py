#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
06_infer.py
用训练好的 YOLO 模型对图片/文件夹推理, 输出标准化检测 JSON (供 04_entity_linking.py)。

  python 06_infer.py detect --weights runs/.../weights/best.pt \
      --source /path/to/images --class-map datasets/Detection/class_map.json \
      --out outputs/preds.json [--part 叶片 --stage 蕾期]

  python 06_infer.py classify --weights runs/.../weights/best.pt \
      --source /path/to/images --class-map datasets/Classification/class_map.json \
      --out outputs/preds.json

输出 JSON: {"image":..., "context":{"part":..,"stage":..},
            "detections":[{"dataset_class":..,"score":..,"bbox":[x,y,w,h]}...]}
检测模型每张图一个文件; 分类模型 top-5。
"""
import argparse
import json
import sys
from pathlib import Path

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def iter_images(source: Path):
    if source.is_file():
        return [source]
    return [p for p in source.rglob("*") if p.suffix.lower() in IMG_EXTS]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("task", choices=["detect", "classify"])
    ap.add_argument("--weights", required=True)
    ap.add_argument("--source", required=True)
    ap.add_argument("--class-map", required=True)
    ap.add_argument("--out", default="outputs/preds.json")
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--imgsz", type=int, default=None,
                    help="推理尺寸, 分类模型建议与训练一致(如224); 不传则用模型默认")
    ap.add_argument("--part", default=None, help="拍摄部位, 如 叶片/蕾/棉铃/根 (KG约束用)")
    ap.add_argument("--stage", default=None, help="棉花生育期, 如 苗期/蕾期/花铃期 (KG约束用)")
    args = ap.parse_args()

    try:
        from ultralytics import YOLO
    except ImportError:
        print("请先安装: pip install ultralytics", file=sys.stderr)
        sys.exit(1)

    class_map = json.loads(Path(args.class_map).read_text(encoding="utf-8"))
    # id -> dataset_class 名
    id2name = {v["dataset_label_0based"]: k for k, v in class_map.items()}

    model = YOLO(args.weights)
    images = iter_images(Path(args.source))
    context = {k: v for k, v in (("part", args.part), ("stage", args.stage)) if v}

    all_out = []
    for img in images:
        infer_kw = {"conf": args.conf, "verbose": False}
        if args.imgsz is not None:
            infer_kw["imgsz"] = args.imgsz
        res = model(str(img), **infer_kw)[0]
        dets = []
        if args.task == "detect":
            for b in res.boxes:
                cid = int(b.cls.item())
                x1, y1, x2, y2 = b.xywh[0].tolist()  # xywh 像素
                dets.append({
                    "dataset_class": id2name.get(cid, str(cid)),
                    "score": round(float(b.conf.item()), 4),
                    "bbox": [round(x1, 1), round(y1, 1), round(x2, 1), round(y2, 1)],
                })
        else:
            names = res.names
            probs = res.probs
            top5 = probs.top5
            for cid in top5:
                dets.append({
                    "dataset_class": id2name.get(cid, names[cid]),
                    "score": round(float(probs.data[cid]), 4),
                })
        all_out.append({"image": str(img), "context": context, "detections": dets})

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(all_out if len(all_out) > 1 else all_out[0],
                              ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"推理 {len(all_out)} 张图 -> {out.resolve()}")
    print("下一步: python 04_entity_linking.py --dets <该文件> --class-map ... --kg outputs/kg_constraints.json")


if __name__ == "__main__":
    main()
