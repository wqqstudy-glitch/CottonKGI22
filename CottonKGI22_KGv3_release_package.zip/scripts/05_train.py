#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
05_train.py
基于 Ultralytics YOLOv11 训练 CottonInsect 分类 / 检测模型。

终端输出(干净模式):
  - 每轮只占一行:  Epoch  1/10 | GPU 2.67G | loss 1.5710 | top1 0.6520 | top5 0.9130 | 640px | 348s
  - 不再打印"混淆矩阵已保存"等提示, 混淆矩阵仍每轮自动保存(PNG + JSON)
  - 压制 matplotlib 缺中文字形的刷屏警告

每轮 epoch 验证结束自动:
  1) 静默导出混淆矩阵到 outputs/confusion_per_epoch/<run带时间戳>/
  2) 追加本轮指标到 outputs/train_logs/<run带时间戳>_epochs.csv
  3) 训练结束生成 outputs/train_logs/<run带时间戳>_summary.json

分类训练 (ImageFolder):
  python 05_train.py classify --data merged --model yolo11s-cls.pt --epochs 50 --device 0
检测训练:
  python 05_train.py detect  --data datasets/Detection/data.yaml --model yolo11s.pt --epochs 100 --device 0
"""
import argparse
import csv
import json
import sys
import time
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np


def to_num(x, nd=4):
    """0-dim Tensor / np 标量 / float -> Python float; 非法返回 None。"""
    if x is None:
        return None
    try:
        return round(float(x), nd)
    except (TypeError, ValueError):
        return None


def gpu_mem_gb(trainer):
    """trainer.gpu_mem 可能是 0-dim tensor / list / 标量, 统一成 GB 浮点。"""
    g = getattr(trainer, "gpu_mem", None)
    if g is None:
        return None
    try:
        if hasattr(g, "__len__") and len(g) > 0:
            return round(float(np.sum(np.asarray(g, dtype=float))), 2)
        return round(float(g), 2)
    except (TypeError, ValueError):
        return None


def append_csv_safe(path, row, retries=4, wait=0.6):
    """追加一行 CSV; Windows 下文件可能被 Excel/杀软短暂锁定, 重试, 仍失败则放弃(不崩训练)。"""
    for i in range(retries):
        try:
            with open(path, "a", newline="", encoding="utf-8-sig") as f:
                csv.writer(f).writerow(row)
            return True
        except PermissionError:
            if i < retries - 1:
                time.sleep(wait)
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("task", choices=["detect", "classify"])
    ap.add_argument("--data", required=True, help="detect: data.yaml; classify: ImageFolder 目录")
    ap.add_argument("--model", default=None, help="yolo11s.pt / yolo11s-cls.pt")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--device", default=None, help="如 0 / cpu; 不传则自动")
    ap.add_argument("--workers", type=int, default=8,
                    help="数据加载进程数, 预取数据喂饱 GPU; Windows 出多进程问题再降到 0")
    ap.add_argument("--cache", default=None, choices=[None, "ram", "disk"],
                    help="ram=图像缓存进内存(最快, 需内存够); disk=缓存到磁盘; 不传=不缓存")
    ap.add_argument("--project", default="runs/cottoninsect")
    ap.add_argument("--name", default=None)
    args = ap.parse_args()

    # ---------- 依赖 + 中文字体 + 警告压制(必须在创建任何图之前) ----------
    try:
        from ultralytics import YOLO
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import seaborn as sns  # noqa: F401
        # Windows 优先微软雅黑/黑体, 兼顾 macOS/Linux
        for _f in ["Microsoft YaHei", "SimHei", "PingFang SC", "Heiti SC",
                   "WenQuanYi Zen Hei", "Noto Sans CJK SC", "Arial Unicode MS"]:
            try:
                from matplotlib.font_manager import findfont, FontProperties
                if findfont(FontProperties(family=_f), fallback_to_default=False):
                    plt.rcParams["font.sans-serif"] = [_f]
                    break
            except Exception:
                continue
        plt.rcParams["axes.unicode_minus"] = False
        # 彻底压掉缺中文字形的刷屏警告(每个汉字一条那种)
        warnings.filterwarnings("ignore", message=r".*Glyph.*")
        warnings.filterwarnings("ignore", message=r".*missing from font.*")
    except ImportError:
        print("请先安装依赖: pip install ultralytics matplotlib seaborn", file=sys.stderr)
        sys.exit(1)

    # ---------- 每次运行带时间戳, 多跑不覆盖 ----------
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = args.name or ("detect_yolo11s" if args.task == "detect" else "classify_yolo11s")
    run_name = f"{base}_{ts}"
    out_confusion = Path("outputs") / "confusion_per_epoch" / run_name
    out_logs = Path("outputs") / "train_logs"
    out_confusion.mkdir(parents=True, exist_ok=True)
    out_logs.mkdir(parents=True, exist_ok=True)

    csv_path = out_logs / f"{run_name}_epochs.csv"
    summary_path = out_logs / f"{run_name}_summary.json"
    if args.task == "classify":
        csv_header = ["epoch", "epoch_sec", "gpu_mem_gb", "train_loss",
                      "val_top1_acc", "val_top5_acc", "val_loss"]
        model_w = args.model or "yolo11s-cls.pt"
    else:
        csv_header = ["epoch", "epoch_sec", "gpu_mem_gb", "train_loss",
                      "precision", "recall", "mAP50", "mAP50_95"]
        model_w = args.model or "yolo11s.pt"
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerow(csv_header)

    train_start = time.time()
    run_epochs = []
    seen_epochs = set()
    state = {"trainer": None, "epoch_t0": None, "n_epochs": args.epochs}

    model = YOLO(model_w)

    train_kwargs = dict(
        data=str(Path(args.data).resolve()),
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        project=args.project,
        name=run_name,
        optimizer="AdamW",
        lr0=0.001,
        exist_ok=True,
        verbose=False,          # 关掉多行进度条/每轮表格, 由回调打印单行
        workers=args.workers,
    )
    if args.cache is not None:
        train_kwargs["cache"] = args.cache
    if args.device is not None:
        train_kwargs["device"] = args.device

    # ---------------------- 回调 ----------------------
    def on_train_start(trainer):
        state["trainer"] = trainer
        state["n_epochs"] = getattr(trainer, "epochs", args.epochs)

    def on_epoch_start(trainer):
        state["trainer"] = trainer
        state["epoch_t0"] = time.time()
        i = int(trainer.epoch) + 1
        # 同一行先占位, 验证完用结果覆盖(\r)
        sys.stdout.write(f"\rEpoch {i:>3}/{state['n_epochs']} | 训练中 ...")
        sys.stdout.flush()

    def on_val_end(validator):
        try:
            trainer = state["trainer"]
            if trainer is None:
                return
            epoch_idx = int(trainer.epoch) + 1
            if epoch_idx in seen_epochs:
                return  # 末轮 final_eval 用 best.pt 的重复验证, 跳过
            seen_epochs.add(epoch_idx)
            epoch_sec = round(time.time() - (state["epoch_t0"] or train_start), 1)
            gpu = gpu_mem_gb(trainer)
            loss = to_num(getattr(trainer, "loss", None))
            m = getattr(validator, "metrics", None)

            # 1) 混淆矩阵 —— 静默保存, 不打印
            cm_obj = getattr(m, "confusion_matrix", None)
            class_names = dict(getattr(validator, "names", {}) or {})
            labels = list(class_names.values())
            if args.task == "detect":
                labels = labels + ["background"]
            if cm_obj is not None:
                cm = np.asarray(cm_obj.matrix, dtype=float)
                save_img = out_confusion / f"confusion_epoch_{epoch_idx:03d}.png"
                save_json = out_confusion / f"confusion_epoch_{epoch_idx:03d}.json"
                with open(save_json, "w", encoding="utf-8") as f:
                    json.dump({"epoch": epoch_idx, "class_names": labels,
                               "confusion_matrix": cm.tolist()}, f, indent=2, ensure_ascii=False)
                plt.figure(figsize=(10, 8))
                sns.heatmap(cm, annot=True, fmt=".0f", cmap="Blues",
                            xticklabels=labels, yticklabels=labels)
                plt.xlabel("Predicted"); plt.ylabel("True")
                plt.title(f"Confusion Matrix Epoch {epoch_idx} ({args.task})")
                plt.tight_layout()
                plt.savefig(save_img, dpi=300)
                plt.close()

            # 2) 指标行
            if args.task == "classify":
                top1, top5 = to_num(getattr(m, "top1", None)), to_num(getattr(m, "top5", None))
                vloss = to_num(getattr(m, "loss", None))
                row = [epoch_idx, epoch_sec, gpu if gpu is not None else "",
                       loss if loss is not None else "",
                       top1 if top1 is not None else "",
                       top5 if top5 is not None else "",
                       vloss if vloss is not None else ""]
                line = (f"\rEpoch {epoch_idx:>3}/{state['n_epochs']} | "
                        f"GPU {gpu if gpu is not None else '-'}G | loss {loss if loss is not None else '-'} | "
                        f"top1 {top1 if top1 is not None else '-'} | top5 {top5 if top5 is not None else '-'} | "
                        f"{args.imgsz}px | {epoch_sec}s")
            else:
                box = getattr(m, "box", None)
                map50 = to_num(getattr(box, "map50", None))
                map5095 = to_num(getattr(box, "map", None))
                rd = getattr(m, "results_dict", {}) or {}
                map50 = map50 if map50 is not None else to_num(rd.get("metrics/mAP50(B)"))
                map5095 = map5095 if map5095 is not None else to_num(rd.get("metrics/mAP50-95(B)"))
                prec = to_num(rd.get("metrics/precision(B)"))
                rec = to_num(rd.get("metrics/recall(B)"))
                row = [epoch_idx, epoch_sec, gpu if gpu is not None else "",
                       loss if loss is not None else "",
                       prec if prec is not None else "", rec if rec is not None else "",
                       map50 if map50 is not None else "", map5095 if map5095 is not None else ""]
                line = (f"\rEpoch {epoch_idx:>3}/{state['n_epochs']} | "
                        f"GPU {gpu if gpu is not None else '-'}G | loss {loss if loss is not None else '-'} | "
                        f"mAP50 {map50 if map50 is not None else '-'} | mAP50-95 {map5095 if map5095 is not None else '-'} | "
                        f"{args.imgsz}px | {epoch_sec}s")

            append_csv_safe(csv_path, row)
            run_epochs.append(dict(zip(csv_header, row)))
            # 3) 每轮最终就这一行(\r 覆盖"训练中", 换行结束)
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
        except Exception as e:
            # 绘图/记录任何异常都不允许中断训练
            print(f"\n⚠️ epoch 记录失败(已忽略, 训练继续): {e}")

    model.add_callback("on_train_start", on_train_start)
    model.add_callback("on_train_epoch_start", on_epoch_start)
    model.add_callback("on_val_end", on_val_end)

    print(f"开始训练: task={args.task} model={model_w} device={args.device or 'auto'} "
          f"imgsz={args.imgsz} batch={args.batch}")
    print(f"权重/曲线目录: {Path(args.project) / run_name}")
    print(f"混淆矩阵目录: {out_confusion.resolve()}  (每轮自动保存)")
    print(f"逐轮指标 CSV: {csv_path.resolve()}")
    print("-" * 72)

    model.train(**train_kwargs)

    summary = {
        "task": args.task, "model": model_w,
        "data": str(Path(args.data).resolve()),
        "run_name": run_name,
        "epochs_requested": args.epochs, "epochs_recorded": len(run_epochs),
        "imgsz": args.imgsz, "batch": args.batch,
        "device": args.device or "auto",
        "total_minutes": round((time.time() - train_start) / 60, 2),
        "epoch_records": run_epochs,
        "csv_file": str(csv_path.resolve()),
        "confusion_dir": str(out_confusion.resolve()),
    }
    try:
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        print("-" * 72)
        print(f"训练完成，汇总 → {summary_path}")
    except PermissionError:
        alt = summary_path.with_name(summary_path.stem + "_backup.json")
        with open(alt, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        print(f"⚠️ 原汇总被占用, 已改存 → {alt}(请关闭 Excel 等占用程序)")
    print("best 权重 → runs/.../weights/best.pt")


if __name__ == "__main__":
    main()
