# CottonInsect 视觉识别 → 棉花病虫害知识图谱实体链接 流水线

把 CottonInsect 数据集（新疆棉田昆虫，13 类）接入棉花病虫害知识图谱（v3，87 种目标实体）的完整代码流水线：
**数据探查 → 格式转换 → KG 约束导出 → YOLO 训练 → 推理 → 实体链接+约束重排 → 图谱问答查询**。

## 目录结构

```
vision/
├── configs/
│   └── cottoninsect_mapping.json   # 数据集类别 ↔ KG 实体映射表 (核心配置, 可人工修订)
├── scripts/
│   ├── 01_export_kg_constraints.py # 从 v3 图谱导出每个实体的部位/生育期/症状/天敌 (重排依据)
│   ├── 02_inspect_dataset.py       # 探查数据集结构, 出数据画像+映射核对报告
│   ├── 03_convert_dataset.py       # 转训练就绪格式: 分类版→ImageFolder, 检测版→YOLO(VOC→txt)
│   ├── 04_entity_linking.py        # 推理结果→KG实体链接 + 部位/生育期约束重排
│   ├── 05_train.py                 # YOLOv11 检测/分类训练
│   ├── 06_infer.py                 # 模型推理 → 标准化检测 JSON
│   └── 07_query_kg.py              # 按 kg_id/名称 查防治方法、药剂、症状、天敌等
├── kg_data/
│   └── v3_合并全量/                 # 知识图谱 Excel (实体14表+关系23表, 已随包附带)
├── outputs/                        # 运行产物 (json 报告/结果; kg_constraints.json 已预生成)
├── datasets/                       # 03 脚本生成的训练数据
└── requirements.txt
```

> 注意：`kg_data/v3_合并全量/` 就是知识图谱，01/07 脚本的 `--kg-dir` 直接指它，**不需要再找图谱文件**。
> `outputs/kg_constraints.json` 已预生成，不跑 01 也能直接做 04 实体链接。

## 数据集真实结构（已核对）

- `CottonInsect_classification/`：分类版，`pest_dataset/{train,val,test}/*.jpg` 扁平存放；
  `train.txt/val.txt/test.txt` 每行 `文件名 标签`；**标签为 0-based**；`classes.txt` 13 类
  （lacewing 草蛉、ladybug_dy/ladybug_lbq/ladybug_hb 三种瓢虫、stinkbug_mx/mc/lv/hsy/ccc/zh
  六种盲蝽/蝽、syrphid 食蚜蝇、bollworm 棉铃虫、bee 蜂）。train 2587 / val 323 / test 315 = 3225 张。
- `CottonInsect_detection/CottonInsect_detection/`：标准 VOC，`Annotations/*.xml` + `JPEGImages/*.jpg` + `classes.txt`。

## 使用步骤

```bash
cd vision
pip install -r requirements.txt   # 建议 Python 3.10/3.11; Mac M 系列训练时加 --device mps
```

> **PyCharm 用户注意**：下面的 `$DATA_ROOT` / `$KG_DIR` 是 shell 变量，在 PyCharm 的「运行配置」里
> 不会被替换（会报 `$KG_DIR/实体/Pestis.xlsx` 找不到）。两种办法：① 在系统终端里先
> `DATA_ROOT="..."` 再跑命令；② 直接把字面路径写进参数，例如
> `python scripts/01_export_kg_constraints.py --kg-dir kg_data/v3_合并全量 --out outputs/kg_constraints.json`。

```bash
# 0. 路径变量 (按你的实际位置改; KG_DIR 不用改, 图谱已随包在 kg_data/ 下)
DATA_ROOT="/Users/os11/Downloads/b0d40-main 2"   # 含两个 CottonInsect_* 目录
KG_DIR="kg_data/v3_合并全量"

# 1. 导出 KG 约束信息 (实体的为害部位/发生时期/症状/天敌)
#    outputs/kg_constraints.json 已预生成, 可跳过本步; 想自己重新导出再跑:
python scripts/01_export_kg_constraints.py --kg-dir "$KG_DIR" --out outputs/kg_constraints.json

# 2. 探查数据集 + 核对映射 (先跑这个, 检查 outputs/dataset_report.json 有无 UNMAPPED)
python scripts/02_inspect_dataset.py --root "$DATA_ROOT" \
    --mapping configs/cottoninsect_mapping.json --out outputs/dataset_report.json

# 3. 转换为训练格式 (硬链接, 不占额外空间; 跨盘失败自动回退复制)
python scripts/03_convert_dataset.py --root "$DATA_ROOT" \
    --mapping configs/cottoninsect_mapping.json --out datasets --link hard

# 4a. 训练检测模型 (YOLOv11)
python scripts/05_train.py detect --data datasets/Detection/data.yaml \
    --model yolo11s.pt --epochs 100 --batch 16 --name detect_v1
# 4b. 或训练分类模型
python scripts/05_train.py classify --data datasets/Classification \
    --model yolo11s-cls.pt --epochs 100 --batch 16 --name cls_v1

# 5. 推理 (--part/--stage 可选, 提供后 KG 约束重排生效)
python scripts/06_infer.py detect --weights runs/cottoninsect/detect_v1/weights/best.pt \
    --source /path/to/field_photos --class-map datasets/Detection/class_map.json \
    --out outputs/preds.json --part 叶片 --stage 蕾期

# 6. 实体链接 + KG 约束重排
python scripts/04_entity_linking.py --dets outputs/preds.json \
    --class-map datasets/Detection/class_map.json \
    --kg outputs/kg_constraints.json --out outputs/linking_result.json

# 7. 查图谱 (问答系统取防治信息; 可直接用 linking 结果的 top1)
python scripts/07_query_kg.py --kg-dir "$KG_DIR" --linking outputs/linking_result.json
python scripts/07_query_kg.py --kg-dir "$KG_DIR" --name 绿盲蝽
```

## 关键设计说明

1. **训练标签保持 13 个细类**（模型学细粒度特征）；**类别→KG 实体的聚合在推理后做**
   （三种瓢虫聚合到「瓢虫类 120001」）。映射集中在 `configs/cottoninsect_mapping.json`，一处维护。
2. **映射现状**：
   - 直接命中 KG 虫害：棉铃虫(20002)、绿/中黑/苜蓿/牧草盲蝽(20009/20010/20032/20042)
   - 命中天敌类群：草蛉→草蛉类(120002)、3 种瓢虫→瓢虫类(120001)、食蚜蝇→食蚜蝇类(120003)
   - 不链接：茶翅蝽(非棉花目标)、蜂(中性昆虫，若实拍为寄生蜂需改映射)
   - 待植保核实：黑食蚜盲蝽（食蚜盲蝽属多为捕食性，但原数据集论文归害虫组）
   - 待核实中文名：ladybug_dy（疑似多异瓢虫）、ladybug_lbq（缩写不明）；类群级映射不受影响
3. **KG 约束重排**：视觉置信度 × 部位匹配系数(0.35) × 生育期匹配系数(0.6)。
   例如拍的是蕾期叶片，铃期病害/蛀蕾害虫以外的候选会被降权。系数在 04 脚本顶部可调。
4. **03 脚本默认硬链接**，不复制图片、不改动原始数据；转换产物全部在 `datasets/`。
5. 检测版若发布时未带 train/val/test 划分，03 脚本按主类别分层自动 8:1:1 划分。

## 已知待办（需人工/植保专家参与）

- [ ] 抽图核实 ladybug_dy / ladybug_lbq / bee 的具体物种，修订映射表 note
- [ ] 黑食蚜盲蝽的益害归属需植保专家确认
- [ ] 检测版 classes.txt 与 XML 内类别名需跑一次 02 脚本核对（若不一致脚本会告警）
- [ ] 后续数据集（IP102、Mendeley 棉花叶病等）接入时，在 configs/ 新增对应映射 json，03/06 脚本的 --class-map 指向各自映射即可复用
