# -*- coding: utf-8 -*-
"""
20_clean_cross_split.py
清理 merged 数据集中的字节级重复图像（含跨 train/val/test 泄漏）。

规则：
  1) 计算 merged/{train,val,test}/<类>/* 全部图片的文件级 MD5；
  2) 同一 MD5（内容完全相同）的所有文件归为一组；
  3) 每组按 split 优先级  test > val > train  只保留一个文件，
     其余从「干净数据集」中剔除 —— 即保证 test 完整，重复图优先从 train/val 删除；
  4) 保留文件复制到 --out（默认 merged_clean），不修改原 merged；
  5) 输出明细 CSV 与汇总 JSON。

注意：文件级 MD5 只能识别字节完全相同的图，不识别内容相近但压缩/尺寸/裁剪不同的近重复图。
"""
import argparse
import csv
import hashlib
import json
import os
import shutil
from pathlib import Path

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
SPLITS = ["train", "val", "test"]
# 数值越小优先级越高（test 优先保留）
RANK = {"test": 0, "val": 1, "train": 2}


def md5_of(p: Path) -> str:
    h = hashlib.md5()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def scan(merged: Path):
    """返回 [(split, cls, fname, md5, size), ...]。"""
    records = []
    for sp in SPLITS:
        sp_dir = merged / sp
        if not sp_dir.is_dir():
            continue
        for cls_dir in sorted(p for p in sp_dir.iterdir() if p.is_dir()):
            for img in sorted(p for p in cls_dir.iterdir() if p.suffix.lower() in IMG_EXTS):
                records.append((sp, cls_dir.name, img.name, md5_of(img), img.stat().st_size))
    return records


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--merged", default="merged", help="原始 merged 目录（只读，不修改）")
    ap.add_argument("--out", default="merged_clean", help="干净数据集输出目录")
    ap.add_argument("--link", choices=["copy", "hard"], default="copy",
                    help="copy=复制文件(默认,稳);hard=同盘硬链接(快,不占额外空间)")
    args = ap.parse_args()

    merged = Path(args.merged)
    out = Path(args.out)
    if not merged.is_dir():
        raise SystemExit(f"找不到 merged 目录: {merged}")
    if out.resolve() == merged.resolve():
        raise SystemExit("--out 不能与 --merged 相同")

    print(f"扫描 {merged} ...")
    records = scan(merged)
    print(f"图片总数 = {len(records)}")

    # 按 md5 分组
    groups = {}
    for rec in records:
        groups.setdefault(rec[3], []).append(rec)

    # 每组选保留项：先按 split 优先级，再按类名、文件名保证确定性
    keep = {}          # md5 -> 保留的 rec
    detail_rows = []   # 明细
    for md5, recs in groups.items():
        ordered = sorted(recs, key=lambda r: (RANK.get(r[0], 9), r[1], r[2]))
        chosen = ordered[0]
        keep[md5] = chosen
        splits = sorted({r[0] for r in recs})
        is_cross = len(splits) > 1
        for r in recs:
            detail_rows.append({
                "md5": md5,
                "组内文件数": len(recs),
                "涉及split": "/".join(splits),
                "是否跨split": "是" if is_cross else "否",
                "split": r[0],
                "class": r[1],
                "file": r[2],
                "bytes": r[4],
                "处理": "保留" if r is chosen else "剔除",
            })

    # 终端打印跨 split 组
    cross_md5 = [m for m, recs in groups.items() if len({r[0] for r in recs}) > 1]
    print(f"\n重复组总数 = {sum(1 for recs in groups.values() if len(recs)>1)}")
    print(f"跨 split 泄漏组 = {len(cross_md5)}")
    for i, m in enumerate(sorted(cross_md5), 1):
        recs = sorted(groups[m], key=lambda r: (RANK.get(r[0], 9), r[1], r[2]))
        chosen = keep[m]
        print(f"  [{i}] md5 {m[:12]}  splits={sorted({r[0] for r in recs})}")
        for r in recs:
            tag = "保留" if r is chosen else "剔除"
            print(f"        {r[0]:5s} {r[1]:12s} {r[2]}   -> {tag}")

    # 准备输出目录
    out.mkdir(parents=True, exist_ok=True)

    # 复制保留图片
    n_kept = 0
    per_split = {sp: 0 for sp in SPLITS}
    per_class = {}
    for md5, rec in keep.items():
        sp, cls, fname = rec[0], rec[1], rec[2]
        src = merged / sp / cls / fname
        dst_dir = out / sp / cls
        dst_dir.mkdir(parents=True, exist_ok=True)
        dst = dst_dir / fname
        if args.link == "hard":
            try:
                os.link(src, dst)
            except OSError:
                shutil.copy2(src, dst)
        else:
            shutil.copy2(src, dst)
        n_kept += 1
        per_split[sp] = per_split.get(sp, 0) + 1
        per_class.setdefault(cls, {s: 0 for s in SPLITS})
        per_class[cls][sp] += 1

    # 复制顶层元文件
    for meta in ["classes.txt", "class_indices.json", "kg_link.json"]:
        src = merged / meta
        if src.exists():
            shutil.copy2(src, out / meta)

    # 重写 dataset_stats.json（更新计数，保留原结构其余字段）
    stats = None
    src_stats = merged / "dataset_stats.json"
    if src_stats.exists():
        try:
            stats = json.loads(src_stats.read_text(encoding="utf-8"))
        except Exception:
            stats = None
    if not isinstance(stats, dict):
        stats = {}
    stats["splits"] = per_split
    stats["total"] = n_kept
    if per_class:
        # 尽量更新原 class 结构；否则写一份计数
        stats["class_counts"] = {
            c: {s: per_class[c].get(s, 0) for s in SPLITS} for c in sorted(per_class)
        }
    (out / "dataset_stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    # 写明细 CSV
    rep_dir = out / "_dedup_report"
    rep_dir.mkdir(parents=True, exist_ok=True)
    detail_csv = rep_dir / "清理明细.csv"
    with open(detail_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(detail_rows[0].keys()))
        w.writeheader()
        w.writerows(detail_rows)

    removed = len(records) - n_kept
    summary = {
        "原始图片数": len(records),
        "干净图片数": n_kept,
        "剔除图片数": removed,
        "重复组数": sum(1 for recs in groups.values() if len(recs) > 1),
        "跨split泄漏组数": len(cross_md5),
        "干净集各split": per_split,
        "去重方法": "完整文件字节 MD5（test>val>train 优先保留）",
        "输出目录": str(out),
    }
    (rep_dir / "清理汇总.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print("\n" + "=" * 60)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\n明细 -> {detail_csv}")
    print(f"干净数据集 -> {out}（原 merged 未改动）")


if __name__ == "__main__":
    main()
