# -*- coding: utf-8 -*-
"""
21_materialize_clean_plan.py
按 Stage5 产出的 clean_plan.csv，物化出新的无近重复泄漏 ImageFolder。

安全：
- 不修改 / 删除 / 移动任何原始图像（只读源、只写 --out）。
- 不启动训练。
- 输出到一个全新目录，绝不覆盖旧 merged / merged_clean。

输入 CSV 至少含列：split, target_class, source_path
（与 Stage2 verified_plan.csv / Stage5 clean_plan.csv 列一致；多余列忽略。）

source_path 解析顺序（尽量稳健，兼容绝对路径与各种相对写法）：
  1) 原样存在；
  2) 相对 --root；
  3) 相对每个 --search-dir；
  4) 在 --merged（旧 ImageFolder）的 <split>/<target_class>/ 下按同名文件找。
任何解析失败的行进入 unresolved.csv，不会静默跳过。

辅助元数据（classes.txt / class_indices.json / kg_link.json / dataset_stats.json）
从 --meta-from（建议直接指向上一版 merged_clean）原样复制，并按新计数重写 dataset_stats.json。

用法（Windows）:
  python 21_materialize_clean_plan.py ^
      --plan stage5_clean_plan_20260923_XXXXXX\\clean_plan.csv ^
      --root F:\\wqq\\CottonInsect ^
      --merged merged_clean ^
      --meta-from merged_clean ^
      --out merged_clean_sift
"""
import argparse
import csv
import json
import os
import shutil
from pathlib import Path

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
SPLITS = ["train", "val", "test"]
META_FILES = ["classes.txt", "class_indices.json", "kg_link.json"]


def resolve_source(value, root, search_dirs, merged):
    """返回能定位到的真实文件 Path，找不到返回 None。"""
    s = str(value).replace("/", os.sep).replace("\\", os.sep)
    cand = Path(s)
    # 1) 原样 / 绝对
    if cand.is_file():
        return cand
    # 2) 相对 root
    p2 = root / s
    if p2.is_file():
        return p2
    # 3) 相对 search dirs
    for d in search_dirs:
        p3 = Path(d) / s
        if p3.is_file():
            return p3
    # 4) 在旧 ImageFolder 内按 split/target/同名 找（此处 merged 与具体行由调用方补充）
    return None


def link_or_copy(src: Path, dst: Path, hard: bool):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if hard:
        try:
            os.link(src, dst)
            return
        except OSError:
            pass
    shutil.copy2(src, dst)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True, help="Stage5 clean_plan.csv 路径")
    ap.add_argument("--root", default=".", help="数据总根（默认当前目录）")
    ap.add_argument("--merged", default="merged_clean",
                    help="旧 ImageFolder（用于按 split/target/同名 兜底定位源文件）")
    ap.add_argument("--meta-from", default="merged_clean",
                    help="从哪个旧 ImageFolder 复制 classes/class_indices/kg_link 元数据")
    ap.add_argument("--search-dir", nargs="*", default=[],
                    help="额外的相对路径搜索根，可多个")
    ap.add_argument("--out", default="merged_clean_sift", help="输出 ImageFolder")
    ap.add_argument("--link", choices=["copy", "hard"], default="copy",
                    help="copy=复制(默认,稳)；hard=同盘硬链接(省空间,失败自动回退复制)")
    args = ap.parse_args()

    root = Path(args.root)
    merged = Path(args.merged)
    meta_from = Path(args.meta_from)
    out = Path(args.out)
    hard = args.link == "hard"

    if out.exists() and any(out.iterdir()):
        raise RuntimeError("输出目录已存在且非空，拒绝覆盖：%s" % out)
    out.mkdir(parents=True, exist_ok=True)

    with open(args.plan, "r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    need = {"split", "target_class", "source_path"}
    if rows and not need.issubset(rows[0].keys()):
        raise RuntimeError("clean_plan.csv 缺列：%s" % sorted(need - set(rows[0].keys())))

    copied = 0
    unresolved = []
    per_split = {sp: 0 for sp in SPLITS}

    for i, r in enumerate(rows, start=1):
        split = str(r["split"]).strip()
        target = str(r["target_class"]).strip()
        raw = str(r["source_path"]).strip()

        src = resolve_source(raw, root, args.search_dir, merged)
        if src is None:
            # 兜底：旧 ImageFolder/<split>/<target>/<basename>
            bn = Path(raw.replace("/", os.sep).replace("\\", os.sep)).name
            p4 = merged / split / target / bn
            if p4.is_file():
                src = p4

        if src is None:
            unresolved.append({"row": i, "split": split,
                               "target_class": target, "source_path": raw})
            continue

        dst = out / split / target / src.name
        # 同名冲突（极少）：加行号后缀，避免互相覆盖
        if dst.exists():
            dst = out / split / target / ("r%d_%s" % (i, src.name))
        link_or_copy(src, dst, hard)
        copied += 1
        if split in per_split:
            per_split[split] += 1

    # 元数据复制
    for mf in META_FILES:
        srcm = meta_from / mf
        if srcm.is_file():
            shutil.copy2(srcm, out / mf)

    # dataset_stats.json 重写计数（若存在）
    stats = {}
    src_stats = meta_from / "dataset_stats.json"
    if src_stats.is_file():
        stats = json.loads(src_stats.read_text(encoding="utf-8"))
    stats["total_images"] = copied
    stats["splits"] = {sp: per_split[sp] for sp in SPLITS}
    (out / "dataset_stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    # 未解析报告
    rep = out / "_materialize_report"
    rep.mkdir(parents=True, exist_ok=True)
    with open(rep / "unresolved.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["row", "split", "target_class", "source_path"])
        w.writeheader()
        w.writerows(unresolved)

    summary = {
        "plan_rows": len(rows),
        "materialized": copied,
        "unresolved": len(unresolved),
        "per_split": per_split,
        "link_mode": args.link,
        "out": str(out),
        "ready": len(unresolved) == 0,
    }
    (rep / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))

    if unresolved:
        print("\n[警告] 有 %d 行源文件无法定位，见 _materialize_report/unresolved.csv"
              % len(unresolved))


if __name__ == "__main__":
    main()
