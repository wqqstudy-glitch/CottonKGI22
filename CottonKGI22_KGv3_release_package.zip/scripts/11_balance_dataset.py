#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
11_balance_dataset.py
对 10_merge_datasets.py 产出的融合分类数据集做"训练集重平衡"(只动 train, val/test 原样)。

策略(可通过参数调整):
  train 数 > --cap   (默认 800)  → 欠采样, 随机保留 cap 张
  train 数 < --floor (默认 200)  → 过采样, 复制补齐到 floor 张(配合训练时在线强增强)
  floor <= train <= cap          → 原样保留
  val / test                     → 完全不动, 保持真实分布用于评估

牧草盲蝽等极小类默认也会过采样到 floor(保留类别, 不合并)。
复制出的文件命名为  原名__dup1.jpg / __dup2.jpg ..., 不修改原 merged 数据集。

用法:
  python 11_balance_dataset.py --src merged --out merged_bal
  python 11_balance_dataset.py --src merged --out merged_bal --cap 800 --floor 200 --seed 42
"""
import argparse
import csv
import json
import random
import shutil
import sys
from pathlib import Path

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def list_images(d: Path):
    if not d.exists():
        return []
    return sorted([p for p in d.iterdir()
                   if p.is_file() and p.suffix.lower() in IMG_EXTS])


def copy_tree_images(src_split: Path, dst_split: Path):
    """val/test 原样按类复制。返回复制张数。"""
    n = 0
    if not src_split.exists():
        return 0
    for cls_dir in sorted(p for p in src_split.iterdir() if p.is_dir()):
        out_cls = dst_split / cls_dir.name
        out_cls.mkdir(parents=True, exist_ok=True)
        for img in list_images(cls_dir):
            shutil.copy2(img, out_cls / img.name)
            n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description="训练集类别重平衡 (欠采样大类 / 过采样小类)")
    ap.add_argument("--src", required=True, help="10 脚本产出的融合数据集目录(含 train/val/test)")
    ap.add_argument("--out", required=True, help="平衡后数据集输出目录")
    ap.add_argument("--cap", type=int, default=800, help="train 超过该数的类欠采样到此值")
    ap.add_argument("--floor", type=int, default=200, help="train 不足该数的类过采样到此值")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--overwrite", action="store_true", help="输出目录已存在时先删除重建")
    args = ap.parse_args()

    src = Path(args.src)
    out = Path(args.out)
    if not (src / "train").exists():
        print(f"❌ 源目录缺少 train/ 子目录: {src}", file=sys.stderr)
        sys.exit(1)
    if out.exists():
        if args.overwrite:
            shutil.rmtree(out)
        else:
            print(f"❌ 输出目录已存在: {out}\n   换个 --out, 或确认无误后加 --overwrite 重建。",
                  file=sys.stderr)
            sys.exit(1)
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)

    # 读 kg_link 以在报告里带上 KG-ID(没有也不影响)
    kg_link = {}
    kp = src / "kg_link.json"
    if kp.exists():
        kg_link = json.loads(kp.read_text(encoding="utf-8"))

    train_src = src / "train"
    classes = sorted([p.name for p in train_src.iterdir() if p.is_dir()])
    if not classes:
        print("❌ train/ 下没有类别文件夹", file=sys.stderr)
        sys.exit(1)

    train_dst = out / "train"
    train_dst.mkdir(parents=True, exist_ok=True)

    report_rows = []
    total_before = total_after = 0
    counts_action = {"undersample": 0, "keep": 0, "oversample": 0}

    for cls in classes:
        imgs = list_images(train_src / cls)
        n0 = len(imgs)
        total_before += n0

        if n0 > args.cap:
            action = "undersample"
            chosen = rng.sample(imgs, args.cap)          # 无重复随机抽取 cap 张
            targets = list(chosen)
        elif n0 < args.floor:
            action = "oversample"
            chosen = list(imgs)
            targets = list(imgs)
            need = args.floor - n0
            # 循环均匀挑图复制, 直到补足 floor; 命名 __dup{k}, 加序号防同名
            k = 0
            gi = 0
            while need > 0:
                src_img = imgs[gi % n0]
                k += 1
                dup_name = f"{src_img.stem}__dup{k}{src_img.suffix}"
                targets.append((src_img, dup_name))
                need -= 1
                gi += 1
        else:
            action = "keep"
            chosen = list(imgs)
            targets = list(imgs)

        out_cls = train_dst / cls
        out_cls.mkdir(parents=True, exist_ok=True)
        for t in targets:
            if isinstance(t, tuple):           # (源路径, 目标文件名) —— 过采样副本
                src_img, dup_name = t
                shutil.copy2(src_img, out_cls / dup_name)
            else:                              # 普通 Path —— 原样复制
                shutil.copy2(t, out_cls / t.name)

        n1 = len(list_images(out_cls))
        total_after += n1
        counts_action[action] += 1
        info = kg_link.get(cls, {})
        report_rows.append({
            "class": cls,
            "kg_id": info.get("kg_id", ""),
            "kg_name": info.get("kg_name", ""),
            "action": action,
            "train_before": n0,
            "train_after": n1,
        })

    # val / test 原样复制
    val_n = copy_tree_images(src / "val", out / "val")
    test_n = copy_tree_images(src / "test", out / "test")

    # 元信息原样带过去
    for fn in ["classes.txt", "class_indices.json", "kg_link.json"]:
        f = src / fn
        if f.exists():
            shutil.copy2(f, out / fn)

    # 报告
    rep_csv = out / "balance_report.csv"
    with open(rep_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["class", "kg_id", "kg_name", "action",
                                          "train_before", "train_after"])
        w.writeheader()
        w.writerows(report_rows)
    rep_json = out / "balance_report.json"
    rep_json.write_text(json.dumps({
        "src": str(src), "cap": args.cap, "floor": args.floor, "seed": args.seed,
        "train_before": total_before, "train_after": total_after,
        "val": val_n, "test": test_n,
        "actions": counts_action,
        "per_class": report_rows,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    # 终端摘要
    print("=" * 78)
    print(f"重平衡完成: cap={args.cap}  floor={args.floor}  seed={args.seed}")
    print("=" * 78)
    print(f"{'类别':<10}{'KG-ID':>8}  {'动作':<12}{'train前':>8}{'train后':>9}")
    print("-" * 78)
    name_map = {"undersample": "欠采样", "keep": "保留", "oversample": "过采样"}
    for r in report_rows:
        print(f"{r['class']:<10}{str(r['kg_id']):>8}  {name_map[r['action']]:<12}"
              f"{r['train_before']:>8}{r['train_after']:>9}")
    print("-" * 78)
    print(f"train: {total_before} → {total_after}   val: {val_n}(不动)   test: {test_n}(不动)")
    print(f"欠采样 {counts_action['undersample']} 类 | 保留 {counts_action['keep']} 类 | "
          f"过采样 {counts_action['oversample']} 类")
    print(f"\n✅ 输出 → {out.resolve()}")
    print(f"报告 → {rep_csv.name} / {rep_json.name}")
    print("\n训练(在线强增强作用在所有副本上, 过采样不会背同一张图):")
    print(f"  python scripts/05_train.py classify --data \"{out}\" "
          f"--model yolo11s-cls.pt --epochs 50 --device 0 --imgsz 224 --batch 256 --workers 8")


if __name__ == "__main__":
    main()
