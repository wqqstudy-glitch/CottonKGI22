#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
10_merge_datasets.py  (v3 按真实结构重写)
把多个数据集中命中 KG 实体的类别合并为统一的 YOLO 分类数据集 (ImageFolder)。

已按实际目录结构适配:
  1) CottonInsect_classification/
       pest_dataset/{train,val,test}/*.jpg   ← 图片平铺, 所有类混放
       train.txt / val.txt / test.txt        ← "图名 类序号" 标签
       class_indices.json                    ← {类token: 序号}
  2) Cotton Leaf Disease Detection Dataset/
       Original Dataset/{Bacterial Blight, Curl Virus, ...}
       Augmented Dataset/{...}               ← 增强副本, 默认不纳入(防 train/test 泄漏)
  3) ip102_v1.1-002/ip102_v1.1/
       images/*.jpg                          ← 75222 张平铺
       train.txt / val.txt / test.txt        ← "图名 类序号"
  4) PlantVillage-Dataset-master/raw/color   ← 本版本无棉花类, 严格精确匹配(本数据贡献0)
       (data_distribution_for_SVM 的数字目录是 PV 自身38类, 不是 IP102, 已排除)

输出:
  <out>/{train,val,test}/<视觉类>/*.jpg
  classes.txt / class_indices.json / kg_link.json(视觉类→KG实体) / dataset_stats.json

用法:
  先体检:  python 10_merge_datasets.py --root "F:\\wqq\\CottonInsect\\data" --inspect
  正式:    python 10_merge_datasets.py --root "F:\\wqq\\CottonInsect\\data" --out "F:\\wqq\\CottonInsect\\merged"
  含增强:  加 --include-augmented
  去重:    加 --dedup
"""
import argparse, sys, json, re, os, hashlib, shutil, random
from pathlib import Path
from collections import defaultdict

random.seed(42)
IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}


# ======================================================================
# 规则表 (只在各自数据集子树内生效, 严禁跨数据集模糊匹配)
# ======================================================================

# CottonInsect 13 类 token → KG
CI_RULES = {
    "bollworm":    ("棉铃虫",   20002,  "棉铃虫",   "pest"),
    "stinkbuglv":  ("绿盲蝽",   20009,  "绿盲蝽",   "pest"),
    "stinkbugzh":  ("中黑盲蝽", 20010,  "中黑盲蝽", "pest"),
    "stinkbugmx":  ("苜蓿盲蝽", 20032,  "苜蓿盲蝽", "pest"),
    "stinkbugmc":  ("牧草盲蝽", 20042,  "牧草盲蝽", "pest"),
    "ladybughb":   ("横斑瓢虫", 120001, "瓢虫类",   "enemy"),
    "ladybugdy":   ("多异瓢虫", 120001, "瓢虫类",   "enemy"),
    "ladybuglbq":  ("七星瓢虫", 120001, "瓢虫类",   "enemy"),
    "lacewing":    ("草蛉",     120002, "草蛉类",   "enemy"),
    "syrphid":     ("食蚜蝇",   120003, "食蚜蝇类", "enemy"),
    # 无 KG: stinkbughsy 黑食蚜盲蝽 / stinkbugccc 茶翅蝽 / bee 蜂类
}

# Cotton Leaf Disease 真实文件夹名(规范化后) → KG
CLD_RULES = {
    "bacterialblight": ("棉角斑病",   10005, "棉角斑病",   "disease"),
    "curlvirus":       ("棉花曲叶病", 10019, "棉花曲叶病", "disease"),
    # 不收入: healthy / herbicidegrowthdamage / leafhopperjassids
    #         / leafredding(红叶,症状) / leafvariegation(叶斑驳,症状)
}

# IP102 官方类序号 → KG (仅棉花相关 14 个)
IP102_RULES = {
    0:  ("美洲斑潜蝇", 20036, "美洲斑潜蝇", "pest"),
    1:  ("斜纹夜蛾",   20015, "斜纹夜蛾",   "pest"),
    2:  ("棉铃虫",     20002, "棉铃虫",     "pest"),
    6:  ("棉小造桥虫", 20003, "棉小造桥虫", "pest"),
    9:  ("甜菜夜蛾",   20014, "甜菜夜蛾",   "pest"),
    16: ("棉二点红蝽", 20037, "棉二点红蝽", "pest"),
    17: ("棉二点红蝽", 20037, "棉二点红蝽", "pest"),
    18: ("棉叶蝉",     20008, "棉叶蝉",     "pest"),
    19: ("烟蓟马",     20053, "烟蓟马",     "pest"),
    24: ("烟粉虱",     20046, "烟粉虱",     "pest"),
    32: ("朱砂叶螨",   20047, "朱砂叶螨",   "pest"),
    33: ("棉蚜",       20001, "棉蚜",       "pest"),
    34: ("扶桑绵粉蚧", 20029, "扶桑绵粉蚧", "pest"),
    35: ("小地老虎",   20021, "小地老虎",   "pest"),
    # 不收入: 36 茎象甲(KG无) / 37 蝽象泛称
}

# PlantVillage 仅精确匹配以下完整目录名(本版本实际不存在, 故贡献0)
PV_RULES = {
    "cottonbacterialblight":  ("棉角斑病",   10005, "棉角斑病",   "disease"),
    "cottonleafcurldisease":  ("棉花曲叶病", 10019, "棉花曲叶病", "disease"),
}


def norm(s: str) -> str:
    s = str(s).strip().lower()
    s = re.sub(r'[^0-9a-z\u4e00-\u9fff]+', '', s)
    return s


# 三种瓢虫在 KG 中同属 120001「瓢虫类」, 可选合并为一个视觉类
LADYBUG_CLASSES = {"横斑瓢虫", "多异瓢虫", "七星瓢虫"}
LADYBUG_MERGED = "瓢虫"


def md5_of(p: Path) -> str:
    h = hashlib.md5()
    with open(p, "rb") as f:
        for buf in iter(lambda: f.read(1 << 16), b""):
            h.update(buf)
    return h.hexdigest()


def build_basename_index(img_root: Path):
    """basename → [Path], 只在指定图片根目录内建索引(避免跨数据集串)。"""
    idx = defaultdict(list)
    for p in img_root.rglob("*"):
        if p.is_file() and p.suffix.lower() in IMG_EXTS:
            idx[p.name].append(p)
    return idx


def parse_labeled_txt(txt: Path, img_index, split: str, kind: str, class_idx_map=None):
    """
    解析 '图名 类序号' 形式的清单。
    kind='ci'   : class_idx_map = {int序号: token}; 用 CI_RULES
    kind='ip102': 类序号直接用 IP102_RULES
    返回 (records, stats)
    """
    records = []
    n_lines = n_nolabel = n_nofile = n_skiprule = 0
    sample_lines = []

    if not txt.exists():
        return records, dict(exists=False)

    for i, raw_line in enumerate(txt.read_text(encoding="utf-8", errors="ignore").splitlines()):
        line = raw_line.strip()
        if not line:
            continue
        n_lines += 1
        if i < 3:
            sample_lines.append(line)

        tokens = line.split()
        int_tokens = [t for t in tokens if re.fullmatch(r"\d+", t)]
        # 找文件名 token: 含扩展名/分隔符, 否则取非整数 token
        name_tok = None
        for t in tokens:
            if re.search(r"\.(jpe?g|png|bmp|tiff?|webp)$", t, re.I) or ("/" in t) or ("\\" in t):
                name_tok = t
                break
        if name_tok is None:
            non_int = [t for t in tokens if not re.fullmatch(r"\d+", t)]
            name_tok = non_int[0] if non_int else None

        # 类序号
        label = int(int_tokens[0]) if int_tokens else None

        # 定位图片
        img_path = None
        if name_tok:
            base = os.path.basename(name_tok.replace("\\", "/"))
            cands = img_index.get(base, [])
            if len(cands) == 1:
                img_path = cands[0]
            elif cands:
                # 优先落在对应 split 子目录
                pref = [c for c in cands if split.lower() in [x.lower() for x in c.parts]]
                img_path = pref[0] if pref else cands[0]
            if img_path is None:
                # 尝试直接相对路径
                cand = txt.parent / name_tok
                if cand.exists():
                    img_path = cand

        if label is None:
            n_nolabel += 1
            continue
        if img_path is None:
            n_nofile += 1
            continue

        # 解析到 KG 规则
        if kind == "ci":
            token = class_idx_map.get(label)
            info = CI_RULES.get(norm(token)) if token else None
        else:
            info = IP102_RULES.get(label)
        if not info:
            n_skiprule += 1
            continue

        cls, kg_id, kg_name, etype = info
        records.append(dict(img=img_path, cls=cls, kg_id=kg_id, kg_name=kg_name,
                            etype=etype, split=split))

    return records, dict(exists=True, lines=n_lines, nolabel=n_nolabel,
                         nofile=n_nofile, skiprule=n_skiprule, sample=sample_lines)


# ======================================================================
# 收集 (每个收集器只在自己的根目录子树内工作)
# ======================================================================
def collect(root: Path, include_augmented: bool):
    all_records = []
    report = {}

    # ---------- 1. CottonInsect (平铺 + txt 标签) ----------
    print("[1/4] CottonInsect Classification")
    ci_dir = root / "CottonInsect_classification"
    ci_pest = ci_dir / "pest_dataset"
    if ci_dir.exists() and ci_pest.exists():
        cj = ci_dir / "class_indices.json"
        idx_to_token = {}
        if cj.exists():
            data = json.loads(cj.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for k, v in data.items():
                    if isinstance(v, int):
                        idx_to_token[v] = k          # {token:序号}
                    elif isinstance(k, int) or str(k).isdigit():
                        idx_to_token[int(k)] = v     # {序号:token}
        img_index = build_basename_index(ci_pest)
        ci_n = 0
        for sp in ["train", "val", "test"]:
            recs, st = parse_labeled_txt(ci_dir / f"{sp}.txt", img_index, sp, "ci", idx_to_token)
            all_records.extend(recs)
            ci_n += len(recs)
            if not st.get("exists"):
                print(f"      ⚠ {sp}.txt 不存在")
            elif st.get("lines") and not recs:
                print(f"      ⚠ {sp}.txt 解析0张, 前3行: {st['sample']}")
        print(f"      命中 KG 图片 {ci_n} 张")
        report["CottonInsect"] = ci_n
    else:
        print("      ⚠ 目录不存在, 跳过")
        report["CottonInsect"] = 0

    # ---------- 2. Cotton Leaf Disease (严格按真实类名, 路径隔离) ----------
    print("[2/4] Cotton Leaf Disease Detection")
    cld_root = root / "Cotton Leaf Disease Detection Dataset"
    cld_n = 0
    if cld_root.exists():
        subsets = ["Original Dataset"]
        if include_augmented:
            subsets.append("Augmented Dataset")
        for subset in subsets:
            sub = cld_root / subset
            if not sub.exists():
                continue
            for d in sub.rglob("*"):
                if not d.is_dir():
                    continue
                info = CLD_RULES.get(norm(d.name))
                if not info:
                    continue
                cls, kg_id, kg_name, etype = info
                n_here = 0
                for img in d.iterdir():
                    if img.is_file() and img.suffix.lower() in IMG_EXTS:
                        all_records.append(dict(
                            img=img, cls=cls, kg_id=kg_id, kg_name=kg_name,
                            etype=etype, split=None,
                            source_tag="LeafOrig" if subset.startswith("Original") else "LeafAug"))
                        n_here += 1
                cld_n += n_here
        tag = "Original+Augmented" if include_augmented else "仅Original(避免增强泄漏)"
        print(f"      命中 KG 图片 {cld_n} 张 [{tag}]")
    else:
        print("      ⚠ 目录不存在, 跳过")
    report["CottonLeafDisease"] = cld_n

    # ---------- 3. IP102 (平铺 + txt 标签, 严格限定 ip102 子树) ----------
    print("[3/4] IP102")
    ip_dir = root / "ip102_v1.1-002" / "ip102_v1.1"
    if not ip_dir.exists():
        ip_dir = root / "ip102_v1.1"
    ip_img = ip_dir / "images"
    if ip_dir.exists() and ip_img.exists():
        img_index = build_basename_index(ip_img)
        ip_n = 0
        for sp in ["train", "val", "test"]:
            recs, st = parse_labeled_txt(ip_dir / f"{sp}.txt", img_index, sp, "ip102")
            all_records.extend(recs)
            ip_n += len(recs)
            if not st.get("exists"):
                print(f"      ⚠ {sp}.txt 不存在")
            elif st.get("lines") and not recs:
                print(f"      ⚠ {sp}.txt 解析0张, 前3行: {st['sample']}")
        print(f"      命中 KG 图片 {ip_n} 张 (棉花相关14类)")
        report["IP102"] = ip_n
    else:
        print("      ⚠ 目录不存在, 跳过")
        report["IP102"] = 0

    # ---------- 4. PlantVillage (仅 raw/color 精确棉花类名, 本版本预期0) ----------
    print("[4/4] PlantVillage")
    pv_color = root / "PlantVillage-Dataset-master" / "raw" / "color"
    pv_n = 0
    if pv_color.exists():
        for d in pv_color.iterdir():
            if d.is_dir():
                info = PV_RULES.get(norm(d.name))
                if info:
                    cls, kg_id, kg_name, etype = info
                    for img in d.iterdir():
                        if img.is_file() and img.suffix.lower() in IMG_EXTS:
                            all_records.append(dict(
                                img=img, cls=cls, kg_id=kg_id, kg_name=kg_name,
                                etype=etype, split=None, source_tag="PV"))
                            pv_n += 1
        if pv_n == 0:
            print("      本版本 raw/color 无棉花类 → 贡献 0 张 (data_distribution_for_SVM 数字目录已正确排除)")
        else:
            print(f"      命中棉花类 {pv_n} 张")
    else:
        print("      ⚠ raw/color 不存在, 跳过(贡献0)")
    report["PlantVillage"] = pv_n

    return all_records, report


# ======================================================================
# 体检
# ======================================================================
def apply_ladybug_merge(records):
    """把横斑/多异/七星三种瓢虫合并为一个视觉类『瓢虫』(同属 KG 120001 瓢虫类)。"""
    n = 0
    for r in records:
        if r["cls"] in LADYBUG_CLASSES:
            r["cls"] = LADYBUG_MERGED
            r["kg_id"] = 120001
            r["kg_name"] = "瓢虫类"
            r["etype"] = "enemy"
            n += 1
    return n


def inspect(root: Path, include_augmented: bool, merge_ladybug: bool = False):
    print("=" * 78)
    print("体检模式 (--inspect): 只扫描不复制")
    print("=" * 78)

    # CottonInsect
    print("\n● CottonInsect_classification  (平铺图 + txt 标签)")
    ci_dir = root / "CottonInsect_classification"
    ci_pest = ci_dir / "pest_dataset"
    if ci_pest.exists():
        cj = ci_dir / "class_indices.json"
        idx_to_token = {}
        if cj.exists():
            data = json.loads(cj.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for k, v in data.items():
                    if isinstance(v, int):
                        idx_to_token[v] = k
                    elif str(k).isdigit():
                        idx_to_token[int(k)] = v
        img_index = build_basename_index(ci_pest)
        per = defaultdict(int)
        for sp in ["train", "val", "test"]:
            txt = ci_dir / f"{sp}.txt"
            recs, st = parse_labeled_txt(txt, img_index, sp, "ci", idx_to_token)
            for r in recs:
                per[r["cls"]] += 1
            if st.get("exists"):
                print(f"  {sp}.txt: 共 {st['lines']} 行, 命中KG {len(recs)}; 样例: {st['sample'][:2]}")
            else:
                print(f"  {sp}.txt 不存在")
        print("  -- 命中 KG 的类别分布 --")
        if merge_ladybug:
            merged_n = sum(per.pop(k, 0) for k in LADYBUG_CLASSES)
            if merged_n:
                per[LADYBUG_MERGED] += merged_n
        for cls, n in sorted(per.items()):
            print(f"     {cls:<10} {n:>6d}")
    else:
        print("  目录不存在")

    # Cotton Leaf Disease
    print("\n● Cotton Leaf Disease Detection")
    cld = root / "Cotton Leaf Disease Detection Dataset"
    if cld.exists():
        for subset in ["Original Dataset", "Augmented Dataset"]:
            sub = cld / subset
            if not sub.exists():
                continue
            for d in sorted(sub.rglob("*")):
                if d.is_dir():
                    n = sum(1 for f in d.iterdir()
                            if f.is_file() and f.suffix.lower() in IMG_EXTS)
                    if n == 0:
                        continue
                    info = CLD_RULES.get(norm(d.name))
                    if info:
                        print(f"   ✅ {n:>6d}  {d.name:<28s} → {info[0]} (KG {info[1]})  [{subset.split()[0]}]")
                    else:
                        print(f"     {n:>6d}  {d.name:<28s} — 跳过(无KG)  [{subset.split()[0]}]")
    else:
        print("  目录不存在")

    # IP102
    print("\n● IP102  (平铺 images + txt 标签)")
    ip_dir = root / "ip102_v1.1-002" / "ip102_v1.1"
    if not ip_dir.exists():
        ip_dir = root / "ip102_v1.1"
    ip_img = ip_dir / "images"
    if ip_img.exists():
        total = sum(1 for f in ip_img.iterdir()
                    if f.is_file() and f.suffix.lower() in IMG_EXTS)
        print(f"  images/ 平铺图片总数: {total}")
        img_index = build_basename_index(ip_img)
        per = defaultdict(int)
        for sp in ["train", "val", "test"]:
            txt = ip_dir / f"{sp}.txt"
            recs, st = parse_labeled_txt(txt, img_index, sp, "ip102")
            for r in recs:
                per[r["cls"]] += 1
            if st.get("exists"):
                print(f"  {sp}.txt: 共 {st['lines']} 行, 命中棉花KG {len(recs)}; 样例: {st['sample'][:2]}")
            else:
                print(f"  {sp}.txt 不存在")
        print("  -- 命中 KG 的棉花害虫分布 --")
        for cls, n in sorted(per.items()):
            print(f"     {cls:<10} {n:>6d}")
    else:
        print("  images 目录不存在")

    # PlantVillage
    print("\n● PlantVillage raw/color (只认精确棉花类名)")
    pv = root / "PlantVillage-Dataset-master" / "raw" / "color"
    if pv.exists():
        cotton = []
        for d in sorted(pv.iterdir()):
            if d.is_dir():
                if norm(d.name) in PV_RULES:
                    cotton.append(d.name)
        if cotton:
            for c in cotton:
                print("   ✅", c)
        else:
            print("   无 Cotton___* 目录 → 本版本不贡献棉花图像 (正常)")
    else:
        print("  raw/color 不存在")

    print("\n" + "=" * 78)
    print("确认以上分布无误后, 去掉 --inspect 正式构建。")
    print("=" * 78)


# ======================================================================
# 写入 + 切分
# ======================================================================
def build(records, out: Path, dedup: bool, ratios):
    tr_r, va_r, te_r = ratios
    out.mkdir(parents=True, exist_ok=True)

    if dedup:
        seen = set()
        uniq = []
        for r in records:
            h = md5_of(r["img"])
            if h in seen:
                continue
            seen.add(h)
            uniq.append(r)
        print(f"\nMD5 去重: {len(records)} → {len(uniq)}")
        records = uniq

    by_cls = defaultdict(list)
    for r in records:
        by_cls[r["cls"]].append(r)

    class_meta = {}
    copied = 0
    for cls in sorted(by_cls):
        recs = by_cls[cls]
        r0 = recs[0]
        sources = sorted({r.get("source_tag") or _src_of(r["img"]) for r in recs})
        class_meta[cls] = dict(kg_id=r0["kg_id"], kg_name=r0["kg_name"],
                               etype=r0["etype"], total=len(recs), sources=sources)

        presplit = {"train": [], "val": [], "test": []}
        pool = []
        for r in recs:
            (presplit[r["split"]] if r["split"] else pool).append(r)
        random.shuffle(pool)
        n = len(pool)
        n_tr = int(n * tr_r)
        n_va = int(n * va_r)
        buckets = {
            "train": presplit["train"] + pool[:n_tr],
            "val":   presplit["val"]   + pool[n_tr:n_tr + n_va],
            "test":  presplit["test"]  + pool[n_tr + n_va:],
        }
        if n >= 2 and not buckets["val"] and buckets["train"]:
            buckets["val"].append(buckets["train"].pop())

        class_meta[cls]["splits"] = {}
        for sp, items in buckets.items():
            d = out / sp / cls
            d.mkdir(parents=True, exist_ok=True)
            class_meta[cls]["splits"][sp] = len(items)
            for r in items:
                tag = r.get("source_tag") or _src_of(r["img"])
                dest = d / f"{tag}_{r['img'].name}"
                k = 1
                while dest.exists():
                    dest = d / f"{tag}_{r['img'].stem}_{k}{r['img'].suffix}"
                    k += 1
                shutil.copy2(r["img"], dest)
                copied += 1

    classes = sorted(class_meta)
    class_indices = {c: i for i, c in enumerate(classes)}
    (out / "classes.txt").write_text("\n".join(classes) + "\n", encoding="utf-8")
    (out / "class_indices.json").write_text(
        json.dumps(class_indices, ensure_ascii=False, indent=2), encoding="utf-8")

    kg_link = {c: {
        "visual_class": c, "class_index": class_indices[c],
        "kg_id": class_meta[c]["kg_id"], "kg_name": class_meta[c]["kg_name"],
        "entity_type": class_meta[c]["etype"],
        "source_datasets": class_meta[c]["sources"],
    } for c in classes}
    (out / "kg_link.json").write_text(
        json.dumps(kg_link, ensure_ascii=False, indent=2), encoding="utf-8")

    stats = {
        "total_visual_classes": len(classes),
        "total_kg_entities": len({class_meta[c]["kg_id"] for c in classes}),
        "total_images": copied, "dedup": dedup,
        "class_distribution": {c: {
            "kg_id": class_meta[c]["kg_id"], "kg_name": class_meta[c]["kg_name"],
            "entity_type": class_meta[c]["etype"], "total": class_meta[c]["total"],
            **class_meta[c]["splits"], "sources": class_meta[c]["sources"],
        } for c in classes},
    }
    (out / "dataset_stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    etype_cn = {"pest": "害虫", "disease": "病害", "enemy": "天敌"}
    print(f"\n{'视觉类':<10}{'KG-ID':>8} {'类型':<6}{'总数':>7}{'train':>7}{'val':>6}{'test':>6}  来源")
    print("-" * 86)
    for c in classes:
        m = class_meta[c]
        s = m["splits"]
        print(f"{c:<10}{m['kg_id']:>8} {etype_cn.get(m['etype'], m['etype']):<6}"
              f"{m['total']:>7}{s.get('train',0):>7}{s.get('val',0):>6}{s.get('test',0):>6}  {','.join(m['sources'])}")
    print("-" * 86)
    print(f"视觉类 {len(classes)} → KG 实体 {stats['total_kg_entities']} | 图片 {copied}")
    print(f"\n✅ 输出 → {out.resolve()}")
    print(f"训练: python 05_train.py classify --data \"{out}\" --model yolo11s-cls.pt --epochs 50")


def _src_of(p: Path) -> str:
    low = str(p).lower()
    if "cottoninsect" in low:
        return "CottonInsect"
    if "ip102" in low:
        return "IP102"
    if "plantvillage" in low:
        return "PV"
    return "SRC"


def main():
    ap = argparse.ArgumentParser(description="多数据集 → KG 融合分类数据集 (v3)")
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", default="merged_dataset")
    ap.add_argument("--dedup", action="store_true")
    ap.add_argument("--include-augmented", action="store_true",
                    help="纳入 Cotton Leaf Disease 的 Augmented Dataset(默认不用, 防增强图泄漏到测试集)")
    ap.add_argument("--train", type=float, default=0.8)
    ap.add_argument("--val", type=float, default=0.1)
    ap.add_argument("--test", type=float, default=0.1)
    ap.add_argument("--inspect", action="store_true")
    ap.add_argument("--merge-ladybug", action="store_true",
                    help="把横斑/多异/七星三种瓢虫合并为一个『瓢虫』视觉类(同属 KG 120001, 更稳)")
    args = ap.parse_args()

    root = Path(args.root)
    if not root.exists():
        print(f"❌ 根目录不存在: {root}")
        sys.exit(1)
    if args.inspect:
        inspect(root, args.include_augmented, args.merge_ladybug)
        return
    if abs(args.train + args.val + args.test - 1.0) > 1e-6:
        print("❌ train/val/test 比例之和必须为 1")
        sys.exit(1)

    print("=" * 78)
    print(f"扫描: {root}   增强集: {'纳入' if args.include_augmented else '不纳入(仅Original)'}")
    print("=" * 78)
    records, report = collect(root, args.include_augmented)
    print("\n" + "=" * 78)
    print("各数据集命中:", json.dumps(report, ensure_ascii=False))
    print(f"合计命中 KG 图片: {len(records)}")
    if args.merge_ladybug:
        n_lb = apply_ladybug_merge(records)
        print(f"🐞 已合并三种瓢虫 → 『瓢虫』(KG 120001): {n_lb} 张")
    print("=" * 78)
    if not records:
        print("\n⚠ 未收集到图片。请先用 --inspect 查看, 并把 train.txt 前几行发我以校准解析。")
        sys.exit(2)
    build(records, Path(args.out), args.dedup, (args.train, args.val, args.test))


if __name__ == "__main__":
    main()
