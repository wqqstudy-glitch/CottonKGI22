#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
13_make_classmap.py
把 10_merge_datasets.py 生成的 merged/kg_link.json 转成
06_infer.py / 04_entity_linking.py 认识的老格式 class_map.json。

新格式(kg_link.json):
  {"烟蓟马": {"visual_class":"烟蓟马","class_index":0,
              "kg_id":20053,"kg_name":"烟蓟马","entity_type":"pest", ...}}

老格式(class_map.json):
  {"烟蓟马": {"dataset_label_0based":0,"zh":"烟蓟马",
              "kg_entity_type":"pest","kg_id":20053,"kg_name":"烟蓟马","note":""}}

用法:
  python 13_make_classmap.py --link merged/kg_link.json --out merged/class_map.json
"""
import argparse
import json
import sys
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--link", default="merged/kg_link.json", help="10号脚本产出的 kg_link.json")
    ap.add_argument("--out", default="merged/class_map.json", help="输出的兼容 class_map.json")
    args = ap.parse_args()

    link_p = Path(args.link)
    if not link_p.exists():
        print(f"❌ 找不到 {link_p}，请先用 10_merge_datasets.py 构建 merged 数据集", file=sys.stderr)
        sys.exit(1)

    kg_link = json.loads(link_p.read_text(encoding="utf-8"))

    class_map = {}
    for name, info in kg_link.items():
        class_map[name] = {
            "dataset_label_0based": int(info["class_index"]),
            "zh": info.get("visual_class", name),
            "kg_entity_type": info.get("entity_type"),
            "kg_id": info.get("kg_id"),
            "kg_name": info.get("kg_name"),
            "note": "由 13_make_classmap.py 从 kg_link.json 自动生成",
        }

    out_p = Path(args.out)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.write_text(json.dumps(class_map, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"✅ {len(class_map)} 个视觉类 -> {out_p.resolve()}")
    print("下一步(分类推理):")
    print('  python scripts/06_infer.py classify \\')
    print('    --weights runs/classify/runs/cottoninsect/<run名>/weights/best.pt \\')
    print('    --source <一张田间照片或文件夹> \\')
    print(f'    --class-map {out_p.as_posix()} \\')
    print('    --out outputs/preds.json [--part 叶片 --stage 蕾期]')


if __name__ == "__main__":
    main()
