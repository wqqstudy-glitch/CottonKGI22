#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
04_entity_linking.py  (批量升级版)
视觉识别结果 -> 知识图谱实体链接 + KG 约束重排。

支持两种输入:
  - 单张图对象 (dict): {"image":..,"context":{..},"detections":[...]}
  - 多张图数组 (list[dict], 06_infer.py 对文件夹推理的产物)

流程(每张图):
  1. 数据集/视觉类 -> KG 实体(class_map.json); 同一 KG 实体的多类聚合
  2. KG 约束重排(kg_constraints.json):
       - 部位: 近义词归一后匹配, 冲突降权
       - 生育期: 不在发生时期内降权
       - 无 context 时跳过对应约束(不惩罚)
  3. 输出重排后的 KG 实体候选; 批量时额外给汇总:
       视觉Top1 vs KG重排Top1 的正确率、被翻转数、翻转帮对/帮错数

真值: 自动取图片路径的父目录名(ImageFolder 类名), 用于评估; 非 ImageFolder
      路径(如自拍照)取不到真值则该图只做链接、不计正确率。

用法:
  python 04_entity_linking.py --dets outputs/preds.json \
      --class-map merged/class_map.json \
      --kg outputs/kg_constraints.json \
      --out outputs/linking_result.json
  # 忽略预测里自带的上下文(纯视觉对比)加: --no-context
  # 强制统一上下文(覆盖每条自带的): --part 叶片 --stage 蕾期
"""
import argparse
import json
from pathlib import Path

# 重排权重 (可按实验调整)
W_PART_CONFLICT = 0.35    # 部位冲突: 分数乘系数
W_STAGE_CONFLICT = 0.6    # 生育期不符: 分数乘系数 (惩罚轻于部位)
W_AGG_BONUS = 1.05        # 多个检测类聚合到同一实体: 轻微加成(上限)

# 部位近义词归一组: 组内任一词视为同部位, 解决 KG 用词粒度差异
# (如烟蓟马记"真叶/子叶", 上下文给"叶片"; 棉铃虫记"棉铃", 上下文给"铃")
PART_GROUPS = [
    {"叶片", "真叶", "子叶", "叶"},
    {"蕾", "花蕾", "蕾铃"},
    {"花", "花瓣"},
    {"棉铃", "幼铃", "青铃", "铃", "桃", "棉桃"},
    {"茎", "秆", "枝干"},
    {"顶心", "生长点", "顶芽", "心叶"},
    {"根", "根部", "根系"},
]


def _same_part(a: str, b: str) -> bool:
    """两个部位词是否等价: 字面包含, 或落在同一近义词组。"""
    if not a or not b:
        return False
    if a in b or b in a:
        return True
    for grp in PART_GROUPS:
        if a in grp and b in grp:
            return True
    return False


def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def link_and_rerank(dets, class_map, kg, context=None):
    context = context or {}
    ctx_part = context.get("part")
    ctx_stage = context.get("stage")

    # 1) 聚合到 KG 实体
    agg = {}
    rejects = []
    for d in dets:
        cls = d["dataset_class"]
        score = float(d.get("score", 0.0))
        info = class_map.get(cls, {})
        kg_id = info.get("kg_id")
        etype = info.get("kg_entity_type")
        if kg_id is None:
            rejects.append({
                "dataset_class": cls, "zh": info.get("zh"),
                "score": score,
                "reason": ("待植保核实, 暂不链接" if etype == "unverified"
                           else "非棉花KG目标(天敌以外/其他作物害虫/中性昆虫)"),
            })
            continue
        rec = kg.get(str(kg_id)) or kg.get(kg_id) or {}
        key = int(kg_id)
        if key not in agg:
            agg[key] = {
                "kg_id": key,
                "kg_name": info.get("kg_name") or rec.get("kg_name"),
                "entity_type": etype,
                "visual_score": 0.0,
                "from_classes": [],
                "raw_scores": [],
            }
        agg[key]["raw_scores"].append(score)
        agg[key]["from_classes"].append(cls)
        agg[key]["visual_score"] = max(agg[key]["visual_score"], score)

    # 2) 约束重排
    results = []
    for key, item in agg.items():
        rec = kg.get(str(key)) or kg.get(key) or {}
        parts = rec.get("parts", [])
        stages = rec.get("stages", [])
        penalties = []
        final = item["visual_score"]

        if len(item["from_classes"]) > 1:
            final = min(1.0, final * W_AGG_BONUS)

        if ctx_part and parts:
            hit = any(_same_part(ctx_part, p) for p in parts)
            if not hit:
                final *= W_PART_CONFLICT
                penalties.append(f"部位冲突: 拍摄部位≈{ctx_part}, 该实体为害部位={parts}")
        if ctx_stage and stages:
            hit = any(ctx_stage in s or s in ctx_stage for s in stages)
            if not hit:
                final *= W_STAGE_CONFLICT
                penalties.append(f"生育期不符: 当前≈{ctx_stage}, 该实体发生时期={stages}")

        results.append({
            "kg_id": key,
            "kg_name": item["kg_name"],
            "entity_type": item["entity_type"],
            "visual_score": round(item["visual_score"], 4),
            "final_score": round(final, 4),
            "from_classes": item["from_classes"],
            "kg_parts": parts,
            "kg_stages": stages,
            "kg_symptoms": rec.get("symptoms", []),
            "penalties": penalties,
        })

    results.sort(key=lambda r: r["final_score"], reverse=True)
    # 视觉序(不看KG分数)用于对比
    visual_order = sorted(results, key=lambda r: r["visual_score"], reverse=True)
    return {
        "context": context,
        "linked_entities": results,
        "visual_order": [r["kg_id"] for r in visual_order],
        "unlinked_detections": rejects,
        "top1": results[0] if results else None,
        "visual_top1": visual_order[0] if visual_order else None,
    }


def _entity_matches_gt(ent, gt_class):
    """真值(视觉类中文名)是否命中该 KG 实体(按实体名或其来源视觉类)。"""
    if not ent or not gt_class:
        return False
    if gt_class == ent.get("kg_name"):
        return True
    return gt_class in ent.get("from_classes", [])


def _gt_from_path(image_path: str):
    """取父目录名作为 ImageFolder 真值; 取不到返回 None。"""
    if not image_path:
        return None
    parent = Path(image_path).parent.name
    return parent or None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dets", required=True, help="06 推理输出 JSON(单图对象或数组)")
    ap.add_argument("--class-map", required=True)
    ap.add_argument("--kg", default="outputs/kg_constraints.json")
    ap.add_argument("--out", default="outputs/linking_result.json")
    ap.add_argument("--part", default=None, help="强制统一部位, 覆盖每条自带 context")
    ap.add_argument("--stage", default=None, help="强制统一生育期")
    ap.add_argument("--no-context", action="store_true", help="忽略所有上下文, 纯视觉序对比")
    ap.add_argument("--show", type=int, default=10, help="终端打印前 N 张明细")
    args = ap.parse_args()

    payload = load_json(args.dets)
    class_map = load_json(args.class_map)
    kg = load_json(args.kg)
    records = payload if isinstance(payload, list) else [payload]

    per_image = []
    n_with_gt = 0
    vis_hit = kg_hit = 0
    flipped = helped = hurt = 0

    for rec in records:
        image = rec.get("image")
        ctx = {} if args.no_context else dict(rec.get("context") or {})
        if args.part:
            ctx["part"] = args.part
        if args.stage:
            ctx["stage"] = args.stage

        out = link_and_rerank(rec.get("detections", []), class_map, kg, context=ctx)
        gt = _gt_from_path(image)

        vtop = out["visual_top1"]
        ktop = out["top1"]
        v_ok = _entity_matches_gt(vtop, gt) if gt else None
        k_ok = _entity_matches_gt(ktop, gt) if gt else None
        is_flip = bool(vtop and ktop and vtop["kg_id"] != ktop["kg_id"])

        if gt:
            n_with_gt += 1
            vis_hit += int(bool(v_ok))
            kg_hit += int(bool(k_ok))
            if is_flip:
                flipped += 1
                if k_ok and not v_ok:
                    helped += 1
                if v_ok and not k_ok:
                    hurt += 1

        per_image.append({
            "image": image,
            "ground_truth": gt,
            "context": ctx,
            "visual_top1": ({"kg_id": vtop["kg_id"], "kg_name": vtop["kg_name"],
                             "score": vtop["visual_score"]} if vtop else None),
            "kg_top1": ({"kg_id": ktop["kg_id"], "kg_name": ktop["kg_name"],
                         "visual_score": ktop["visual_score"],
                         "final_score": ktop["final_score"],
                         "penalties": ktop["penalties"]} if ktop else None),
            "flipped": is_flip,
            "visual_correct": v_ok,
            "kg_correct": k_ok,
            "linked_entities": out["linked_entities"],
            "unlinked_detections": out["unlinked_detections"],
        })

    summary = {
        "n_images": len(records),
        "n_with_ground_truth": n_with_gt,
        "context_mode": ("none(纯视觉)" if args.no_context
                         else "per-image/统一" if (args.part or args.stage) else "per-image"),
        "visual_top1_accuracy": round(vis_hit / n_with_gt, 4) if n_with_gt else None,
        "kg_rerank_top1_accuracy": round(kg_hit / n_with_gt, 4) if n_with_gt else None,
        "accuracy_delta": round((kg_hit - vis_hit) / n_with_gt, 4) if n_with_gt else None,
        "n_flipped": flipped,
        "flip_helped_correct": helped,
        "flip_hurt_correct": hurt,
    }

    result_doc = {"summary": summary, "results": per_image}
    out_p = Path(args.out)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.write_text(json.dumps(result_doc, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------- 终端汇总 ----------
    print("=" * 78)
    print(f"图片 {summary['n_images']} 张 | 有真值(ImageFolder) {n_with_gt} 张 | 上下文: {summary['context_mode']}")
    if n_with_gt:
        print(f"视觉 Top-1 准确率 : {summary['visual_top1_accuracy']:.4f}")
        print(f"KG重排 Top-1 准确率: {summary['kg_rerank_top1_accuracy']:.4f}  "
              f"(Δ {summary['accuracy_delta']:+.4f})")
        print(f"Top-1 被KG翻转 {flipped} 张: 帮对 {helped} / 帮错 {hurt} / 同错互换 {flipped-helped-hurt}")
    print("=" * 78)

    # 明细(前 N 张, 重点看翻转和惩罚)
    for i, r in enumerate(per_image[:args.show], 1):
        v, k = r["visual_top1"], r["kg_top1"]
        gt = r.get("ground_truth") or "?"
        vtxt = f"{v['kg_name']}({v['score']:.2f})" if v else "-"
        kpn = ""
        if k and k["penalties"]:
            kpn = " ⚠" + "; ".join(k["penalties"])
        ktxt = f"{k['kg_name']}({k['final_score']:.2f})" if k else "-"
        mark = " 🔄" if r["flipped"] else ""
        print(f"{i:>3}. 真值={gt:<8} 视觉 {vtxt:<22} -> KG {ktxt}{mark}{kpn}")
    if len(per_image) > args.show:
        print(f"... 其余 {len(per_image)-args.show} 张见 JSON")

    print(f"\n✅ 输出 -> {out_p.resolve()}")
    if (args.part or args.stage) and not args.no_context:
        print("注意: 本次上下文为统一假设(非逐图真实农情), 数字仅验证管线与重排机制,")
        print("      不要直接作为论文性能结论; 正式对比需逐图真实上下文或无上下文结构重排。")


if __name__ == "__main__":
    main()
